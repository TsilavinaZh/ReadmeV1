 Bien sûr, je vais vous fournir une liste étendue de 50 composants React Native avec un bref exemple de code pour chacun. Notez que certains de ces composants sont moins courants ou spécifiques à certaines plateformes. Voici la liste :

1. View
```jsx
<View style={{ flex: 1, backgroundColor: 'white' }}>
  {/* Contenu */}
</View>
```

2. Text
```jsx
<Text style={{ fontSize: 16, color: 'black' }}>Hello, world!</Text>
```

3. Image
```jsx
<Image source={{ uri: 'https://example.com/image.jpg' }} style={{ width: 200, height: 200 }} />
```

4. TextInput
```jsx
<TextInput placeholder="Entrez du texte" onChangeText={(text) => console.log(text)} />
```

5. ScrollView
```jsx
<ScrollView>
  {/* Contenu défilant */}
</ScrollView>
```

6. FlatList
```jsx
<FlatList
  data={[{ key: 'a' }, { key: 'b' }]}
  renderItem={({ item }) => <Text>{item.key}</Text>}
/>
```

7. TouchableOpacity
```jsx
<TouchableOpacity onPress={() => console.log('Pressé')}>
  <Text>Appuyez ici</Text>
</TouchableOpacity>
```

8. Button
```jsx
<Button title="Cliquez-moi" onPress={() => console.log('Cliqué')} />
```

9. StyleSheet
```jsx
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'white' },
});
```

10. SafeAreaView
```jsx
<SafeAreaView style={{ flex: 1 }}>
  {/* Contenu sécurisé */}
</SafeAreaView>
```

11. ActivityIndicator
```jsx
<ActivityIndicator size="large" color="#0000ff" />
```

12. Modal
```jsx
<Modal visible={true} transparent={true}>
  <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
    <Text>Contenu modal</Text>
  </View>
</Modal>
```

13. Switch
```jsx
<Switch value={true} onValueChange={(value) => console.log(value)} />
```

14. Picker (deprecated, use community version)
```jsx
<Picker selectedValue="java" onValueChange={(itemValue) => console.log(itemValue)}>
  <Picker.Item label="Java" value="java" />
  <Picker.Item label="JavaScript" value="js" />
</Picker>
```

15. StatusBar
```jsx
<StatusBar barStyle="dark-content" backgroundColor="white" />
```

16. TouchableHighlight
```jsx
<TouchableHighlight onPress={() => console.log('Pressé')}>
  <Text>Appuyez ici</Text>
</TouchableHighlight>
```

17. KeyboardAvoidingView
```jsx
<KeyboardAvoidingView behavior="padding" style={{ flex: 1 }}>
  {/* Contenu */}
</KeyboardAvoidingView>
```

18. Pressable
```jsx
<Pressable onPress={() => console.log('Pressé')}>
  <Text>Pressable</Text>
</Pressable>
```

19. RefreshControl
```jsx
<ScrollView refreshControl={
  <RefreshControl refreshing={false} onRefresh={() => console.log('Rafraîchi')} />
}>
  {/* Contenu */}
</ScrollView>
```

20. SectionList
```jsx
<SectionList
  sections={[{ title: 'Section 1', data: ['Item 1', 'Item 2'] }]}
  renderItem={({ item }) => <Text>{item}</Text>}
  renderSectionHeader={({ section }) => <Text>{section.title}</Text>}
/>
```

21. DrawerLayoutAndroid (Android only)
```jsx
<DrawerLayoutAndroid
  drawerWidth={300}
  drawerPosition="left"
  renderNavigationView={() => <View><Text>Drawer Content</Text></View>}
>
  <View><Text>Main Content</Text></View>
</DrawerLayoutAndroid>
```

22. TouchableWithoutFeedback
```jsx
<TouchableWithoutFeedback onPress={() => console.log('Pressé')}>
  <View><Text>Appuyez ici</Text></View>
</TouchableWithoutFeedback>
```

23. VirtualizedList
```jsx
<VirtualizedList
  data={[1, 2, 3]}
  renderItem={({ item }) => <Text>{item}</Text>}
  getItemCount={(data) => data.length}
  getItem={(data, index) => data[index]}
/>
```

24. ImageBackground
```jsx
<ImageBackground source={{ uri: 'https://example.com/bg.jpg' }} style={{ flex: 1 }}>
  <Text>Texte sur l'image</Text>
</ImageBackground>
```

25. Slider (deprecated, use community version)
```jsx
<Slider
  style={{ width: 200, height: 40 }}
  minimumValue={0}
  maximumValue={1}
  value={0.5}
  onValueChange={(value) => console.log(value)}
/>
```

# Chakra UI

 Bien sûr, je vais vous donner une liste de 50 composants Chakra UI avec des exemples de code pour chacun. Chakra UI est une bibliothèque de composants pour React, donc ces exemples fonctionneront dans une application React ou React Native (avec les adaptations nécessaires pour React Native).

1. Box
```jsx
<Box bg="tomato" w="100%" p={4} color="white">
  Ceci est un Box
</Box>
```

2. Flex
```jsx
<Flex>
  <Box p="4" bg="red.400">Box 1</Box>
  <Spacer />
  <Box p="4" bg="green.400">Box 2</Box>
</Flex>
```

3. Center
```jsx
<Center bg="tomato" h="100px" color="white">
  Ceci est centré
</Center>
```

4. Text
```jsx
<Text fontSize="2xl" color="blue.500">
  Ceci est un texte
</Text>
```

5. Heading
```jsx
<Heading as="h2" size="xl">
  Ceci est un titre
</Heading>
```

6. Button
```jsx
<Button colorScheme="blue">Cliquez-moi</Button>
```

7. IconButton
```jsx
<IconButton aria-label="Search database" icon={<SearchIcon />} />
```

8. Input
```jsx
<Input placeholder="Entrez du texte" />
```

9. Textarea
```jsx
<Textarea placeholder="Voici un textarea" />
```

10. Select
```jsx
<Select placeholder="Sélectionnez une option">
  <option value="option1">Option 1</option>
  <option value="option2">Option 2</option>
</Select>
```

11. Checkbox
```jsx
<Checkbox>Cochez-moi</Checkbox>
```

12. Radio
```jsx
<RadioGroup>
  <Radio value="1">Option 1</Radio>
  <Radio value="2">Option 2</Radio>
</RadioGroup>
```

13. Switch
```jsx
<Switch />
```

14. Stack
```jsx
<Stack spacing={3}>
  <Box bg="tomato" h="40px" />
  <Box bg="blue.500" h="40px" />
</Stack>
```

15. HStack
```jsx
<HStack spacing="24px">
  <Box w="40px" h="40px" bg="yellow.200">1</Box>
  <Box w="40px" h="40px" bg="tomato">2</Box>
</HStack>
```

16. VStack
```jsx
<VStack spacing="24px">
  <Box w="40px" h="40px" bg="yellow.200">1</Box>
  <Box w="40px" h="40px" bg="tomato">2</Box>
</VStack>
```

17. Wrap
```jsx
<Wrap>
  <WrapItem><Center w="180px" h="80px" bg="red.200">Box 1</Center></WrapItem>
  <WrapItem><Center w="180px" h="80px" bg="green.200">Box 2</Center></WrapItem>
</Wrap>
```

18. Container
```jsx
<Container maxW="xl" centerContent>
  <Box padding="4" bg="blue.400" color="white" maxW="md">
    Contenu dans un container
  </Box>
</Container>
```

19. SimpleGrid
```jsx
<SimpleGrid columns={2} spacing={10}>
  <Box height="80px" bg="tomato">1</Box>
  <Box height="80px" bg="tomato">2</Box>
</SimpleGrid>
```

20. Grid
```jsx
<Grid templateColumns="repeat(5, 1fr)" gap={6}>
  <GridItem w="100%" h="10" bg="blue.500" />
  <GridItem w="100%" h="10" bg="blue.500" />
</Grid>
```

21. Accordion
```jsx
<Accordion>
  <AccordionItem>
    <AccordionButton>Section 1</AccordionButton>
    <AccordionPanel>Contenu de la section 1</AccordionPanel>
  </AccordionItem>
</Accordion>
```

22. Tabs
```jsx
<Tabs>
  <TabList>
    <Tab>One</Tab>
    <Tab>Two</Tab>
  </TabList>
  <TabPanels>
    <TabPanel>Contenu 1</TabPanel>
    <TabPanel>Contenu 2</TabPanel>
  </TabPanels>
</Tabs>
```

23. Modal
```jsx
<Modal isOpen={isOpen} onClose={onClose}>
  <ModalOverlay />
  <ModalContent>
    <ModalHeader>Modal Title</ModalHeader>
    <ModalCloseButton />
    <ModalBody>Contenu du modal</ModalBody>
    <ModalFooter>
      <Button colorScheme="blue" mr={3} onClick={onClose}>Fermer</Button>
    </ModalFooter>
  </ModalContent>
</Modal>
```

24. Drawer
```jsx
<Drawer isOpen={isOpen} placement="right" onClose={onClose}>
  <DrawerOverlay />
  <DrawerContent>
    <DrawerHeader>Drawer Content</DrawerHeader>
    <DrawerBody>Contenu du drawer</DrawerBody>
  </DrawerContent>
</Drawer>
```

25. Popover
```jsx
<Popover>
  <PopoverTrigger>
    <Button>Trigger</Button>
  </PopoverTrigger>
  <PopoverContent>
    <PopoverArrow />
    <PopoverCloseButton />
    <PopoverHeader>Confirmation!</PopoverHeader>
    <PopoverBody>Contenu du popover</PopoverBody>
  </PopoverContent>
</Popover>
```

Voulez-vous que je continue avec les 25 composants restants ?


 D'accord, je vais vous présenter les principaux composants et APIs standards de React Native. Ces éléments font partie de l'API de base de React Native et sont largement utilisés dans le développement d'applications mobiles.

1. AppState
```jsx
import { AppState } from 'react-native';

AppState.addEventListener('change', (nextAppState) => {
  if (nextAppState === 'active') {
    console.log('App has come to the foreground!');
  }
});
```

2. AsyncStorage
```jsx
import AsyncStorage from '@react-native-async-storage/async-storage';

const storeData = async (value) => {
  try {
    await AsyncStorage.setItem('@storage_Key', value)
  } catch (e) {
    // saving error
  }
}
```

3. Dimensions
```jsx
import { Dimensions } from 'react-native';

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
```

4. Linking
```jsx
import { Linking } from 'react-native';

Linking.openURL('https://www.example.com').catch(err => console.error('An error occurred', err));
```

5. PanResponder
```jsx
import { PanResponder } from 'react-native';

const panResponder = PanResponder.create({
  onStartShouldSetPanResponder: () => true,
  onPanResponderMove: (evt, gestureState) => {
    console.log(gestureState.dx, gestureState.dy);
  },
});
```

6. PixelRatio
```jsx
import { PixelRatio } from 'react-native';

const pixelRatio = PixelRatio.get();
console.log(`Device Pixel Ratio: ${pixelRatio}`);
```

7. Platform
```jsx
import { Platform } from 'react-native';

if (Platform.OS === 'ios') {
  console.log('Running on iOS');
} else if (Platform.OS === 'android') {
  console.log('Running on Android');
}
```

8. StyleSheet
```jsx
import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
```

9. Vibration
```jsx
import { Vibration } from 'react-native';

// Vibrate for 1 second
Vibration.vibrate(1000);
```

10. Alert
```jsx
import { Alert } from 'react-native';

Alert.alert(
  "Titre",
  "Message",
  [
    { text: "OK", onPress: () => console.log("OK Pressed") }
  ]
);
```

11. Animated
```jsx
import { Animated } from 'react-native';

const fadeAnim = new Animated.Value(0);

Animated.timing(fadeAnim, {
  toValue: 1,
  duration: 1000,
  useNativeDriver: true,
}).start();
```

12. Keyboard
```jsx
import { Keyboard } from 'react-native';

Keyboard.addListener('keyboardDidShow', () => {
  console.log('Keyboard shown');
});
```

13. LayoutAnimation
```jsx
import { LayoutAnimation } from 'react-native';

LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
```

14. InteractionManager
```jsx
import { InteractionManager } from 'react-native';

InteractionManager.runAfterInteractions(() => {
  // ...long-running synchronous task...
});
```

15. ToastAndroid (Android only)
```jsx
import { ToastAndroid } from 'react-native';

ToastAndroid.show('A pikachu appeared nearby !', ToastAndroid.SHORT);
```

Voulez-vous que je continue avec d'autres APIs ou composants standards de React Native ?


 Bien sûr, je vais reprendre la liste des APIs standards de React Native avec une brève explication pour chacune :

1. AppState
```jsx
import { AppState } from 'react-native';

AppState.addEventListener('change', (nextAppState) => {
  if (nextAppState === 'active') {
    console.log('App has come to the foreground!');
  }
});
```
Explication : AppState permet de suivre l'état de l'application (actif, inactif, en arrière-plan). Utile pour gérer le comportement de l'app lors des transitions d'état.

2. AsyncStorage
```jsx
import AsyncStorage from '@react-native-async-storage/async-storage';

const storeData = async (value) => {
  try {
    await AsyncStorage.setItem('@storage_Key', value)
  } catch (e) {
    // saving error
  }
}
```
Explication : AsyncStorage est un système de stockage de données clé-valeur asynchrone. Il est utilisé pour persister des données simples dans l'application.

3. Dimensions
```jsx
import { Dimensions } from 'react-native';

const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;
```
Explication : Dimensions permet d'obtenir les dimensions de l'écran du dispositif. Utile pour créer des layouts responsives.

4. Linking
```jsx
import { Linking } from 'react-native';

Linking.openURL('https://www.example.com').catch(err => console.error('An error occurred', err));
```
Explication : Linking permet d'ouvrir des URLs externes et de gérer les deep links dans l'application.

5. PanResponder
```jsx
import { PanResponder } from 'react-native';

const panResponder = PanResponder.create({
  onStartShouldSetPanResponder: () => true,
  onPanResponderMove: (evt, gestureState) => {
    console.log(gestureState.dx, gestureState.dy);
  },
});
```
Explication : PanResponder gère les gestes tactiles complexes comme le glissement ou le pincement.

6. PixelRatio
```jsx
import { PixelRatio } from 'react-native';

const pixelRatio = PixelRatio.get();
console.log(`Device Pixel Ratio: ${pixelRatio}`);
```
Explication : PixelRatio donne des informations sur la densité de pixels de l'écran, utile pour ajuster les tailles et les images en fonction de la résolution.

7. Platform
```jsx
import { Platform } from 'react-native';

if (Platform.OS === 'ios') {
  console.log('Running on iOS');
} else if (Platform.OS === 'android') {
  console.log('Running on Android');
}
```
Explication : Platform permet de détecter la plateforme sur laquelle l'app s'exécute, permettant d'ajuster le code en fonction du système d'exploitation.

8. StyleSheet
```jsx
import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
```
Explication : StyleSheet est utilisé pour créer des styles optimisés pour React Native, similaires aux CSS mais avec des propriétés spécifiques à RN.

9. Vibration
```jsx
import { Vibration } from 'react-native';

// Vibrate for 1 second
Vibration.vibrate(1000);
```
Explication : Vibration permet de contrôler le moteur de vibration du dispositif, utile pour le retour haptique.

10. Alert
```jsx
import { Alert } from 'react-native';

Alert.alert(
  "Titre",
  "Message",
  [
    { text: "OK", onPress: () => console.log("OK Pressed") }
  ]
);
```
Explication : Alert affiche une boîte de dialogue native avec un titre, un message et des boutons d'action.

Voulez-vous que je continue avec les APIs restantes ?

