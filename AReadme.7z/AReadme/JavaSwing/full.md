Bien sûr ! Voici une approche détaillée, étape par étape, pour apprendre Java Swing avec des exemples de code.

### 1. Premiers Composants Swing

#### Créer une Fenêtre avec `JFrame`

```java
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class SimpleFrame {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Ma Première Fenêtre");
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

#### Ajouter des Panneaux avec `JPanel`

```java
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class PanelExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Fenêtre avec Panneau");
            JPanel panel = new JPanel();
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

#### Utiliser des Boutons avec `JButton`

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class ButtonExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Fenêtre avec Bouton");
            JPanel panel = new JPanel();
            JButton button = new JButton("Cliquez-moi");
            panel.add(button);
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

### Gestion des Événements

#### Implémenter des Écouteurs avec `ActionListener` et `MouseListener`

**ActionListener**

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionListenerExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("ActionListener Example");
            JPanel panel = new JPanel();
            JButton button = new JButton("Cliquez-moi");
            
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.out.println("Bouton cliqué !");
                }
            });
            
            panel.add(button);
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

**MouseListener**

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MouseListenerExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("MouseListener Example");
            JPanel panel = new JPanel();
            JButton button = new JButton("Cliquez-moi");

            button.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    System.out.println("Bouton cliqué avec la souris !");
                }

                @Override
                public void mousePressed(MouseEvent e) {}
                @Override
                public void mouseReleased(MouseEvent e) {}
                @Override
                public void mouseEntered(MouseEvent e) {}
                @Override
                public void mouseExited(MouseEvent e) {}
            });

            panel.add(button);
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

#### Exercice : Créer une Fenêtre avec un Bouton et un Champ de Texte

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TextFieldButtonExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Fenêtre avec Champ de Texte et Bouton");
            JPanel panel = new JPanel();
            JTextField textField = new JTextField(20);
            JButton button = new JButton("Afficher le texte");

            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    System.out.println(textField.getText());
                }
            });

            panel.add(textField);
            panel.add(button);
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

### 2. Composants Avancés de Swing

#### Menus et Barres d’Outils

```java
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class MenuExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Fenêtre avec Menu");
            JMenuBar menuBar = new JMenuBar();
            JMenu menu = new JMenu("Fichier");
            JMenuItem menuItem = new JMenuItem("Quitter");

            menuItem.addActionListener(e -> System.exit(0));

            menu.add(menuItem);
            menuBar.add(menu);
            frame.setJMenuBar(menuBar);
            
            JPanel panel = new JPanel();
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

#### Dialogues

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class DialogExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Fenêtre avec Dialogue");
            JPanel panel = new JPanel();
            JButton button = new JButton("Afficher une boîte de dialogue");

            button.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Bonjour !"));

            panel.add(button);
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

#### Listes et Tableaux

```java
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.ListSelectionModel;
import javax.swing.JList;

public class ListAndTableExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Liste et Tableau");
            JPanel panel = new JPanel();
            
            // Liste
            String[] items = {"Item 1", "Item 2", "Item 3"};
            JList<String> list = new JList<>(items);
            JScrollPane listScrollPane = new JScrollPane(list);

            // Tableau
            String[] columnNames = {"Nom", "Âge"};
            Object[][] data = {
                {"Alice", 30},
                {"Bob", 25},
                {"Charlie", 35}
            };
            JTable table = new JTable(data, columnNames);
            JScrollPane tableScrollPane = new JScrollPane(table);

            panel.add(listScrollPane);
            panel.add(tableScrollPane);
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

#### Formulaires

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.SwingUtilities;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FormExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Formulaire");
            JPanel panel = new JPanel();
            
            JTextField nameField = new JTextField(20);
            JPasswordField passwordField = new JPasswordField(20);
            JComboBox<String> comboBox = new JComboBox<>(new String[]{"Option 1", "Option 2"});
            JButton submitButton = new JButton("Soumettre");

            submitButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String name = nameField.getText();
                    String password = new String(passwordField.getPassword());
                    String option = (String) comboBox.getSelectedItem();
                    System.out.println("Nom: " + name);
                    System.out.println("Mot de passe: " + password);
                    System.out.println("Option: " + option);
                }
            });

            panel.add(nameField);
            panel.add(passwordField);
            panel.add(comboBox);
            panel.add(submitButton);
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

#### Exercice : Créer une Application avec un Formulaire

Tu peux combiner les éléments ci-dessus pour créer une application avec un formulaire qui recueille des informations de l'utilisateur et les affiche dans la console ou les sauvegarde dans un fichier.

### 3. Mise en Page et Agenc

ements (Layouts)

#### FlowLayout, BorderLayout, GridLayout

**FlowLayout**

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.FlowLayout;

public class FlowLayoutExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("FlowLayout Example");
        JPanel panel = new JPanel(new FlowLayout());

        panel.add(new JButton("Bouton 1"));
        panel.add(new JButton("Bouton 2"));
        panel.add(new JButton("Bouton 3"));

        frame.add(panel);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
```

**BorderLayout**

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;

public class BorderLayoutExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("BorderLayout Example");
        JPanel panel = new JPanel(new BorderLayout());

        panel.add(new JButton("Nord"), BorderLayout.NORTH);
        panel.add(new JButton("Sud"), BorderLayout.SOUTH);
        panel.add(new JButton("Est"), BorderLayout.EAST);
        panel.add(new JButton("Ouest"), BorderLayout.WEST);
        panel.add(new JButton("Centre"), BorderLayout.CENTER);

        frame.add(panel);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
```

**GridLayout**

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridLayout;

public class GridLayoutExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("GridLayout Example");
        JPanel panel = new JPanel(new GridLayout(3, 2));

        panel.add(new JButton("1"));
        panel.add(new JButton("2"));
        panel.add(new JButton("3"));
        panel.add(new JButton("4"));
        panel.add(new JButton("5"));
        panel.add(new JButton("6"));

        frame.add(panel);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
```

#### BoxLayout et GridBagLayout

**BoxLayout**

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.BoxLayout;

public class BoxLayoutExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("BoxLayout Example");
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        panel.add(new JButton("Bouton 1"));
        panel.add(new JButton("Bouton 2"));
        panel.add(new JButton("Bouton 3"));

        frame.add(panel);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
```

**GridBagLayout**

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

public class GridBagLayoutExample {
    public static void main(String[] args) {
        JFrame frame = new JFrame("GridBagLayout Example");
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JButton("1"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        panel.add(new JButton("2"), gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JButton("3"), gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(new JButton("4"), gbc);

        frame.add(panel);
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
```

#### Exercice : Créer une Interface Complexe avec Plusieurs Composants

Combine les différents agencements pour créer une interface utilisateur complexe qui utilise plusieurs panneaux et boutons organisés avec différents layouts.

### 4. Gestion des Fichiers et Persistance

#### Lire et Écrire des Fichiers

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;

public class FileWritingExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Écriture dans un Fichier");
            JPanel panel = new JPanel();
            JTextField textField = new JTextField(20);
            JButton saveButton = new JButton("Sauvegarder");

            saveButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try (FileWriter writer = new FileWriter("data.txt")) {
                        writer.write(textField.getText());
                        System.out.println("Données sauvegardées !");
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
            });

            panel.add(textField);
            panel.add(saveButton);
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

#### JFileChooser

```java
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.JFileChooser;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

public class FileChooserExample {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("JFileChooser Example");
            JPanel panel = new JPanel();
            JButton openButton = new JButton("Ouvrir un Fichier");

            openButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    JFileChooser fileChooser = new JFileChooser();
                    int result = fileChooser.showOpenDialog(frame);
                    if (result == JFileChooser.APPROVE_OPTION) {
                        File selectedFile = fileChooser.getSelectedFile();
                        System.out.println("Fichier sélectionné : " + selectedFile.getAbsolutePath());
                    }
                }
            });

            panel.add(openButton);
            frame.add(panel);
            frame.setSize(400, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        });
    }
}
```

#### Exercice : Créer une Application qui Sauvegarde les Données dans un Fichier

Utilise les exemples ci-dessus pour créer une application qui collecte les données des utilisateurs et les sauvegarde dans un fichier texte.

### 5. Graphisme et Animation

#### Dessin avec `Graphics`

```java
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;

public class DrawingExample extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawRect(50, 50, 100, 100);
        g.drawOval(200, 50, 100, 100);
        g.drawLine(50, 200, 150, 300);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Dessin avec Graphics");
        frame.add(new DrawingExample());
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
```

#### Animation avec `Timer`

```java
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AnimationExample extends JPanel {
    private int x = 0;

    public AnimationExample() {
        Timer timer = new Timer(10, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                x++;
                if (x > getWidth()) {
                    x = 0;
                }
                repaint();
            }
        });
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.fillOval(x, 50, 30, 30);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Animation avec Timer");
        frame.add(new AnimationExample());
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
```

#### Exercice : Créer une Application avec Animation

Crée une application qui utilise des animations pour afficher un objet en mouvement ou créer un effet visuel dynamique.

---

Ces exemples couvrent les bases et les concepts avancés de Java Swing. En les suivant, tu pourras développer des applications desktop robustes et interactives.