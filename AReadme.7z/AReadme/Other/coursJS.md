### Stage 1: Prerequisites

#### JavaScript Fundamentals

**Variables, data types, and operators:**

```javascript
// Variables
let name = "John"; // let allows variable reassignment
const age = 25; // const means the variable can't be reassigned

// Data types
let isStudent = true; // boolean
let height = 5.9; // number
let hobbies = ["reading", "sports"]; // array

// Operators
let sum = 10 + 5; // addition
let product = 10 * 5; // multiplication
let isEqual = (10 == "10"); // true, type coercion
let isIdentical = (10 === "10"); // false, no type coercion
```

**Functions and scope:**

```javascript
// Function declaration
function greet(name) {
  return `Hello, ${name}!`;
}

// Function expression
const add = function(a, b) {
  return a + b;
};

// Arrow function
const multiply = (a, b) => a * b;

// Scope
let globalVar = "I am global";

function checkScope() {
  let localVar = "I am local";
  console.log(globalVar); // Accessible
  console.log(localVar); // Accessible
}
console.log(globalVar); // Accessible
// console.log(localVar); // Unaccessible, would cause an error
```

**Asynchronous JavaScript: Promises, async/await**

```javascript
// Promise
let fetchData = new Promise((resolve, reject) => {
  setTimeout(() => {
    resolve("Data fetched");
  }, 2000);
});

fetchData.then(data => console.log(data)).catch(error => console.error(error));

// Async/Await
async function getData() {
  try {
    let data = await fetchData;
    console.log(data);
  } catch (error) {
    console.error(error);
  }
}

getData();
```

**ES6+ features:**

```javascript
// let/const
let variable = "value"; // Block scoped
const constant = "fixed value"; // Block scoped and cannot be reassigned

// Arrow functions
const addNumbers = (a, b) => a + b;

// Destructuring
const person = {
  name: "Alice",
  age: 30,
};
const { name, age } = person;

// Template literals
const message = `Hello, ${name}. You are ${age} years old.`;
```

#### Node.js Basics

**Understanding the Node.js runtime:**
Node.js is a JavaScript runtime built on Chrome's V8 JavaScript engine. It allows you to run JavaScript on the server side.

**Working with npm (Node Package Manager):**
NPM is a package manager for JavaScript. It helps you to install and manage dependencies for your project.

```bash
npm init -y // Initialize a new Node.js project
npm install express // Install express package
```

**Basic file system operations:**

```javascript
const fs = require('fs');

// Reading a file
fs.readFile('example.txt', 'utf8', (err, data) => {
  if (err) throw err;
  console.log(data);
});

// Writing to a file
fs.writeFile('example.txt', 'Hello, world!', (err) => {
  if (err) throw err;
  console.log('File has been saved!');
});
```

**Creating simple HTTP servers with the built-in http module:**

```javascript
const http = require('http');

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello, world!\n');
});

server.listen(3000, () => {
  console.log('Server running at http://127.0.0.1:3000/');
});
```

### Stage 2: Getting Started with Express.js

#### Introduction to Express.js

**What is Express.js?**
Express.js is a minimal and flexible Node.js web application framework that provides a robust set of features for web and mobile applications.

**Installing Express.js:**

```bash
npm install express
```

**Setting up a basic Express server:**

```javascript
const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.send('Hello, world!');
});

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
```

#### Basic Routing

**Handling GET, POST, PUT, DELETE requests:**

```javascript
// GET request
app.get('/user', (req, res) => {
  res.send('GET request to the user');
});

// POST request
app.post('/user', (req, res) => {
  res.send('POST request to the user');
});

// PUT request
app.put('/user/:id', (req, res) => {
  res.send(`PUT request to user with ID ${req.params.id}`);
});

// DELETE request
app.delete('/user/:id', (req, res) => {
  res.send(`DELETE request to user with ID ${req.params.id}`);
});
```

**Route parameters and query strings:**

```javascript
// Route parameters
app.get('/user/:id', (req, res) => {
  res.send(`User ID: ${req.params.id}`);
});

// Query strings
app.get('/search', (req, res) => {
  res.send(`Search query: ${req.query.q}`);
});
```

#### Middleware

**Understanding middleware functions:**
Middleware functions are functions that have access to the request object (req), the response object (res), and the next middleware function in the application’s request-response cycle.

**Built-in middleware vs. custom middleware:**

```javascript
// Built-in middleware
app.use(express.json()); // Parse JSON bodies

// Custom middleware
app.use((req, res, next) => {
  console.log('Request received at ' + Date.now());
  next(); // Pass control to the next middleware function
});
```

**Error handling middleware:**

```javascript
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});
```

### Stage 3: Building RESTful APIs

#### CRUD Operations

**Creating, reading, updating, and deleting resources:**

```javascript
let users = [];

app.post('/users', (req, res) => {
  const user = req.body;
  users.push(user);
  res.status(201).send(user);
});

app.get('/users', (req, res) => {
  res.send(users);
});

app.get('/users/:id', (req, res) => {
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).send('User not found');
  res.send(user);
});

app.put('/users/:id', (req, res) => {
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).send('User not found');
  user.name = req.body.name;
  res.send(user);
});

app.delete('/users/:id', (req, res) => {
  const userIndex = users.findIndex(u => u.id === parseInt(req.params.id));
  if (userIndex === -1) return res.status(404).send('User not found');
  users.splice(userIndex, 1);
  res.status(204).send();
});
```

**Using express.Router for modular routing:**

```javascript
const userRouter = express.Router();

userRouter.get('/', (req, res) => {
  res.send(users);
});

userRouter.post('/', (req, res) => {
  const user = req.body;
  users.push(user);
  res.status(201).send(user);
});

app.use('/users', userRouter);
```

#### Request and Response

**Handling request data (body, params, query):**

```javascript
app.use(express.json());

app.post('/user', (req, res) => {
  console.log(req.body); // body data
  res.send('User received');
});

app.get('/user/:id', (req, res) => {
  console.log(req.params.id); // route parameter
  res.send('User ID received');
});

app.get('/search', (req, res) => {
  console.log(req.query.q); // query string
  res.send('Query received');
});
```

**Sending responses (JSON, status codes, headers):**

```javascript
app.get('/user', (req, res) => {
  res.status(200).json({ name: 'John', age: 30 });
});

app.get('/error', (req, res) => {
  res.status(500).send('Server error');
});

app.get('/headers', (req, res) => {
  res.set('Custom-Header', 'Value').send('Headers set');
});
```

#### Data Validation and Sanitization

**Using libraries like express-validator for input validation:**

```javascript
const { body, validationResult } = require('express-validator');

app.post('/user', [
  body('email').isEmail(),
  body('password').isLength({ min: 5 })
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  res.send('User is valid');
});
```

**Sanitizing data to prevent security issues:**

```javascript
app.post('/user', [
  body('username').trim().escape(),
  body('email').normalizeEmail()
], (req, res) => {
  res```javascript
.send('Data sanitized and user is valid');
});
```

#### Working with Databases

**Connecting to databases (MongoDB, PostgreSQL, MySQL):**

1. **MongoDB:**

```javascript
const mongoose = require('mongoose');

mongoose.connect('mongodb://localhost:27017/mydatabase', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});
```

2. **PostgreSQL:**

```javascript
const { Pool } = require('pg');

const pool = new Pool({
  user: 'myuser',
  host: 'localhost',
  database: 'mydatabase',
  password: 'mypassword',
  port: 5432,
});

pool.connect((err, client, done) => {
  if (err) throw err;
  console.log('Connected to PostgreSQL');
});
```

3. **MySQL:**

```javascript
const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'myuser',
  password: 'mypassword',
  database: 'mydatabase'
});

connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL');
});
```

**Using ODM/ORM (Mongoose, Sequelize, etc.):**

1. **Mongoose (for MongoDB):**

```javascript
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: String,
  age: Number,
  email: String
});

const User = mongoose.model('User', userSchema);

// Create a new user
const newUser = new User({ name: 'Alice', age: 30, email: 'alice@example.com' });

newUser.save((err) => {
  if (err) return console.error(err);
  console.log('User saved');
});
```

2. **Sequelize (for SQL databases):**

```javascript
const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize('database', 'username', 'password', {
  host: 'localhost',
  dialect: 'postgres' // or 'mysql'
});

const User = sequelize.define('User', {
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  age: {
    type: DataTypes.INTEGER
  },
  email: {
    type: DataTypes.STRING
  }
});

// Sync and create a new user
sequelize.sync().then(() => {
  User.create({
    name: 'Alice',
    age: 30,
    email: 'alice@example.com'
  }).then(user => {
    console.log('User created:', user.toJSON());
  });
});
```

### Putting It All Together

Here's a complete example of a basic Express.js application that connects to MongoDB, sets up routes for CRUD operations, validates input, and handles errors:

```javascript
const express = require('express');
const mongoose = require('mongoose');
const { body, validationResult } = require('express-validator');

const app = express();
const PORT = 3000;

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/mydatabase', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// Define a User schema and model
const userSchema = new mongoose.Schema({
  name: String,
  age: Number,
  email: String
});

const User = mongoose.model('User', userSchema);

// Middleware to parse JSON bodies
app.use(express.json());

// Routes
app.post('/users', [
  body('email').isEmail(),
  body('name').not().isEmpty().trim().escape(),
  body('age').isInt({ min: 0 })
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const user = new User(req.body);
  user.save((err) => {
    if (err) return res.status(500).send('Error saving user');
    res.status(201).send(user);
  });
});

app.get('/users', (req, res) => {
  User.find((err, users) => {
    if (err) return res.status(500).send('Error retrieving users');
    res.send(users);
  });
});

app.get('/users/:id', (req, res) => {
  User.findById(req.params.id, (err, user) => {
    if (err) return res.status(500).send('Error retrieving user');
    if (!user) return res.status(404).send('User not found');
    res.send(user);
  });
});

app.put('/users/:id', [
  body('email').optional().isEmail(),
  body('name').optional().trim().escape(),
  body('age').optional().isInt({ min: 0 })
], (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  User.findByIdAndUpdate(req.params.id, req.body, { new: true }, (err, user) => {
    if (err) return res.status(500).send('Error updating user');
    if (!user) return res.status(404).send('User not found');
    res.send(user);
  });
});

app.delete('/users/:id', (req, res) => {
  User.findByIdAndDelete(req.params.id, (err, user) => {
    if (err) return res.status(500).send('Error deleting user');
    if (!user) return res.status(404).send('User not found');
    res.status(204).send();
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/`);
});
```

In this example, the Express.js application:

1. Connects to a MongoDB database using Mongoose.
2. Defines a User schema and model.
3. Sets up routes for creating, reading, updating, and deleting users.
4. Validates and sanitizes input using `express-validator`.
5. Handles errors gracefully.

Pour apprendre les API web et les API RESTful avec des exemples de code, nous allons créer une simple API RESTful utilisant Node.js et Express. Cette API permettra de gérer une collection de livres avec des opérations de base comme créer, lire, mettre à jour et supprimer (CRUD).

### 1. Installation de Node.js et Express

Assure-toi d'avoir Node.js et npm installés sur ta machine. Ensuite, crée un nouveau projet :

```bash
mkdir rest-api-example
cd rest-api-example
npm init -y
npm install express
```

### 2. Structure du Projet

Organise ton projet comme suit :

```
rest-api-example/
├── node_modules/
├── package.json
└── server.js
```

### 3. Création de l'API RESTful

Ouvre le fichier `server.js` et ajoute le code suivant :

```javascript
const express = require('express');
const app = express();
const port = 3000;

// Middleware pour parser le corps des requêtes en JSON
app.use(express.json());

// Données de test
let books = [
  { id: 1, title: '1984', author: 'George Orwell' },
  { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee' },
];

// Routes de l'API

// 1. Obtenir tous les livres
app.get('/books', (req, res) => {
  res.json(books);
});

// 2. Obtenir un livre par ID
app.get('/books/:id', (req, res) => {
  const book = books.find(b => b.id === parseInt(req.params.id));
  if (book) {
    res.json(book);
  } else {
    res.status(404).send('Book not found');
  }
});

// 3. Créer un nouveau livre
app.post('/books', (req, res) => {
  const newBook = {
    id: books.length + 1,
    title: req.body.title,
    author: req.body.author,
  };
  books.push(newBook);
  res.status(201).json(newBook);
});

// 4. Mettre à jour un livre existant
app.put('/books/:id', (req, res) => {
  const book = books.find(b => b.id === parseInt(req.params.id));
  if (book) {
    book.title = req.body.title;
    book.author = req.body.author;
    res.json(book);
  } else {
    res.status(404).send('Book not found');
  }
});

// 5. Supprimer un livre
app.delete('/books/:id', (req, res) => {
  const bookIndex = books.findIndex(b => b.id === parseInt(req.params.id));
  if (bookIndex !== -1) {
    const deletedBook = books.splice(bookIndex, 1);
    res.json(deletedBook[0]);
  } else {
    res.status(404).send('Book not found');
  }
});

// Démarrer le serveur
app.listen(port, () => {
  console.log(`API listening at http://localhost:${port}`);
});
```

### 4. Explication du Code

- **Middleware** : `app.use(express.json())` permet de parser les requêtes avec un corps JSON.
- **Routes** :
  - `GET /books` : Renvoie la liste de tous les livres.
  - `GET /books/:id` : Renvoie les détails d'un livre spécifique par ID.
  - `POST /books` : Crée un nouveau livre avec les données fournies dans le corps de la requête.
  - `PUT /books/:id` : Met à jour les détails d'un livre existant par ID.
  - `DELETE /books/:id` : Supprime un livre par ID.
- **Données** : Utilise un tableau `books` comme stockage temporaire pour les livres.

### 5. Tester l'API

Pour tester l'API, utilise des outils comme [Postman](https://www.postman.com/) ou [cURL](https://curl.se/). Voici quelques exemples de requêtes :

- **Obtenir tous les livres** :
  ```
  GET http://localhost:3000/books
  ```

- **Obtenir un livre par ID** :
  ```
  GET http://localhost:3000/books/1
  ```

- **Créer un nouveau livre** :
  ```
  POST http://localhost:3000/books
  Content-Type: application/json

  {
    "title": "New Book",
    "author": "Author Name"
  }
  ```

- **Mettre à jour un livre** :
  ```
  PUT http://localhost:3000/books/1
  Content-Type: application/json

  {
    "title": "Updated Title",
    "author": "Updated Author"
  }
  ```

- **Supprimer un livre** :
  ```
  DELETE http://localhost:3000/books/1
  ```

Avec cette API simple, tu as une base pour comprendre comment fonctionnent les API RESTful. N'hésite pas à l'étendre et à ajouter des fonctionnalités supplémentaires pour approfondir ta compréhension.