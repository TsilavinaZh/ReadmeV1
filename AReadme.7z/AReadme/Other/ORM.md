D'accord, utilisons Node.js avec une bibliothèque ORM populaire appelée Sequelize. Voici comment tu peux gérer tes "jouets" avec Sequelize.

### Étapes de Configuration

1. **Installation de Sequelize et SQLite** (ou une autre base de données comme PostgreSQL, MySQL, etc.)

   ```bash
   npm install sequelize sqlite3
   ```

2. **Configuration de Sequelize**

   Crée un fichier `database.js` pour configurer Sequelize avec SQLite :

   ```javascript
   const { Sequelize, DataTypes } = require('sequelize');
   const sequelize = new Sequelize({
     dialect: 'sqlite',
     storage: 'database.sqlite'
   });

   const Jouet = sequelize.define('Jouet', {
     id: {
       type: DataTypes.INTEGER,
       primaryKey: true,
       autoIncrement: true
     },
     nom: {
       type: DataTypes.STRING,
       allowNull: false
     },
     couleur: {
       type: DataTypes.STRING,
       allowNull: false
     }
   });

   module.exports = { sequelize, Jouet };
   ```

3. **Création et Synchronisation de la Base de Données**

   Crée un fichier `sync.js` pour synchroniser la base de données :

   ```javascript
   const { sequelize, Jouet } = require('./database');

   async function syncDatabase() {
     await sequelize.sync({ force: true });
     console.log('La base de données a été synchronisée.');
   }

   syncDatabase();
   ```

   Exécute ce fichier pour synchroniser la base de données :

   ```bash
   node sync.js
   ```

4. **Ajouter et Lire des Jouets**

   Crée un fichier `app.js` pour ajouter et lire des jouets :

   ```javascript
   const { sequelize, Jouet } = require('./database');

   async function manageJouets() {
     // Ajouter un nouveau jouet
     const nouveauJouet = await Jouet.create({ nom: 'Poupée Barbie', couleur: 'Rose' });
     console.log(`Nouveau jouet ajouté: ${nouveauJouet.nom} (${nouveauJouet.couleur})`);

     // Lire un jouet de la base de données
     const jouet = await Jouet.findOne({ where: { nom: 'Poupée Barbie' } });
     console.log(`Jouet trouvé: ${jouet.nom} (${jouet.couleur})`);
   }

   manageJouets();
   ```

   Exécute ce fichier pour voir le résultat :

   ```bash
   node app.js
   ```

### Explication Simplifiée

- **Configuration de Sequelize**: Tu définis une connexion à la base de données SQLite et tu crées un modèle Jouet avec les attributs `id`, `nom`, et `couleur`.
- **Synchronisation de la Base de Données**: Tu crées et synchronises les tables de la base de données.
- **Ajouter et Lire des Jouets**: Tu ajoutes un nouveau jouet avec le nom "Poupée Barbie" et la couleur "Rose", puis tu le lis de la base de données.

Cela fonctionne de manière similaire à l'exemple Python avec SQLAlchemy, mais en utilisant Node.js et Sequelize. L'ORM te permet de travailler avec des objets JavaScript au lieu d'écrire des requêtes SQL directement.