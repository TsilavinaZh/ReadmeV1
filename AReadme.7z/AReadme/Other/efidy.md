Pour créer le système de vote décrit, nous allons diviser le projet en plusieurs parties : backend (Node.js et MySQL) et frontend (React).

## Backend (Node.js avec Express et MySQL)

### 1. Initialisation du projet et installation des dépendances

```sh
# Créer un dossier pour le projet et initialiser npm
mkdir voting-system
cd voting-system
npm init -y

# Installer les dépendances nécessaires
npm install express mysql2 sequelize body-parser bcryptjs jsonwebtoken cors dotenv
```

### 2. Configuration de la base de données

Créez un fichier `.env` pour les configurations environnementales:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=yourpassword
DB_NAME=voting_system
JWT_SECRET=your_jwt_secret
```

### 3. Configuration de Sequelize pour la base de données MySQL

`config/database.js`:

```js
const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
    host: process.env.DB_HOST,
    dialect: 'mysql'
});

module.exports = sequelize;
```

### 4. Création des modèles Sequelize

`models/User.js`:

```js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const User = sequelize.define('User', {
    username: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    }
});

module.exports = User;
```

`models/Candidate.js`:

```js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Candidate = sequelize.define('Candidate', {
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    photo: {
        type: DataTypes.STRING,
        allowNull: false
    }
});

module.exports = Candidate;
```

`models/Vote.js`:

```js
const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Vote = sequelize.define('Vote', {
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    candidateId: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
});

module.exports = Vote;
```

### 5. Configuration du serveur Express

`server.js`:

```js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sequelize = require('./config/database');
const User = require('./models/User');
const Candidate = require('./models/Candidate');
const Vote = require('./models/Vote');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());
app.use(cors());

// Importer les routes
const authRoutes = require('./routes/auth');
const candidateRoutes = require('./routes/candidate');
const voteRoutes = require('./routes/vote');

// Utiliser les routes
app.use('/auth', authRoutes);
app.use('/candidates', candidateRoutes);
app.use('/votes', voteRoutes);

sequelize.sync().then(() => {
    app.listen(5000, () => {
        console.log('Server is running on port 5000');
    });
});
```

### 6. Création des routes

`routes/auth.js`:

```js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const router = express.Router();
require('dotenv').config();

// Inscription
router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const user = await User.create({ username, password: hashedPassword });
        res.status(201).json(user);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Connexion
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ where: { username } });
        if (!user || !await bcrypt.compare(password, user.password)) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }
        const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
```

`routes/candidate.js`:

```js
const express = require('express');
const Candidate = require('../models/Candidate');
const router = express.Router();

// Ajouter un candidat
router.post('/', async (req, res) => {
    const { name, photo } = req.body;
    try {
        const candidate = await Candidate.create({ name, photo });
        res.status(201).json(candidate);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Modifier un candidat
router.put('/:id', async (req, res) => {
    const { id } = req.params;
    const { name, photo } = req.body;
    try {
        const candidate = await Candidate.findByPk(id);
        if (!candidate) {
            return res.status(404).json({ message: 'Candidate not found' });
        }
        candidate.name = name;
        candidate.photo = photo;
        await candidate.save();
        res.json(candidate);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Supprimer un candidat
router.delete('/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const candidate = await Candidate.findByPk(id);
        if (!candidate) {
            return res.status(404).json({ message: 'Candidate not found' });
        }
        await candidate.destroy();
        res.json({ message: 'Candidate deleted' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Liste des candidats
router.get('/', async (req, res) => {
    try {
        const candidates = await Candidate.findAll();
        res.json(candidates);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
```

`routes/vote.js`:

```js
const express = require('express');
const Vote = require('../models/Vote');
const Candidate = require('../models/Candidate');
const jwt = require('jsonwebtoken');
const router = express.Router();
require('dotenv').config();

// Middleware d'authentification
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// Voter pour un candidat
router.post('/', authenticateToken, async (req, res) => {
    const { candidateId } = req.body;
    try {
        const existingVote = await Vote.findOne({ where: { userId: req.user.userId } });
        if (existingVote) {
            return res.status(403).json({ message: 'You have already voted' });
        }
        const vote = await Vote.create({ userId: req.user.userId, candidateId });
        res.status(201).json(vote);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Afficher les résultats
router.get('/', async (req, res) => {
    try {
        const candidates = await Candidate.findAll({
            include: [{ model: Vote, attributes: [] }],
            attributes: ['id', 'name', [sequelize.fn('COUNT', sequelize.col('Votes.id')), 'voteCount']],
            group: ['Candidate.id']
        });
        res.json(candidates);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
```

## Frontend (React)

### 1. Initialisation du projet et installation des dépendances

```sh
npx create-react-app voting-system-client
cd voting-system-client
npm install axios react-router-dom
```

### 2. Configuration des routes et des composants

`src/App.js`:

```jsx
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './components/Home';
import Register from './components/Register';
import Login from './components/Login';
import Candidates from './components/Candidates';
import Vote from './components/Vote';
import Results from './components/Results';

function App() {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/register" component={Register} />
          <Route path="/login" component={Login} />
          <Route path="/candidates" component={Candidates} />
          <Route path="/vote" component={Vote} />
          <Route path="/results" component={Results} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
```

### 3. Création des composants

### 3. Création des composants

Créez les différents composants nécessaires pour l'application.

`src/components/Home.js`:

```jsx
import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div>
      <h1>Bienvenue sur le système de vote</h1>
      <Link to="/register">S'inscrire</Link>
      <Link to="/login">Se connecter</Link>
      <Link to="/candidates">Voir les candidats</Link>
      <Link to="/vote">Voter</Link>
      <Link to="/results">Voir les résultats</Link>
    </div>
  );
};

export default Home;
```

`src/components/Register.js`:

```jsx
import React, { useState } from 'react';
import axios from 'axios';

const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleRegister = async () => {
    try {
      await axios.post('http://localhost:5000/auth/register', { username, password });
      alert('Inscription réussie');
    } catch (error) {
      alert('Erreur lors de l\'inscription');
    }
  };

  return (
    <div>
      <h1>S'inscrire</h1>
      <input
        type="text"
        placeholder="Nom d'utilisateur"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Mot de passe"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleRegister}>S'inscrire</button>
    </div>
  );
};

export default Register;
```

`src/components/Login.js`:

```jsx
import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:5000/auth/login', { username, password });
      localStorage.setItem('token', response.data.token);
      alert('Connexion réussie');
      history.push('/candidates');
    } catch (error) {
      alert('Erreur lors de la connexion');
    }
  };

  return (
    <div>
      <h1>Se connecter</h1>
      <input
        type="text"
        placeholder="Nom d'utilisateur"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Mot de passe"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Se connecter</button>
    </div>
  );
};

export default Login;
```

`src/components/Candidates.js`:

```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Candidates = () => {
  const [candidates, setCandidates] = useState([]);
  const [name, setName] = useState('');
  const [photo, setPhoto] = useState('');

  const fetchCandidates = async () => {
    const response = await axios.get('http://localhost:5000/candidates');
    setCandidates(response.data);
  };

  const addCandidate = async () => {
    await axios.post('http://localhost:5000/candidates', { name, photo });
    fetchCandidates();
  };

  const deleteCandidate = async (id) => {
    await axios.delete(`http://localhost:5000/candidates/${id}`);
    fetchCandidates();
  };

  useEffect(() => {
    fetchCandidates();
  }, []);

  return (
    <div>
      <h1>Liste des candidats</h1>
      <input
        type="text"
        placeholder="Nom du candidat"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        type="text"
        placeholder="Photo URL"
        value={photo}
        onChange={(e) => setPhoto(e.target.value)}
      />
      <button onClick={addCandidate}>Ajouter un candidat</button>
      <ul>
        {candidates.map(candidate => (
          <li key={candidate.id}>
            {candidate.name}
            <button onClick={() => deleteCandidate(candidate.id)}>Supprimer</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Candidates;
```

`src/components/Vote.js`:

```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Vote = () => {
  const [candidates, setCandidates] = useState([]);
  const [selectedCandidate, setSelectedCandidate] = useState(null);

  const fetchCandidates = async () => {
    const response = await axios.get('http://localhost:5000/candidates');
    setCandidates(response.data);
  };

  const vote = async () => {
    const token = localStorage.getItem('token');
    await axios.post('http://localhost:5000/votes', { candidateId: selectedCandidate }, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
    alert('Vote réussi');
  };

  useEffect(() => {
    fetchCandidates();
  }, []);

  return (
    <div>
      <h1>Votez pour votre candidat préféré</h1>
      <select onChange={(e) => setSelectedCandidate(e.target.value)}>
        <option value="">Sélectionnez un candidat</option>
        {candidates.map(candidate => (
          <option key={candidate.id} value={candidate.id}>
            {candidate.name}
          </option>
        ))}
      </select>
      <button onClick={vote}>Voter</button>
    </div>
  );
};

export default Vote;
```

`src/components/Results.js`:

```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Results = () => {
  const [results, setResults] = useState([]);

  const fetchResults = async () => {
    const response = await axios.get('http://localhost:5000/votes');
    setResults(response.data);
  };

  useEffect(() => {
    fetchResults();
  }, []);

  return (
    <div>
      <h1>Résultats des votes</h1>
      <ul>
        {results.map(result => (
          <li key={result.id}>
            {result.name}: {result.voteCount} votes
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Results;
```

### 4. Configuration des appels API

Créez un fichier `src/api.js` pour centraliser les appels API:

```jsx
import axios from 'axios';

const API = axios.create({ baseURL: 'http://localhost:5000' });

export const register = (formData) => API.post('/auth/register', formData);
export const login = (formData) => API.post('/auth/login', formData);

export const fetchCandidates = () => API.get('/candidates');
export const addCandidate = (formData) => API.post('/candidates', formData);
export const deleteCandidate = (id) => API.delete(`/candidates/${id}`);

export const vote = (formData, token) => API.post('/votes', formData, {
  headers: { Authorization: `Bearer ${token}` }
});
export const fetchResults = () => API.get('/votes');
```

### 5. Finaliser le projet

Ajoutez un fichier `src/index.js` pour démarrer l'application:

```jsx
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
```

## Conclusion

Cette configuration de base vous permet de démarrer un projet de système de vote avec Node.js, React et MySQL. Assurez-vous de tester chaque fonctionnalité et d'apporter des ajustements en fonction de vos besoins spécifiques. N'hésitez pas à ajouter des fonctionnalités supplémentaires comme des graphiques pour les résultats, des notifications, etc.

Voici les scripts SQL nécessaires pour créer les tables `users`, `candidates`, et `votes` dans la base de données MySQL.

### Création de la base de données

```sql
CREATE DATABASE voting_system;
USE voting_system;
```

### Création des tables

#### Table `users`

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Table `candidates`

```sql
CREATE TABLE candidates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    photo VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Table `votes`

```sql
CREATE TABLE votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    candidate_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE
);
```

### Insérer des données d'exemple

Pour tester l'application, vous pouvez insérer des données d'exemple.

#### Insertion de données dans la table `users`

```sql
INSERT INTO users (username, password) VALUES ('user1', 'hashed_password1');
INSERT INTO users (username, password) VALUES ('user2', 'hashed_password2');
```

(Note : Les mots de passe doivent être hachés avant l'insertion.)

#### Insertion de données dans la table `candidates`

```sql
INSERT INTO candidates (name, photo) VALUES ('Candidate 1', 'photo_url_1');
INSERT INTO candidates (name, photo) VALUES ('Candidate 2', 'photo_url_2');
```

### Vérification des données

Pour vérifier que les tables ont été créées correctement et que les données d'exemple ont été insérées, vous pouvez utiliser les requêtes suivantes :

#### Vérification des utilisateurs

```sql
SELECT * FROM users;
```

#### Vérification des candidats

```sql
SELECT * FROM candidates;
```

#### Vérification des votes

```sql
SELECT * FROM votes;
```

Avec ces scripts SQL, vous devriez être en mesure de configurer votre base de données MySQL pour le système de vote. Assurez-vous que vos configurations environnementales sont correctes et que le serveur de base de données est en cours d'exécution avant de lancer l'application.


