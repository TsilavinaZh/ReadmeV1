Pour envoyer et recevoir des données avec HTML et JavaScript en utilisant la méthode `fetch`, vous pouvez suivre les étapes suivantes. 

### Envoyer des données avec `fetch`

1. **Préparer les données à envoyer** : Il peut s'agir d'un objet JavaScript que vous convertissez en JSON.
2. **Utiliser la fonction `fetch`** : Spécifiez l'URL de destination, la méthode HTTP (par exemple POST) et le corps de la requête.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fetch Example</title>
</head>
<body>
    <button id="sendDataBtn">Envoyer des données</button>

    <script>
        document.getElementById('sendDataBtn').addEventListener('click', function() {
            const data = {
                name: 'John Doe',
                email: 'john.doe@example.com'
            };

            fetch('https://example.com/api/data', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
            })
            .catch((error) => {
                console.error('Error:', error);
            });
        });
    </script>
</body>
</html>
```

### Recevoir des données avec `fetch`

1. **Utiliser la fonction `fetch` pour effectuer une requête GET** : Il n'est pas nécessaire de spécifier la méthode si vous effectuez une requête GET car c'est la méthode par défaut.
2. **Traiter la réponse** : Convertissez la réponse en JSON et manipulez les données reçues.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fetch Example</title>
</head>
<body>
    <button id="getDataBtn">Recevoir des données</button>
    <div id="dataDisplay"></div>

    <script>
        document.getElementById('getDataBtn').addEventListener('click', function() {
            fetch('https://example.com/api/data')
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                document.getElementById('dataDisplay').innerText = JSON.stringify(data, null, 2);
            })
            .catch((error) => {
                console.error('Error:', error);
            });
        });
    </script>
</body>
</html>
```

### Notes importantes

- **Gestion des erreurs** : Assurez-vous de bien gérer les erreurs, comme montré dans les exemples avec `.catch()`.
- **En-têtes HTTP** : Lors de l'envoi de données, spécifiez correctement les en-têtes HTTP, notamment `Content-Type` si vous envoyez du JSON.
- **CORS (Cross-Origin Resource Sharing)** : Assurez-vous que le serveur autorise les requêtes venant de votre domaine si les requêtes sont effectuées vers un domaine différent.

Avec ces exemples, vous devriez être capable d'envoyer et de recevoir des données à l'aide de `fetch` en JavaScript.