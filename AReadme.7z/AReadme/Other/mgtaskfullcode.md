### Jour 1 : Authentification et sécurité

#### Backend

1. **Installer les dépendances nécessaires :**
   ```bash
   npm install express mysql2 bcryptjs jsonwebtoken cors
   ```

2. **Configurer Express et la base de données :**
   - **`app.js`**
     ```javascript
     const express = require('express');
     const cors = require('cors');
     const app = express();
     const db = require('./config/db');

     app.use(cors());
     app.use(express.json());

     // Importer les routes d'authentification
     const authRoutes = require('./routes/auth');
     app.use('/auth', authRoutes);

     const PORT = process.env.PORT || 5000;
     app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
     ```

   - **`config/db.js`**
     ```javascript
     const mysql = require('mysql2');

     const db = mysql.createConnection({
       host: 'localhost',
       user: 'root',
       password: 'password',
       database: 'mydatabase'
     });

     db.connect((err) => {
       if (err) throw err;
       console.log('MySQL Connected...');
     });

     module.exports = db;
     ```

3. **Créer les modèles :**
   - **`models/User.js`**
     ```javascript
     const db = require('../config/db');
     const bcrypt = require('bcryptjs');

     const User = {
       create: (username, password, email, callback) => {
         const hashedPassword = bcrypt.hashSync(password, 8);
         const query = 'INSERT INTO users (username, password, email) VALUES (?, ?, ?)';
         db.query(query, [username, hashedPassword, email], callback);
       },
       findByUsername: (username, callback) => {
         const query = 'SELECT * FROM users WHERE username = ?';
         db.query(query, [username], callback);
       }
     };

     module.exports = User;
     ```

4. **Créer les contrôleurs :**
   - **`controllers/AuthController.js`**
     ```javascript
     const User = require('../models/User');
     const bcrypt = require('bcryptjs');
     const jwt = require('jsonwebtoken');

     exports.register = (req, res) => {
       const { username, password, email } = req.body;
       User.create(username, password, email, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(201).send('User registered');
       });
     };

     exports.login = (req, res) => {
       const { username, password } = req.body;
       User.findByUsername(username, (err, users) => {
         if (err) return res.status(500).send('Server error');
         if (users.length === 0) return res.status(404).send('User not found');

         const user = users[0];
         const isValidPassword = bcrypt.compareSync(password, user.password);
         if (!isValidPassword) return res.status(401).send('Invalid password');

         const token = jwt.sign({ id: user.id }, 'secret', { expiresIn: '1h' });
         res.status(200).send({ auth: true, token });
       });
     };

     exports.logout = (req, res) => {
       res.status(200).send({ auth: false, token: null });
     };
     ```

5. **Créer les routes :**
   - **`routes/auth.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const authController = require('../controllers/AuthController');

     router.post('/register', authController.register);
     router.post('/login', authController.login);
     router.post('/logout', authController.logout);

     module.exports = router;
     ```

#### Base de données

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_roles (
    user_id INT,
    role VARCHAR(50),
    PRIMARY KEY (user_id, role),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### Frontend (React)

1. **Installer les dépendances nécessaires :**
   ```bash
   npx create-react-app frontend
   cd frontend
   npm install axios
   ```

2. **Configurer les composants :**
   - **`src/App.js`**
     ```javascript
     import React from 'react';
     import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
     import Login from './components/Login';
     import Register from './components/Register';

     function App() {
       return (
         <Router>
           <Switch>
             <Route path="/login" component={Login} />
             <Route path="/register" component={Register} />
           </Switch>
         </Router>
       );
     }

     export default App;
     ```

   - **`src/components/Login.js`**
     ```javascript
     import React, { useState } from 'react';
     import axios from 'axios';

     function Login() {
       const [username, setUsername] = useState('');
       const [password, setPassword] = useState('');

       const handleLogin = async () => {
         try {
           const res = await axios.post('http://localhost:5000/auth/login', { username, password });
           console.log('Token:', res.data.token);
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Login</h2>
           <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" />
           <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
           <button onClick={handleLogin}>Login</button>
         </div>
       );
     }

     export default Login;
     ```

   - **`src/components/Register.js`**
     ```javascript
     import React, { useState } from 'react';
     import axios from 'axios';

     function Register() {
       const [username, setUsername] = useState('');
       const [password, setPassword] = useState('');
       const [email, setEmail] = useState('');

       const handleRegister = async () => {
         try {
           await axios.post('http://localhost:5000/auth/register', { username, password, email });
           alert('User registered');
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Register</h2>
           <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" />
           <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
           <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
           <button onClick={handleRegister}>Register</button>
         </div>
       );
     }

     export default Register;
     ```

### Suite des jours

Je fournirai les détails pour chaque jour suivant étape par étape. Commençons par configurer et tester cette partie, puis nous pourrons avancer avec les fonctionnalités des jours suivants.


### Jour 2 : Gestion des projets et des tâches

#### Backend

1. **Installer les dépendances nécessaires :**
   ```bash
   npm install express mysql2 cors
   ```

2. **Configurer les modèles :**
   - **`models/Project.js`**
     ```javascript
     const db = require('../config/db');

     const Project = {
       create: (name, description, start_date, end_date, callback) => {
         const query = 'INSERT INTO projects (name, description, start_date, end_date) VALUES (?, ?, ?, ?)';
         db.query(query, [name, description, start_date, end_date], callback);
       },
       getAll: (callback) => {
         const query = 'SELECT * FROM projects';
         db.query(query, callback);
       },
       getById: (id, callback) => {
         const query = 'SELECT * FROM projects WHERE id = ?';
         db.query(query, [id], callback);
       },
       update: (id, name, description, start_date, end_date, callback) => {
         const query = 'UPDATE projects SET name = ?, description = ?, start_date = ?, end_date = ? WHERE id = ?';
         db.query(query, [name, description, start_date, end_date, id], callback);
       },
       delete: (id, callback) => {
         const query = 'DELETE FROM projects WHERE id = ?';
         db.query(query, [id], callback);
       }
     };

     module.exports = Project;
     ```

   - **`models/Task.js`**
     ```javascript
     const db = require('../config/db');

     const Task = {
       create: (project_id, title, description, status, due_date, callback) => {
         const query = 'INSERT INTO tasks (project_id, title, description, status, due_date) VALUES (?, ?, ?, ?, ?)';
         db.query(query, [project_id, title, description, status, due_date], callback);
       },
       getByProjectId: (project_id, callback) => {
         const query = 'SELECT * FROM tasks WHERE project_id = ?';
         db.query(query, [project_id], callback);
       },
       getById: (id, callback) => {
         const query = 'SELECT * FROM tasks WHERE id = ?';
         db.query(query, [id], callback);
       },
       update: (id, title, description, status, due_date, callback) => {
         const query = 'UPDATE tasks SET title = ?, description = ?, status = ?, due_date = ? WHERE id = ?';
         db.query(query, [title, description, status, due_date, id], callback);
       },
       delete: (id, callback) => {
         const query = 'DELETE FROM tasks WHERE id = ?';
         db.query(query, [id], callback);
       }
     };

     module.exports = Task;
     ```

3. **Créer les contrôleurs :**
   - **`controllers/ProjectController.js`**
     ```javascript
     const Project = require('../models/Project');

     exports.createProject = (req, res) => {
       const { name, description, start_date, end_date } = req.body;
       Project.create(name, description, start_date, end_date, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(201).send('Project created');
       });
     };

     exports.getAllProjects = (req, res) => {
       Project.getAll((err, projects) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(projects);
       });
     };

     exports.getProjectById = (req, res) => {
       const { id } = req.params;
       Project.getById(id, (err, project) => {
         if (err) return res.status(500).send('Server error');
         if (project.length === 0) return res.status(404).send('Project not found');
         res.status(200).send(project[0]);
       });
     };

     exports.updateProject = (req, res) => {
       const { id } = req.params;
       const { name, description, start_date, end_date } = req.body;
       Project.update(id, name, description, start_date, end_date, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Project updated');
       });
     };

     exports.deleteProject = (req, res) => {
       const { id } = req.params;
       Project.delete(id, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Project deleted');
       });
     };
     ```

   - **`controllers/TaskController.js`**
     ```javascript
     const Task = require('../models/Task');

     exports.createTask = (req, res) => {
       const { project_id, title, description, status, due_date } = req.body;
       Task.create(project_id, title, description, status, due_date, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(201).send('Task created');
       });
     };

     exports.getTasksByProjectId = (req, res) => {
       const { id } = req.params;
       Task.getByProjectId(id, (err, tasks) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(tasks);
       });
     };

     exports.getTaskById = (req, res) => {
       const { id } = req.params;
       Task.getById(id, (err, task) => {
         if (err) return res.status(500).send('Server error');
         if (task.length === 0) return res.status(404).send('Task not found');
         res.status(200).send(task[0]);
       });
     };

     exports.updateTask = (req, res) => {
       const { id } = req.params;
       const { title, description, status, due_date } = req.body;
       Task.update(id, title, description, status, due_date, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Task updated');
       });
     };

     exports.deleteTask = (req, res) => {
       const { id } = req.params;
       Task.delete(id, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Task deleted');
       });
     };
     ```

4. **Créer les routes :**
   - **`routes/project.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const projectController = require('../controllers/ProjectController');

     router.post('/', projectController.createProject);
     router.get('/', projectController.getAllProjects);
     router.get('/:id', projectController.getProjectById);
     router.put('/:id', projectController.updateProject);
     router.delete('/:id', projectController.deleteProject);

     module.exports = router;
     ```

   - **`routes/task.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const taskController = require('../controllers/TaskController');

     router.post('/', taskController.createTask);
     router.get('/project/:id', taskController.getTasksByProjectId);
     router.get('/:id', taskController.getTaskById);
     router.put('/:id', taskController.updateTask);
     router.delete('/:id', taskController.deleteTask);

     module.exports = router;
     ```

5. **Mettre à jour le fichier `app.js` pour inclure les nouvelles routes :**
   ```javascript
   const express = require('express');
   const cors = require('cors');
   const app = express();
   const db = require('./config/db');

   app.use(cors());
   app.use(express.json());

   // Importer les routes
   const authRoutes = require('./routes/auth');
   const projectRoutes = require('./routes/project');
   const taskRoutes = require('./routes/task');

   app.use('/auth', authRoutes);
   app.use('/projects', projectRoutes);
   app.use('/tasks', taskRoutes);

   const PORT = process.env.PORT || 5000;
   app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
   ```

#### Base de données

```sql
CREATE TABLE projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    start_date DATE,
    end_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    status ENUM('pending', 'in_progress', 'completed') DEFAULT 'pending',
    due_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id)
);
```

#### Frontend (React)

1. **Installer les dépendances nécessaires :**
   ```bash
   npm install axios react-router-dom
   ```

2. **Configurer les composants :**
   - **`src/components/Projects.js`**

 ```javascript
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Projects() {
  const [projects, setProjects] = useState([]);
  const [newProject, setNewProject] = useState({ name: '', description: '', start_date: '', end_date: '' });

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const res = await axios.get('http://localhost:5000/projects');
        setProjects(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchProjects();
  }, []);

  const handleCreateProject = async () => {
    try {
      await axios.post('http://localhost:5000/projects', newProject);
      setNewProject({ name: '', description: '', start_date: '', end_date: '' });
      const res = await axios.get('http://localhost:5000/projects');
      setProjects(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <h2>Projects</h2>
      <input type="text" value={newProject.name} onChange={(e) => setNewProject({ ...newProject, name: e.target.value })} placeholder="Name" />
      <input type="text" value={newProject.description} onChange={(e) => setNewProject({ ...newProject, description: e.target.value })} placeholder="Description" />
      <input type="date" value={newProject.start_date} onChange={(e) => setNewProject({ ...newProject, start_date: e.target.value })} placeholder="Start Date" />
      <input type="date" value={newProject.end_date} onChange={(e) => setNewProject({ ...newProject, end_date: e.target.value })} placeholder="End Date" />
      <button onClick={handleCreateProject}>Create Project</button>
      <ul>
        {projects.map((project) => (
          <li key={project.id}>{project.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default Projects;
```

- **`src/components/Tasks.js`**
  ```javascript
  import React, { useState, useEffect } from 'react';
  import axios from 'axios';

  function Tasks({ projectId }) {
    const [tasks, setTasks] = useState([]);
    const [newTask, setNewTask] = useState({ title: '', description: '', status: 'pending', due_date: '' });

    useEffect(() => {
      const fetchTasks = async () => {
        try {
          const res = await axios.get(`http://localhost:5000/tasks/project/${projectId}`);
          setTasks(res.data);
        } catch (err) {
          console.error(err);
        }
      };
      fetchTasks();
    }, [projectId]);

    const handleCreateTask = async () => {
      try {
        await axios.post('http://localhost:5000/tasks', { ...newTask, project_id: projectId });
        setNewTask({ title: '', description: '', status: 'pending', due_date: '' });
        const res = await axios.get(`http://localhost:5000/tasks/project/${projectId}`);
        setTasks(res.data);
      } catch (err) {
        console.error(err);
      }
    };

    return (
      <div>
        <h2>Tasks</h2>
        <input type="text" value={newTask.title} onChange={(e) => setNewTask({ ...newTask, title: e.target.value })} placeholder="Title" />
        <input type="text" value={newTask.description} onChange={(e) => setNewTask({ ...newTask, description: e.target.value })} placeholder="Description" />
        <select value={newTask.status} onChange={(e) => setNewTask({ ...newTask, status: e.target.value })}>
          <option value="pending">Pending</option>
          <option value="in_progress">In Progress</option>
          <option value="completed">Completed</option>
        </select>
        <input type="date" value={newTask.due_date} onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })} placeholder="Due Date" />
        <button onClick={handleCreateTask}>Create Task</button>
        <ul>
          {tasks.map((task) => (
            <li key={task.id}>{task.title}</li>
          ))}
        </ul>
      </div>
    );
  }

  export default Tasks;
  ```

3. **Mettre à jour le fichier `src/App.js` pour inclure les nouvelles pages :**
   ```javascript
   import React from 'react';
   import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
   import Login from './components/Login';
   import Register from './components/Register';
   import Projects from './components/Projects';
   import Tasks from './components/Tasks';

   function App() {
     return (
       <Router>
         <Switch>
           <Route path="/login" component={Login} />
           <Route path="/register" component={Register} />
           <Route path="/projects" component={Projects} />
           <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
         </Switch>
       </Router>
     );
   }

   export default App;
   ```

### Jour 3 : Calendrier et planification

#### Backend

1. **Configurer les modèles :**
   - **`models/Event.js`**
     ```javascript
     const db = require('../config/db');

     const Event = {
       create: (title, description, start_datetime, end_datetime, callback) => {
         const query = 'INSERT INTO events (title, description, start_datetime, end_datetime) VALUES (?, ?, ?, ?)';
         db.query(query, [title, description, start_datetime, end_datetime], callback);
       },
       getAll: (callback) => {
         const query = 'SELECT * FROM events';
         db.query(query, callback);
       },
       getById: (id, callback) => {
         const query = 'SELECT * FROM events WHERE id = ?';
         db.query(query, [id], callback);
       },
       update: (id, title, description, start_datetime, end_datetime, callback) => {
         const query = 'UPDATE events SET title = ?, description = ?, start_datetime = ?, end_datetime = ? WHERE id = ?';
         db.query(query, [title, description, start_datetime, end_datetime, id], callback);
       },
       delete: (id, callback) => {
         const query = 'DELETE FROM events WHERE id = ?';
         db.query(query, [id], callback);
       }
     };

     module.exports = Event;
     ```

   - **`models/EventParticipant.js`**
     ```javascript
     const db = require('../config/db');

     const EventParticipant = {
       addParticipant: (event_id, user_id, callback) => {
         const query = 'INSERT INTO event_participants (event_id, user_id) VALUES (?, ?)';
         db.query(query, [event_id, user_id], callback);
       },
       getParticipants: (event_id, callback) => {
         const query = 'SELECT * FROM event_participants WHERE event_id = ?';
         db.query(query, [event_id], callback);
       }
     };

     module.exports = EventParticipant;
     ```

2. **Créer les contrôleurs :**
   - **`controllers/CalendarController.js`**
     ```javascript
     const Event = require('../models/Event');
     const EventParticipant = require('../models/EventParticipant');

     exports.createEvent = (req, res) => {
       const { title, description, start_datetime, end_datetime } = req.body;
       Event.create(title, description, start_datetime, end_datetime, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(201).send('Event created');
       });
     };

     exports.getAllEvents = (req, res) => {
       Event.getAll((err, events) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(events);
       });
     };

     exports.getEventById = (req, res) => {
       const { id } = req.params;
       Event.getById(id, (err, event) => {
         if (err) return res.status(500).send('Server error');
         if (event.length === 0) return res.status(404).send('Event not found');
         res.status(200).send(event[0]);
       });
     };

     exports.updateEvent = (req, res) => {
       const { id } = req.params;
       const { title, description, start_datetime, end_datetime } = req.body;
       Event.update(id, title, description, start_datetime, end_datetime, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Event updated');
       });
     };

     exports.deleteEvent = (req, res) => {
       const { id } = req.params;
       Event.delete(id, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Event deleted');
       });
     };

     exports.addParticipant = (req, res) => {
       const { event_id, user_id } = req.body;
       EventParticipant.addParticipant(event_id

```javascript
, user_id, (err, result) => {
    if (err) return res.status(500).send('Server error');
    res.status(201).send('Participant added');
  });
};

exports.getParticipants = (req, res) => {
  const { event_id } = req.params;
  EventParticipant.getParticipants(event_id, (err, participants) => {
    if (err) return res.status(500).send('Server error');
    res.status(200).send(participants);
  });
};
```

3. **Créer les routes :**
   - **`routes/calendar.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const calendarController = require('../controllers/CalendarController');

     router.post('/events', calendarController.createEvent);
     router.get('/events', calendarController.getAllEvents);
     router.get('/events/:id', calendarController.getEventById);
     router.put('/events/:id', calendarController.updateEvent);
     router.delete('/events/:id', calendarController.deleteEvent);
     router.post('/events/participants', calendarController.addParticipant);
     router.get('/events/:event_id/participants', calendarController.getParticipants);

     module.exports = router;
     ```

4. **Mettre à jour le fichier `app.js` pour inclure les nouvelles routes :**
   ```javascript
   const express = require('express');
   const cors = require('cors');
   const app = express();
   const db = require('./config/db');

   app.use(cors());
   app.use(express.json());

   // Importer les routes
   const authRoutes = require('./routes/auth');
   const projectRoutes = require('./routes/project');
   const taskRoutes = require('./routes/task');
   const calendarRoutes = require('./routes/calendar');

   app.use('/auth', authRoutes);
   app.use('/projects', projectRoutes);
   app.use('/tasks', taskRoutes);
   app.use('/calendar', calendarRoutes);

   const PORT = process.env.PORT || 5000;
   app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
   ```

#### Base de données

```sql
CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    start_datetime DATETIME,
    end_datetime DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE event_participants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT,
    user_id INT,
    FOREIGN KEY (event_id) REFERENCES events(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### Frontend (React)

1. **Installer les dépendances nécessaires :**
   ```bash
   npm install react-calendar
   ```

2. **Configurer les composants :**
   - **`src/components/Calendar.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import Calendar from 'react-calendar';
     import axios from 'axios';

     function EventCalendar() {
       const [events, setEvents] = useState([]);
       const [newEvent, setNewEvent] = useState({ title: '', description: '', start_datetime: '', end_datetime: '' });

       useEffect(() => {
         const fetchEvents = async () => {
           try {
             const res = await axios.get('http://localhost:5000/calendar/events');
             setEvents(res.data);
           } catch (err) {
             console.error(err);
           }
         };
         fetchEvents();
       }, []);

       const handleCreateEvent = async () => {
         try {
           await axios.post('http://localhost:5000/calendar/events', newEvent);
           setNewEvent({ title: '', description: '', start_datetime: '', end_datetime: '' });
           const res = await axios.get('http://localhost:5000/calendar/events');
           setEvents(res.data);
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Calendar</h2>
           <input type="text" value={newEvent.title} onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })} placeholder="Title" />
           <input type="text" value={newEvent.description} onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })} placeholder="Description" />
           <input type="datetime-local" value={newEvent.start_datetime} onChange={(e) => setNewEvent({ ...newEvent, start_datetime: e.target.value })} placeholder="Start DateTime" />
           <input type="datetime-local" value={newEvent.end_datetime} onChange={(e) => setNewEvent({ ...newEvent, end_datetime: e.target.value })} placeholder="End DateTime" />
           <button onClick={handleCreateEvent}>Create Event</button>
           <Calendar
             value={new Date()}
             tileContent={({ date, view }) => {
               const eventDates = events.filter(event => new Date(event.start_datetime).toDateString() === date.toDateString());
               return eventDates.length > 0 ? <div>{eventDates[0].title}</div> : null;
             }}
           />
         </div>
       );
     }

     export default EventCalendar;
     ```

2. **Mettre à jour le fichier `src/App.js` pour inclure la nouvelle page :**
   ```javascript
   import React from 'react';
   import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
   import Login from './components/Login';
   import Register from './components/Register';
   import Projects from './components/Projects';
   import Tasks from './components/Tasks';
   import EventCalendar from './components/Calendar';

   function App() {
     return (
       <Router>
         <Switch>
           <Route path="/login" component={Login} />
           <Route path="/register" component={Register} />
           <Route path="/projects" component={Projects} />
           <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
           <Route path="/calendar" component={EventCalendar} />
         </Switch>
       </Router>
     );
   }

   export default App;
   ```

Cela couvre les étapes principales pour ajouter la gestion des projets, des tâches, ainsi que la gestion du calendrier et des événements pour les trois premiers jours de votre projet. Voulez-vous continuer avec les étapes pour les jours suivants?


### Jour 4 : Communication et collaboration (chat en temps réel)

#### Backend

1. **Configurer les modèles :**
   - **`models/ChatRoom.js`**
     ```javascript
     const db = require('../config/db');

     const ChatRoom = {
       create: (name, callback) => {
         const query = 'INSERT INTO chat_rooms (name) VALUES (?)';
         db.query(query, [name], callback);
       },
       getAll: (callback) => {
         const query = 'SELECT * FROM chat_rooms';
         db.query(query, callback);
       }
     };

     module.exports = ChatRoom;
     ```

   - **`models/ChatMessage.js`**
     ```javascript
     const db = require('../config/db');

     const ChatMessage = {
       create: (room_id, user_id, message, callback) => {
         const query = 'INSERT INTO chat_messages (room_id, user_id, message) VALUES (?, ?, ?)';
         db.query(query, [room_id, user_id, message], callback);
       },
       getByRoomId: (room_id, callback) => {
         const query = 'SELECT * FROM chat_messages WHERE room_id = ?';
         db.query(query, [room_id], callback);
       }
     };

     module.exports = ChatMessage;
     ```

2. **Créer les contrôleurs :**
   - **`controllers/ChatController.js`**
     ```javascript
     const ChatRoom = require('../models/ChatRoom');
     const ChatMessage = require('../models/ChatMessage');

     exports.createRoom = (req, res) => {
       const { name } = req.body;
       ChatRoom.create(name, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(201).send('Chat room created');
       });
     };

     exports.getAllRooms = (req, res) => {
       ChatRoom.getAll((err, rooms) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(rooms);
       });
     };

     exports.createMessage = (req, res) => {
       const { room_id, user_id, message } = req.body;
       ChatMessage.create(room_id, user_id, message, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(201).send('Message sent');
       });
     };

     exports.getMessagesByRoomId = (req, res) => {
       const { room_id } = req.params;
       ChatMessage.getByRoomId(room_id, (err, messages) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(messages);
       });
     };
     ```

3. **Créer les routes :**
   - **`routes/chat.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const chatController = require('../controllers/ChatController');

     router.post('/rooms', chatController.createRoom);
     router.get('/rooms', chatController.getAllRooms);
     router.post('/rooms/:id/messages', chatController.createMessage);
     router.get('/rooms/:id/messages', chatController.getMessagesByRoomId);

     module.exports = router;
     ```

4. **Mettre à jour le fichier `app.js` pour inclure les nouvelles routes :**
   ```javascript
   const express = require('express');
   const cors = require('cors');
   const app = express();
   const db = require('./config/db');

   app.use(cors());
   app.use(express.json());

   // Importer les routes
   const authRoutes = require('./routes/auth');
   const projectRoutes = require('./routes/project');
   const taskRoutes = require('./routes/task');
   const calendarRoutes = require('./routes/calendar');
   const chatRoutes = require('./routes/chat');

   app.use('/auth', authRoutes);
   app.use('/projects', projectRoutes);
   app.use('/tasks', taskRoutes);
   app.use('/calendar', calendarRoutes);
   app.use('/chat', chatRoutes);

   const PORT = process.env.PORT || 5000;
   app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
   ```

#### Base de données

```sql
CREATE TABLE chat_rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE chat_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT,
    user_id INT,
    message TEXT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES chat_rooms(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### Frontend (React)

1. **Configurer les composants :**
   - **`src/components/ChatRooms.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import axios from 'axios';

     function ChatRooms() {
       const [rooms, setRooms] = useState([]);
       const [newRoom, setNewRoom] = useState('');

       useEffect(() => {
         const fetchRooms = async () => {
           try {
             const res = await axios.get('http://localhost:5000/chat/rooms');
             setRooms(res.data);
           } catch (err) {
             console.error(err);
           }
         };
         fetchRooms();
       }, []);

       const handleCreateRoom = async () => {
         try {
           await axios.post('http://localhost:5000/chat/rooms', { name: newRoom });
           setNewRoom('');
           const res = await axios.get('http://localhost:5000/chat/rooms');
           setRooms(res.data);
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Chat Rooms</h2>
           <input type="text" value={newRoom} onChange={(e) => setNewRoom(e.target.value)} placeholder="Room Name" />
           <button onClick={handleCreateRoom}>Create Room</button>
           <ul>
             {rooms.map((room) => (
               <li key={room.id}>{room.name}</li>
             ))}
           </ul>
         </div>
       );
     }

     export default ChatRooms;
     ```

   - **`src/components/ChatMessages.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import axios from 'axios';

     function ChatMessages({ roomId }) {
       const [messages, setMessages] = useState([]);
       const [newMessage, setNewMessage] = useState('');

       useEffect(() => {
         const fetchMessages = async () => {
           try {
             const res = await axios.get(`http://localhost:5000/chat/rooms/${roomId}/messages`);
             setMessages(res.data);
           } catch (err) {
             console.error(err);
           }
         };
         fetchMessages();
       }, [roomId]);

       const handleSendMessage = async () => {
         try {
           await axios.post(`http://localhost:5000/chat/rooms/${roomId}/messages`, { message: newMessage, user_id: 1 }); // user_id should be dynamically set
           setNewMessage('');
           const res = await axios.get(`http://localhost:5000/chat/rooms/${roomId}/messages`);
           setMessages(res.data);
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Chat Messages</h2>
           <input type="text" value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Message" />
           <button onClick={handleSendMessage}>Send Message</button>
           <ul>
             {messages.map((message) => (
               <li key={message.id}>{message.message}</li>
             ))}
           </ul>
         </div>
       );
     }

     export default ChatMessages;
     ```

2. **Mettre à jour le fichier `src/App.js` pour inclure les nouvelles pages :**
   ```javascript
   import React from 'react';
   import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
   import Login from './components/Login';
   import Register from './components/Register';
   import Projects from './components/Projects';
   import Tasks from './components/Tasks';
   import EventCalendar from './components/Calendar';
   import ChatRooms from './components/ChatRooms';
   import ChatMessages from './components/ChatMessages';

   function App() {
     return (
       <Router>
         <Switch>
           <Route path="/login" component={Login} />
           <Route path="/register" component={Register} />
           <Route path="/projects" component={Projects} />
           <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
           <Route path="/calendar" component={EventCalendar} />
           <Route path="/chat/rooms" component={ChatRooms} />
           <Route path="/chat/rooms/:id/messages" component={({ match }) => <ChatMessages roomId={match.params.id} />} />
         </Switch>
       </Router>
     );
   }

   export default App;
   ```

### Jour 5 : Gestion des documents et des fichiers

#### Backend

1. **Configurer les modèles :**
   - **`models/File.js`**
     ```javascript
     const db = require('../config/db');

     const File = {
       create: (user_id, name, path, callback) => {
        

```javascript
const query = 'INSERT INTO files (user_id, name, path) VALUES (?, ?, ?)';
         db.query(query, [user_id, name, path], callback);
       },
       getAll: (callback) => {
         const query = 'SELECT * FROM files';
         db.query(query, callback);
       },
       getById: (id, callback) => {
         const query = 'SELECT * FROM files WHERE id = ?';
         db.query(query, [id], callback);
       },
       delete: (id, callback) => {
         const query = 'DELETE FROM files WHERE id = ?';
         db.query(query, [id], callback);
       }
     };

     module.exports = File;
     ```

2. **Créer les contrôleurs :**
   - **`controllers/FileController.js`**
     ```javascript
     const File = require('../models/File');
     const path = require('path');
     const fs = require('fs');

     exports.uploadFile = (req, res) => {
       const { user_id } = req.body;
       const file = req.file;

       const filePath = path.join(__dirname, '..', 'uploads', file.filename);

       File.create(user_id, file.originalname, filePath, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(201).send('File uploaded');
       });
     };

     exports.getAllFiles = (req, res) => {
       File.getAll((err, files) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(files);
       });
     };

     exports.getFileById = (req, res) => {
       const { id } = req.params;
       File.getById(id, (err, file) => {
         if (err) return res.status(500).send('Server error');
         if (!file) return res.status(404).send('File not found');

         res.download(file.path, file.name);
       });
     };

     exports.deleteFile = (req, res) => {
       const { id } = req.params;
       File.getById(id, (err, file) => {
         if (err) return res.status(500).send('Server error');
         if (!file) return res.status(404).send('File not found');

         fs.unlink(file.path, (err) => {
           if (err) return res.status(500).send('Server error');

           File.delete(id, (err) => {
             if (err) return res.status(500).send('Server error');
             res.status(200).send('File deleted');
           });
         });
       });
     };
     ```

3. **Créer les routes :**
   - **`routes/file.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const fileController = require('../controllers/FileController');
     const multer = require('multer');
     const upload = multer({ dest: 'uploads/' });

     router.post('/', upload.single('file'), fileController.uploadFile);
     router.get('/', fileController.getAllFiles);
     router.get('/:id', fileController.getFileById);
     router.delete('/:id', fileController.deleteFile);

     module.exports = router;
     ```

4. **Mettre à jour le fichier `app.js` pour inclure les nouvelles routes :**
   ```javascript
   const express = require('express');
   const cors = require('cors');
   const app = express();
   const db = require('./config/db');

   app.use(cors());
   app.use(express.json());

   // Importer les routes
   const authRoutes = require('./routes/auth');
   const projectRoutes = require('./routes/project');
   const taskRoutes = require('./routes/task');
   const calendarRoutes = require('./routes/calendar');
   const chatRoutes = require('./routes/chat');
   const fileRoutes = require('./routes/file');

   app.use('/auth', authRoutes);
   app.use('/projects', projectRoutes);
   app.use('/tasks', taskRoutes);
   app.use('/calendar', calendarRoutes);
   app.use('/chat', chatRoutes);
   app.use('/files', fileRoutes);

   const PORT = process.env.PORT || 5000;
   app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
   ```

#### Base de données

```sql
CREATE TABLE files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    name VARCHAR(255) NOT NULL,
    path VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### Frontend (React)

1. **Configurer les composants :**
   - **`src/components/FileUpload.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import axios from 'axios';

     function FileUpload() {
       const [files, setFiles] = useState([]);
       const [selectedFile, setSelectedFile] = useState(null);

       useEffect(() => {
         const fetchFiles = async () => {
           try {
             const res = await axios.get('http://localhost:5000/files');
             setFiles(res.data);
           } catch (err) {
             console.error(err);
           }
         };
         fetchFiles();
       }, []);

       const handleFileChange = (e) => {
         setSelectedFile(e.target.files[0]);
       };

       const handleUpload = async () => {
         const formData = new FormData();
         formData.append('file', selectedFile);
         formData.append('user_id', 1); // user_id should be dynamically set

         try {
           await axios.post('http://localhost:5000/files', formData, {
             headers: {
               'Content-Type': 'multipart/form-data'
             }
           });
           const res = await axios.get('http://localhost:5000/files');
           setFiles(res.data);
           setSelectedFile(null);
         } catch (err) {
           console.error(err);
         }
       };

       const handleDelete = async (id) => {
         try {
           await axios.delete(`http://localhost:5000/files/${id}`);
           const res = await axios.get('http://localhost:5000/files');
           setFiles(res.data);
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>File Upload</h2>
           <input type="file" onChange={handleFileChange} />
           <button onClick={handleUpload}>Upload File</button>
           <ul>
             {files.map((file) => (
               <li key={file.id}>
                 {file.name}
                 <button onClick={() => handleDelete(file.id)}>Delete</button>
               </li>
             ))}
           </ul>
         </div>
       );
     }

     export default FileUpload;
     ```

2. **Mettre à jour le fichier `src/App.js` pour inclure les nouvelles pages :**
   ```javascript
   import React from 'react';
   import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
   import Login from './components/Login';
   import Register from './components/Register';
   import Projects from './components/Projects';
   import Tasks from './components/Tasks';
   import EventCalendar from './components/Calendar';
   import ChatRooms from './components/ChatRooms';
   import ChatMessages from './components/ChatMessages';
   import FileUpload from './components/FileUpload';

   function App() {
     return (
       <Router>
         <Switch>
           <Route path="/login" component={Login} />
           <Route path="/register" component={Register} />
           <Route path="/projects" component={Projects} />
           <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
           <Route path="/calendar" component={EventCalendar} />
           <Route path="/chat/rooms" component={ChatRooms} />
           <Route path="/chat/rooms/:id/messages" component={({ match }) => <ChatMessages roomId={match.params.id} />} />
           <Route path="/files" component={FileUpload} />
         </Switch>
       </Router>
     );
   }

   export default App;
   ```

### Jour 6 : Suivi du temps et des ressources

#### Backend

1. **Configurer les modèles :**
   - **`models/TimeEntry.js`**
     ```javascript
     const db = require('../config/db');

     const TimeEntry = {
       create: (user_id, project_id, description, start_time, end_time, callback) => {
         const query = 'INSERT INTO time_entries (user_id, project_id, description, start_time, end_time) VALUES (?, ?, ?, ?, ?)';
         db.query(query, [user_id, project_id, description, start_time, end_time], callback);
       },
       getAll: (callback) => {
         const query = 'SELECT * FROM time_entries';
         db.query(query, callback);
       },
       getById: (id, callback) => {
         const query = 'SELECT * FROM time_entries WHERE id = ?';
         db.query(query, [id], callback);
       },
       delete: (id, callback) => {
         const query = 'DELETE FROM time_entries WHERE id = ?';
         db.query(query, [id], callback);
       }
     };

     module.exports = TimeEntry;
     ```

2. **Créer les contrôleurs :**
   - **`controllers/TimeTrackingController.js`**
     ```javascript
     const TimeEntry = require('../models/

```javascript
TimeEntry');

     exports.createTimeEntry = (req, res) => {
       const { user_id, project_id, description, start_time, end_time } = req.body;

       TimeEntry.create(user_id, project_id, description, start_time, end_time, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(201).send('Time entry created');
       });
     };

     exports.getAllTimeEntries = (req, res) => {
       TimeEntry.getAll((err, timeEntries) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(timeEntries);
       });
     };

     exports.getTimeEntryById = (req, res) => {
       const { id } = req.params;
       TimeEntry.getById(id, (err, timeEntry) => {
         if (err) return res.status(500).send('Server error');
         if (!timeEntry) return res.status(404).send('Time entry not found');
         res.status(200).send(timeEntry);
       });
     };

     exports.deleteTimeEntry = (req, res) => {
       const { id } = req.params;
       TimeEntry.delete(id, (err) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Time entry deleted');
       });
     };
     ```

3. **Créer les routes :**
   - **`routes/timeTracking.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const timeTrackingController = require('../controllers/TimeTrackingController');

     router.post('/', timeTrackingController.createTimeEntry);
     router.get('/', timeTrackingController.getAllTimeEntries);
     router.get('/:id', timeTrackingController.getTimeEntryById);
     router.delete('/:id', timeTrackingController.deleteTimeEntry);

     module.exports = router;
     ```

4. **Mettre à jour le fichier `app.js` pour inclure les nouvelles routes :**
   ```javascript
   const express = require('express');
   const cors = require('cors');
   const app = express();
   const db = require('./config/db');

   app.use(cors());
   app.use(express.json());

   // Importer les routes
   const authRoutes = require('./routes/auth');
   const projectRoutes = require('./routes/project');
   const taskRoutes = require('./routes/task');
   const calendarRoutes = require('./routes/calendar');
   const chatRoutes = require('./routes/chat');
   const fileRoutes = require('./routes/file');
   const timeTrackingRoutes = require('./routes/timeTracking');

   app.use('/auth', authRoutes);
   app.use('/projects', projectRoutes);
   app.use('/tasks', taskRoutes);
   app.use('/calendar', calendarRoutes);
   app.use('/chat', chatRoutes);
   app.use('/files', fileRoutes);
   app.use('/time-tracking', timeTrackingRoutes);

   const PORT = process.env.PORT || 5000;
   app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
   ```

#### Base de données

```sql
CREATE TABLE time_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    project_id INT,
    description TEXT,
    start_time DATETIME,
    end_time DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (project_id) REFERENCES projects(id)
);
```

#### Frontend (React)

1. **Configurer les composants :**
   - **`src/components/TimeTracking.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import axios from 'axios';

     function TimeTracking() {
       const [timeEntries, setTimeEntries] = useState([]);
       const [newTimeEntry, setNewTimeEntry] = useState({
         user_id: 1, // user_id should be dynamically set
         project_id: '',
         description: '',
         start_time: '',
         end_time: ''
       });

       useEffect(() => {
         const fetchTimeEntries = async () => {
           try {
             const res = await axios.get('http://localhost:5000/time-tracking');
             setTimeEntries(res.data);
           } catch (err) {
             console.error(err);
           }
         };
         fetchTimeEntries();
       }, []);

       const handleChange = (e) => {
         const { name, value } = e.target;
         setNewTimeEntry((prev) => ({
           ...prev,
           [name]: value
         }));
       };

       const handleSubmit = async () => {
         try {
           await axios.post('http://localhost:5000/time-tracking', newTimeEntry);
           const res = await axios.get('http://localhost:5000/time-tracking');
           setTimeEntries(res.data);
           setNewTimeEntry({
             user_id: 1,
             project_id: '',
             description: '',
             start_time: '',
             end_time: ''
           });
         } catch (err) {
           console.error(err);
         }
       };

       const handleDelete = async (id) => {
         try {
           await axios.delete(`http://localhost:5000/time-tracking/${id}`);
           const res = await axios.get('http://localhost:5000/time-tracking');
           setTimeEntries(res.data);
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Time Tracking</h2>
           <div>
             <input
               type="text"
               name="project_id"
               value={newTimeEntry.project_id}
               onChange={handleChange}
               placeholder="Project ID"
             />
             <input
               type="text"
               name="description"
               value={newTimeEntry.description}
               onChange={handleChange}
               placeholder="Description"
             />
             <input
               type="datetime-local"
               name="start_time"
               value={newTimeEntry.start_time}
               onChange={handleChange}
             />
             <input
               type="datetime-local"
               name="end_time"
               value={newTimeEntry.end_time}
               onChange={handleChange}
             />
             <button onClick={handleSubmit}>Add Time Entry</button>
           </div>
           <ul>
             {timeEntries.map((entry) => (
               <li key={entry.id}>
                 {entry.description} - {entry.start_time} to {entry.end_time}
                 <button onClick={() => handleDelete(entry.id)}>Delete</button>
               </li>
             ))}
           </ul>
         </div>
       );
     }

     export default TimeTracking;
     ```

2. **Mettre à jour le fichier `src/App.js` pour inclure les nouvelles pages :**
   ```javascript
   import React from 'react';
   import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
   import Login from './components/Login';
   import Register from './components/Register';
   import Projects from './components/Projects';
   import Tasks from './components/Tasks';
   import EventCalendar from './components/Calendar';
   import ChatRooms from './components/ChatRooms';
   import ChatMessages from './components/ChatMessages';
   import FileUpload from './components/FileUpload';
   import TimeTracking from './components/TimeTracking';

   function App() {
     return (
       <Router>
         <Switch>
           <Route path="/login" component={Login} />
           <Route path="/register" component={Register} />
           <Route path="/projects" component={Projects} />
           <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
           <Route path="/calendar" component={EventCalendar} />
           <Route path="/chat/rooms" component={ChatRooms} />
           <Route path="/chat/rooms/:id/messages" component={({ match }) => <ChatMessages roomId={match.params.id} />} />
           <Route path="/files" component={FileUpload} />
           <Route path="/time-tracking" component={TimeTracking} />
         </Switch>
       </Router>
     );
   }

   export default App;
   ```

### Jour 7 : Notifications et alertes

#### Backend

1. **Configurer les modèles :**
   - **`models/Notification.js`**
     ```javascript
     const db = require('../config/db');

     const Notification = {
       create: (user_id, message, type, callback) => {
         const query = 'INSERT INTO notifications (user_id, message, type) VALUES (?, ?, ?)';
         db.query(query, [user_id, message, type], callback);
       },
       getAllByUserId: (user_id, callback) => {
         const query = 'SELECT * FROM notifications WHERE user_id = ?';
         db.query(query, [user_id], callback);
       },
       delete: (id, callback) => {
         const query = 'DELETE FROM notifications WHERE id = ?';
         db.query(query, [id], callback);
       }
     };

     module.exports = Notification;
     ```

2. **Créer les contrôleurs :**
   - **`controllers/NotificationController.js`**
     ```javascript
     const Notification = require('../models/Notification');

     exports.createNotification = (req, res) => {
       const { user_id, message, type } = req.body;

       Notification.create(user_id, message, type, (err, result) => {
         if (err) return res.status(500).send('Server error');
         res.status(201).send('Notification created');
       });
```javascript
     };

     exports.getAllNotificationsByUserId = (req, res) => {
       const { user_id } = req.params;
       Notification.getAllByUserId(user_id, (err, notifications) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(notifications);
       });
     };

     exports.deleteNotification = (req, res) => {
       const { id } = req.params;
       Notification.delete(id, (err) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Notification deleted');
       });
     };
     ```

3. **Créer les routes :**
   - **`routes/notification.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const notificationController = require('../controllers/NotificationController');

     router.post('/', notificationController.createNotification);
     router.get('/:user_id', notificationController.getAllNotificationsByUserId);
     router.delete('/:id', notificationController.deleteNotification);

     module.exports = router;
     ```

4. **Mettre à jour le fichier `app.js` pour inclure les nouvelles routes :**
   ```javascript
   const express = require('express');
   const cors = require('cors');
   const app = express();
   const db = require('./config/db');

   app.use(cors());
   app.use(express.json());

   // Importer les routes
   const authRoutes = require('./routes/auth');
   const projectRoutes = require('./routes/project');
   const taskRoutes = require('./routes/task');
   const calendarRoutes = require('./routes/calendar');
   const chatRoutes = require('./routes/chat');
   const fileRoutes = require('./routes/file');
   const timeTrackingRoutes = require('./routes/timeTracking');
   const notificationRoutes = require('./routes/notification');

   app.use('/auth', authRoutes);
   app.use('/projects', projectRoutes);
   app.use('/tasks', taskRoutes);
   app.use('/calendar', calendarRoutes);
   app.use('/chat', chatRoutes);
   app.use('/files', fileRoutes);
   app.use('/time-tracking', timeTrackingRoutes);
   app.use('/notifications', notificationRoutes);

   const PORT = process.env.PORT || 5000;
   app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
   ```

#### Base de données

```sql
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    message TEXT,
    type VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

#### Frontend (React)

1. **Configurer les composants :**
   - **`src/components/Notifications.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import axios from 'axios';

     function Notifications() {
       const [notifications, setNotifications] = useState([]);
       const user_id = 1; // user_id should be dynamically set

       useEffect(() => {
         const fetchNotifications = async () => {
           try {
             const res = await axios.get(`http://localhost:5000/notifications/${user_id}`);
             setNotifications(res.data);
           } catch (err) {
             console.error(err);
           }
         };
         fetchNotifications();
       }, [user_id]);

       const handleDelete = async (id) => {
         try {
           await axios.delete(`http://localhost:5000/notifications/${id}`);
           const res = await axios.get(`http://localhost:5000/notifications/${user_id}`);
           setNotifications(res.data);
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Notifications</h2>
           <ul>
             {notifications.map((notification) => (
               <li key={notification.id}>
                 {notification.message}
                 <button onClick={() => handleDelete(notification.id)}>Delete</button>
               </li>
             ))}
           </ul>
         </div>
       );
     }

     export default Notifications;
     ```

2. **Mettre à jour le fichier `src/App.js` pour inclure les nouvelles pages :**
   ```javascript
   import React from 'react';
   import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
   import Login from './components/Login';
   import Register from './components/Register';
   import Projects from './components/Projects';
   import Tasks from './components/Tasks';
   import EventCalendar from './components/Calendar';
   import ChatRooms from './components/ChatRooms';
   import ChatMessages from './components/ChatMessages';
   import FileUpload from './components/FileUpload';
   import TimeTracking from './components/TimeTracking';
   import Notifications from './components/Notifications';

   function App() {
     return (
       <Router>
         <Switch>
           <Route path="/login" component={Login} />
           <Route path="/register" component={Register} />
           <Route path="/projects" component={Projects} />
           <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
           <Route path="/calendar" component={EventCalendar} />
           <Route path="/chat/rooms" component={ChatRooms} />
           <Route path="/chat/rooms/:id/messages" component={({ match }) => <ChatMessages roomId={match.params.id} />} />
           <Route path="/files" component={FileUpload} />
           <Route path="/time-tracking" component={TimeTracking} />
           <Route path="/notifications" component={Notifications} />
         </Switch>
       </Router>
     );
   }

   export default App;
   ```

Avec cela, vous avez une application web complète avec une gestion des utilisateurs, des projets, des tâches, un calendrier, une fonctionnalité de chat, un système de téléchargement de fichiers, un suivi du temps, et des notifications.

### Prochaine étape

Assurez-vous que toutes les fonctionnalités sont bien intégrées et fonctionnent correctement. Vous pouvez maintenant tester l'application, faire des ajustements si nécessaire, et éventuellement ajouter des fonctionnalités supplémentaires selon vos besoins.



Pour ajouter des fonctionnalités en temps réel à votre projet (comme les notifications et le chat), vous pouvez utiliser Socket.io. Socket.io permet une communication bidirectionnelle en temps réel entre le client et le serveur.

### Intégration de Socket.io

#### Backend (Node.js + Express)

1. **Installer Socket.io :**
   ```bash
   npm install socket.io
   ```

2. **Mettre à jour le serveur pour utiliser Socket.io :**
   - **`app.js`**
     ```javascript
     const express = require('express');
     const cors = require('cors');
     const http = require('http');
     const socketIo = require('socket.io');
     const db = require('./config/db');

     const app = express();
     const server = http.createServer(app);
     const io = socketIo(server, {
       cors: {
         origin: "http://localhost:3000",
         methods: ["GET", "POST"]
       }
     });

     app.use(cors());
     app.use(express.json());

     // Importer les routes
     const authRoutes = require('./routes/auth');
     const projectRoutes = require('./routes/project');
     const taskRoutes = require('./routes/task');
     const calendarRoutes = require('./routes/calendar');
     const chatRoutes = require('./routes/chat');
     const fileRoutes = require('./routes/file');
     const timeTrackingRoutes = require('./routes/timeTracking');
     const notificationRoutes = require('./routes/notification');

     app.use('/auth', authRoutes);
     app.use('/projects', projectRoutes);
     app.use('/tasks', taskRoutes);
     app.use('/calendar', calendarRoutes);
     app.use('/chat', chatRoutes);
     app.use('/files', fileRoutes);
     app.use('/time-tracking', timeTrackingRoutes);
     app.use('/notifications', notificationRoutes);

     io.on('connection', (socket) => {
       console.log('New client connected');

       socket.on('disconnect', () => {
         console.log('Client disconnected');
       });
     });

     const PORT = process.env.PORT || 5000;
     server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
     ```

3. **Mettre à jour les contrôleurs pour émettre des événements Socket.io :**
   - **`controllers/ChatController.js`**
     ```javascript
     const ChatRoom = require('../models/ChatRoom');
     const ChatMessage = require('../models/ChatMessage');
     const io = require('../app').io;

     exports.createMessage = (req, res) => {
       const { room_id, user_id, message } = req.body;

       ChatMessage.create(room_id, user_id, message, (err, result) => {
         if (err) return res.status(500).send('Server error');

         io.to(room_id).emit('newMessage', { room_id, user_id, message });
         res.status(201).send('Message created');
       });
     };

     exports.getAllMessagesByRoomId = (req, res) => {
       const { room_id } = req.params;

       ChatMessage.getAllByRoomId(room_id, (err, messages) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(messages);
       });
     };
     ```

   - **`controllers/NotificationController.js`**
     ```javascript
     const Notification = require('../models/Notification');
     const io = require('../app').io;

     exports.createNotification = (req, res) => {
       const { user_id, message, type } = req.body;

       Notification.create(user_id, message, type, (err, result) => {
         if (err) return res.status(500).send('Server error');

         io.to(user_id).emit('newNotification', { message, type });
         res.status(201).send('Notification created');
       });
     };

     exports.getAllNotificationsByUserId = (req, res) => {
       const { user_id } = req.params;
       Notification.getAllByUserId(user_id, (err, notifications) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(notifications);
       });
     };

     exports.deleteNotification = (req, res) => {
       const { id } = req.params;
       Notification.delete(id, (err) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Notification deleted');
       });
     };
     ```

#### Frontend (React)

1. **Installer Socket.io client :**
   ```bash
   npm install socket.io-client
   ```

2. **Configurer le client Socket.io :**
   - **`src/components/ChatMessages.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import axios from 'axios';
     import io from 'socket.io-client';

     const socket = io('http://localhost:5000');

     function ChatMessages({ roomId }) {
       const [messages, setMessages] = useState([]);
       const [newMessage, setNewMessage] = useState('');

       useEffect(() => {
         const fetchMessages = async () => {
           try {
             const res = await axios.get(`http://localhost:5000/chat/rooms/${roomId}/messages`);
             setMessages(res.data);
           } catch (err) {
             console.error(err);
           }
         };
         fetchMessages();

         socket.emit('joinRoom', roomId);

         socket.on('newMessage', (message) => {
           setMessages((prevMessages) => [...prevMessages, message]);
         });

         return () => {
           socket.emit('leaveRoom', roomId);
         };
       }, [roomId]);

       const handleChange = (e) => {
         setNewMessage(e.target.value);
       };

       const handleSubmit = async () => {
         try {
           await axios.post('http://localhost:5000/chat/rooms/messages', {
             room_id: roomId,
             user_id: 1, // user_id should be dynamically set
             message: newMessage
           });
           setNewMessage('');
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Chat Room {roomId}</h2>
           <div>
             {messages.map((msg, index) => (
               <p key={index}>{msg.message}</p>
             ))}
           </div>
           <input type="text" value={newMessage} onChange={handleChange} />
           <button onClick={handleSubmit}>Send</button>
         </div>
       );
     }

     export default ChatMessages;
     ```

   - **`src/components/Notifications.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import axios from 'axios';
     import io from 'socket.io-client';

     const socket = io('http://localhost:5000');

     function Notifications() {
       const [notifications, setNotifications] = useState([]);
       const user_id = 1; // user_id should be dynamically set

       useEffect(() => {
         const fetchNotifications = async () => {
           try {
             const res = await axios.get(`http://localhost:5000/notifications/${user_id}`);
             setNotifications(res.data);
           } catch (err) {
             console.error(err);
           }
         };
         fetchNotifications();

         socket.emit('joinNotifications', user_id);

         socket.on('newNotification', (notification) => {
           setNotifications((prevNotifications) => [...prevNotifications, notification]);
         });

         return () => {
           socket.emit('leaveNotifications', user_id);
         };
       }, [user_id]);

       const handleDelete = async (id) => {
         try {
           await axios.delete(`http://localhost:5000/notifications/${id}`);
           const res = await axios.get(`http://localhost:5000/notifications/${user_id}`);
           setNotifications(res.data);
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Notifications</h2>
           <ul>
             {notifications.map((notification) => (
               <li key={notification.id}>
                 {notification.message}
                 <button onClick={() => handleDelete(notification.id)}>Delete</button>
               </li>
             ))}
           </ul>
         </div>
       );
     }

     export default Notifications;
     ```

Avec ces modifications, votre application supporte maintenant des fonctionnalités en temps réel pour le chat et les notifications, utilisant Socket.io pour la communication entre le client et le serveur.


Pour ajouter des sessions et un composant de déconnexion dans votre application, vous pouvez utiliser le package `express-session` pour gérer les sessions côté serveur et créer un composant de déconnexion côté client.

### Backend (Node.js + Express)

1. **Installer `express-session` :**
   ```bash
   npm install express-session
   ```

2. **Configurer `express-session` :**
   - **`app.js`**
     ```javascript
     const express = require('express');
     const cors = require('cors');
     const session = require('express-session');
     const http = require('http');
     const socketIo = require('socket.io');
     const db = require('./config/db');

     const app = express();
     const server = http.createServer(app);
     const io = socketIo(server, {
       cors: {
         origin: "http://localhost:3000",
         methods: ["GET", "POST"]
       }
     });

     app.use(cors());
     app.use(express.json());
     app.use(session({
       secret: 'your-secret-key', // Remplacez par votre clé secrète
       resave: false,
       saveUninitialized: true,
       cookie: { secure: false } // Mettre true si vous utilisez HTTPS
     }));

     // Importer les routes
     const authRoutes = require('./routes/auth');
     const projectRoutes = require('./routes/project');
     const taskRoutes = require('./routes/task');
     const calendarRoutes = require('./routes/calendar');
     const chatRoutes = require('./routes/chat');
     const fileRoutes = require('./routes/file');
     const timeTrackingRoutes = require('./routes/timeTracking');
     const notificationRoutes = require('./routes/notification');

     app.use('/auth', authRoutes);
     app.use('/projects', projectRoutes);
     app.use('/tasks', taskRoutes);
     app.use('/calendar', calendarRoutes);
     app.use('/chat', chatRoutes);
     app.use('/files', fileRoutes);
     app.use('/time-tracking', timeTrackingRoutes);
     app.use('/notifications', notificationRoutes);

     io.on('connection', (socket) => {
       console.log('New client connected');

       socket.on('disconnect', () => {
         console.log('Client disconnected');
       });
     });

     const PORT = process.env.PORT || 5000;
     server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
     ```

3. **Mettre à jour les routes d'authentification pour utiliser les sessions :**
   - **`routes/auth.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const bcrypt = require('bcrypt');
     const db = require('../config/db');

     router.post('/register', async (req, res) => {
       const { username, password, email } = req.body;
       const hashedPassword = await bcrypt.hash(password, 10);

       db.query(
         'INSERT INTO users (username, password, email) VALUES (?, ?, ?)',
         [username, hashedPassword, email],
         (err, result) => {
           if (err) return res.status(500).send('Server error');
           res.status(201).send('User registered');
         }
       );
     });

     router.post('/login', (req, res) => {
       const { username, password } = req.body;

       db.query(
         'SELECT * FROM users WHERE username = ?',
         [username],
         async (err, results) => {
           if (err) return res.status(500).send('Server error');
           if (results.length === 0) return res.status(401).send('User not found');

           const user = results[0];
           const isMatch = await bcrypt.compare(password, user.password);

           if (!isMatch) return res.status(401).send('Invalid credentials');

           req.session.user = user;
           res.status(200).send('User logged in');
         }
       );
     });

     router.post('/logout', (req, res) => {
       req.session.destroy(err => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('User logged out');
       });
     });

     module.exports = router;
     ```

#### Frontend (React)

1. **Créer le composant Logout :**
   - **`src/components/Logout.js`**
     ```javascript
     import React from 'react';
     import { useHistory } from 'react-router-dom';
     import axios from 'axios';

     function Logout() {
       const history = useHistory();

       const handleLogout = async () => {
         try {
           await axios.post('http://localhost:5000/auth/logout');
           history.push('/login');
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <button onClick={handleLogout}>Logout</button>
       );
     }

     export default Logout;
     ```

2. **Mettre à jour le fichier `src/App.js` pour inclure le composant de déconnexion :**
   ```javascript
   import React from 'react';
   import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
   import Login from './components/Login';
   import Register from './components/Register';
   import Projects from './components/Projects';
   import Tasks from './components/Tasks';
   import EventCalendar from './components/Calendar';
   import ChatRooms from './components/ChatRooms';
   import ChatMessages from './components/ChatMessages';
   import FileUpload from './components/FileUpload';
   import TimeTracking from './components/TimeTracking';
   import Notifications from './components/Notifications';
   import Logout from './components/Logout';

   function App() {
     return (
       <Router>
         <Switch>
           <Route path="/login" component={Login} />
           <Route path="/register" component={Register} />
           <Route path="/projects" component={Projects} />
           <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
           <Route path="/calendar" component={EventCalendar} />
           <Route path="/chat/rooms" component={ChatRooms} />
           <Route path="/chat/rooms/:id/messages" component={({ match }) => <ChatMessages roomId={match.params.id} />} />
           <Route path="/files" component={FileUpload} />
           <Route path="/time-tracking" component={TimeTracking} />
           <Route path="/notifications" component={Notifications} />
           <Route path="/logout" component={Logout} />
         </Switch>
       </Router>
     );
   }

   export default App;
   ```

Avec ces modifications, vous avez ajouté la gestion des sessions pour l'authentification et un composant de déconnexion côté client. Cela permet de maintenir l'état de la session utilisateur et de gérer correctement la déconnexion.

Voici une version corrigée et complète de l'application avec les fonctionnalités de sessions, de Socket.io et du composant de déconnexion.

### Backend (Node.js + Express)

1. **Installer les dépendances :**
   ```bash
   npm install express cors express-session bcrypt mysql socket.io
   ```

2. **Configurer le serveur avec `express-session` et `socket.io` :**
   - **`app.js`**
     ```javascript
     const express = require('express');
     const cors = require('cors');
     const session = require('express-session');
     const http = require('http');
     const socketIo = require('socket.io');
     const db = require('./config/db');

     const app = express();
     const server = http.createServer(app);
     const io = socketIo(server, {
       cors: {
         origin: "http://localhost:3000",
         methods: ["GET", "POST"]
       }
     });

     app.use(cors({
       origin: "http://localhost:3000",
       credentials: true
     }));
     app.use(express.json());
     app.use(session({
       secret: 'your-secret-key', // Remplacez par votre clé secrète
       resave: false,
       saveUninitialized: true,
       cookie: { secure: false } // Mettre true si vous utilisez HTTPS
     }));

     // Attach io to req so it can be accessed in routes
     app.use((req, res, next) => {
       req.io = io;
       next();
     });

     // Importer les routes
     const authRoutes = require('./routes/auth');
     const projectRoutes = require('./routes/project');
     const taskRoutes = require('./routes/task');
     const calendarRoutes = require('./routes/calendar');
     const chatRoutes = require('./routes/chat');
     const fileRoutes = require('./routes/file');
     const timeTrackingRoutes = require('./routes/timeTracking');
     const notificationRoutes = require('./routes/notification');

     app.use('/auth', authRoutes);
     app.use('/projects', projectRoutes);
     app.use('/tasks', taskRoutes);
     app.use('/calendar', calendarRoutes);
     app.use('/chat', chatRoutes);
     app.use('/files', fileRoutes);
     app.use('/time-tracking', timeTrackingRoutes);
     app.use('/notifications', notificationRoutes);

     io.on('connection', (socket) => {
       console.log('New client connected');

       socket.on('disconnect', () => {
         console.log('Client disconnected');
       });
     });

     const PORT = process.env.PORT || 5000;
     server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
     ```

3. **Configurer la base de données :**
   - **`config/db.js`**
     ```javascript
     const mysql = require('mysql');

     const db = mysql.createConnection({
       host: 'localhost',
       user: 'root',
       password: 'password',
       database: 'your_database_name'
     });

     db.connect((err) => {
       if (err) throw err;
       console.log('MySQL Connected...');
     });

     module.exports = db;
     ```

4. **Mettre à jour les routes d'authentification :**
   - **`routes/auth.js`**
     ```javascript
     const express = require('express');
     const router = express.Router();
     const bcrypt = require('bcrypt');
     const db = require('../config/db');

     router.post('/register', async (req, res) => {
       const { username, password, email } = req.body;
       const hashedPassword = await bcrypt.hash(password, 10);

       db.query(
         'INSERT INTO users (username, password, email) VALUES (?, ?, ?)',
         [username, hashedPassword, email],
         (err, result) => {
           if (err) return res.status(500).send('Server error');
           res.status(201).send('User registered');
         }
       );
     });

     router.post('/login', (req, res) => {
       const { username, password } = req.body;

       db.query(
         'SELECT * FROM users WHERE username = ?',
         [username],
         async (err, results) => {
           if (err) return res.status(500).send('Server error');
           if (results.length === 0) return res.status(401).send('User not found');

           const user = results[0];
           const isMatch = await bcrypt.compare(password, user.password);

           if (!isMatch) return res.status(401).send('Invalid credentials');

           req.session.user = user;
           res.status(200).send('User logged in');
         }
       );
     });

     router.post('/logout', (req, res) => {
       req.session.destroy(err => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('User logged out');
       });
     });

     module.exports = router;
     ```

5. **Mettre à jour les contrôleurs pour émettre des événements Socket.io :**
   - **`controllers/ChatController.js`**
     ```javascript
     const ChatMessage = require('../models/ChatMessage');

     exports.createMessage = (req, res) => {
       const { room_id, user_id, message } = req.body;

       ChatMessage.create(room_id, user_id, message, (err, result) => {
         if (err) return res.status(500).send('Server error');

         req.io.to(room_id).emit('newMessage', { room_id, user_id, message });
         res.status(201).send('Message created');
       });
     };

     exports.getAllMessagesByRoomId = (req, res) => {
       const { room_id } = req.params;

       ChatMessage.getAllByRoomId(room_id, (err, messages) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(messages);
       });
     };
     ```

   - **`controllers/NotificationController.js`**
     ```javascript
     const Notification = require('../models/Notification');

     exports.createNotification = (req, res) => {
       const { user_id, message, type } = req.body;

       Notification.create(user_id, message, type, (err, result) => {
         if (err) return res.status(500).send('Server error');

         req.io.to(user_id).emit('newNotification', { message, type });
         res.status(201).send('Notification created');
       });
     };

     exports.getAllNotificationsByUserId = (req, res) => {
       const { user_id } = req.params;
       Notification.getAllByUserId(user_id, (err, notifications) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send(notifications);
       });
     };

     exports.deleteNotification = (req, res) => {
       const { id } = req.params;
       Notification.delete(id, (err) => {
         if (err) return res.status(500).send('Server error');
         res.status(200).send('Notification deleted');
       });
     };
     ```

#### Frontend (React)

1. **Installer `socket.io-client` et `axios` :**
   ```bash
   npm install socket.io-client axios
   ```

2. **Configurer le client Socket.io et ajouter les fonctionnalités de déconnexion :**
   - **`src/components/ChatMessages.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import axios from 'axios';
     import io from 'socket.io-client';

     const socket = io('http://localhost:5000');

     function ChatMessages({ roomId }) {
       const [messages, setMessages] = useState([]);
       const [newMessage, setNewMessage] = useState('');

       useEffect(() => {
         const fetchMessages = async () => {
           try {
             const res = await axios.get(`http://localhost:5000/chat/rooms/${roomId}/messages`, { withCredentials: true });
             setMessages(res.data);
           } catch (err) {
             console.error(err);
           }
         };
         fetchMessages();

         socket.emit('joinRoom', roomId);

         socket.on('newMessage', (message) => {
           setMessages((prevMessages) => [...prevMessages, message]);
         });

         return () => {
           socket.emit('leaveRoom', roomId);
         };
       }, [roomId]);

       const handleChange = (e) => {
         setNewMessage(e.target.value);
       };

       const handleSubmit = async () => {
         try {
           await axios.post('http://localhost:5000/chat/rooms/messages', {
             room_id: roomId,
             user_id: 1, // user_id should be dynamically set
             message: newMessage
           }, { withCredentials: true });
           setNewMessage('');
         } catch (err) {
           console.error(err);
         }
       };

       return (
         <div>
           <h2>Chat Room {roomId}</h2>
           <div>
             {messages.map((msg, index) => (
               <p key={index}>{msg.message}</p>
             ))}
           </div>
           <input type="text" value={newMessage} onChange={handleChange} />
           <button onClick={handleSubmit}>Send</button>
         </div>
       );
     }

     export default ChatMessages;
     ```

   - **`src/components/Notifications.js`**
     ```javascript
     import React, { useState, useEffect } from 'react';
     import axios from 'axios';
     import io

Bien sûr, voici la suite de l'implémentation avec les fonctionnalités de notifications et de déconnexion dans votre application React.

### Notifications.js

```javascript
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import io from 'socket.io-client';

const socket = io('http://localhost:5000');

function Notifications() {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const res = await axios.get('http://localhost:5000/notifications', { withCredentials: true });
        setNotifications(res.data);
      } catch (err) {
        console.error(err);
      }
    };
    fetchNotifications();

    socket.on('newNotification', (notification) => {
      setNotifications((prevNotifications) => [...prevNotifications, notification]);
    });

    return () => {
      socket.off('newNotification');
    };
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/notifications/${id}`, { withCredentials: true });
      setNotifications((prevNotifications) => prevNotifications.filter((n) => n.id !== id));
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <h2>Notifications</h2>
      <ul>
        {notifications.map((notification) => (
          <li key={notification.id}>
            {notification.message} - {notification.type}
            <button onClick={() => handleDelete(notification.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Notifications;
```

### Logout.js

```javascript
import React from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';

function Logout() {
  const history = useHistory();

  const handleLogout = async () => {
    try {
      await axios.post('http://localhost:5000/auth/logout', {}, { withCredentials: true });
      history.push('/login');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <button onClick={handleLogout}>Logout</button>
  );
}

export default Logout;
```

### App.js

Mettez à jour le fichier `src/App.js` pour inclure le composant Notifications et Logout.

```javascript
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Projects from './components/Projects';
import Tasks from './components/Tasks';
import EventCalendar from './components/Calendar';
import ChatRooms from './components/ChatRooms';
import ChatMessages from './components/ChatMessages';
import FileUpload from './components/FileUpload';
import TimeTracking from './components/TimeTracking';
import Notifications from './components/Notifications';
import Logout from './components/Logout';

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route path="/projects" component={Projects} />
        <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
        <Route path="/calendar" component={EventCalendar} />
        <Route path="/chat/rooms" component={ChatRooms} />
        <Route path="/chat/rooms/:id/messages" component={({ match }) => <ChatMessages roomId={match.params.id} />} />
        <Route path="/files" component={FileUpload} />
        <Route path="/time-tracking" component={TimeTracking} />
        <Route path="/notifications" component={Notifications} />
        <Route path="/logout" component={Logout} />
      </Switch>
    </Router>
  );
}

export default App;
```

### Login.js (Mise à jour pour gérer les sessions)

```javascript
import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

  const handleLogin = async () => {
    try {
      await axios.post('http://localhost:5000/auth/login', { username, password }, { withCredentials: true });
      history.push('/projects');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}

export default Login;
```

### Register.js

```javascript
import React, { useState } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';

function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const history = useHistory();

  const handleRegister = async () => {
    try {
      await axios.post('http://localhost:5000/auth/register', { username, email, password }, { withCredentials: true });
      history.push('/login');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <h2>Register</h2>
      <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
      <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleRegister}>Register</button>
    </div>
  );
}

export default Register;
```

### Final Steps

1. **Démarrer le backend :**
   ```bash
   node app.js
   ```

2. **Démarrer le frontend :**
   ```bash
   npm start
   ```

Avec ces fichiers, votre application devrait être en mesure de gérer les sessions, l'authentification, les notifications en temps réel avec Socket.io, et fournir des fonctionnalités de déconnexion. Assurez-vous que votre backend est bien configuré pour accepter les requêtes avec les cookies de session (`withCredentials: true` dans Axios).


Il semble qu'il y a des modules manquants qui empêchent votre application de démarrer correctement. Voici les étapes à suivre pour corriger ces erreurs :

1. **Vérifiez la configuration de la base de données**: Assurez-vous que le fichier `db.js` existe dans le dossier `config` et est correctement configuré pour se connecter à votre base de données.

2. **Installez les dépendances manquantes**: Vous devez installer les modules `bcryptjs` et `socket.io`. Assurez-vous également que toutes les autres dépendances sont correctement installées.

3. **Créez les fichiers manquants**: Si certains fichiers sont mentionnés mais n'existent pas encore, vous devrez les créer.

### Étape 1: Vérifiez et créez la configuration de la base de données

Créez un fichier `db.js` dans le dossier `config` si ce n'est pas déjà fait.

**config/db.js**:
```javascript
const mysql = require('mysql2');
const dotenv = require('dotenv');

dotenv.config();

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = pool.promise();
```

Assurez-vous également que le fichier `.env` contient les bonnes informations de connexion à la base de données :
```env
DB_HOST=localhost
DB_USER=yourusername
DB_PASS=yourpassword
DB_NAME=yourdatabase
```

### Étape 2: Installez les dépendances manquantes

Dans votre terminal, assurez-vous d'être dans le répertoire `back-end` puis exécutez les commandes suivantes pour installer les dépendances manquantes:

```bash
npm install bcryptjs socket.io
```

### Étape 3: Structure du projet

Assurez-vous que votre projet est structuré comme suit :
```
back-end/
│
├── config/
│   └── db.js
│
├── controllers/
│   ├── AuthController.js
│   ├── ProjectController.js
│   ├── TaskController.js
│   ├── CalendarController.js
│   ├── ChatController.js
│   ├── FileController.js
│   ├── TimeTrackingController.js
│   └── NotificationController.js
│
├── models/
│   ├── User.js
│   ├── UserRole.js
│   ├── Project.js
│   ├── Task.js
│   ├── Event.js
│   ├── EventParticipant.js
│   ├── ChatRoom.js
│   ├── ChatMessage.js
│   ├── File.js
│   ├── TimeEntry.js
│   ├── Report.js
│   └── Notification.js
│
├── routes/
│   ├── auth.js
│   ├── projects.js
│   ├── tasks.js
│   ├── calendar.js
│   ├── chat.js
│   ├── files.js
│   ├── timeTracking.js
│   ├── notifications.js
│   └── reports.js
│
├── app.js
└── package.json
```

### Vérifiez et créez les fichiers nécessaires

**app.js**:
```javascript
const express = require('express');
const cors = require('cors');
const session = require('express-session');
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
const http = require('http');
const socketIo = require('socket.io');

const db = require('./config/db');
const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const taskRoutes = require('./routes/tasks');
const calendarRoutes = require('./routes/calendar');
const chatRoutes = require('./routes/chat');
const fileRoutes = require('./routes/files');
const timeTrackingRoutes = require('./routes/timeTracking');
const notificationRoutes = require('./routes/notifications');
const reportRoutes = require('./routes/reports');

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"],
    credentials: true
  }
});

app.use(cors({ origin: 'http://localhost:3000', credentials: true }));
app.use(bodyParser.json());
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}));

app.use('/auth', authRoutes);
app.use('/projects', projectRoutes);
app.use('/tasks', taskRoutes);
app.use('/calendar', calendarRoutes);
app.use('/chat', chatRoutes);
app.use('/files', fileRoutes);
app.use('/time-tracking', timeTrackingRoutes);
app.use('/notifications', notificationRoutes);
app.use('/reports', reportRoutes);

io.on('connection', (socket) => {
  console.log('a user connected');
  socket.on('disconnect', () => {
    console.log('user disconnected');
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
```

Avec cette structure et ces fichiers, votre application devrait être en mesure de démarrer correctement. N'hésitez pas à me signaler toute autre erreur ou problème que vous rencontrez.

Pour intégrer `react-router-dom` dans ce projet, nous allons structurer les routes de l'application React pour gérer la navigation entre différentes pages. Assurons-nous que chaque composant est correctement connecté à une route spécifique. Voici comment vous pouvez le faire :

1. **Installer `react-router-dom`** :
   Dans votre répertoire `front-end`, installez `react-router-dom` si ce n'est pas déjà fait :

   ```bash
   npm install react-router-dom
   ```

2. **Configurer les routes dans `App.js`** :
   Mettez à jour `src/App.js` pour inclure les routes et les composants associés.

```javascript
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Projects from './components/Projects';
import Tasks from './components/Tasks';
import EventCalendar from './components/Calendar';
import ChatRooms from './components/ChatRooms';
import ChatMessages from './components/ChatMessages';
import FileUpload from './components/FileUpload';
import TimeTracking from './components/TimeTracking';
import Notifications from './components/Notifications';
import Logout from './components/Logout';

function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li><a href="/projects">Projects</a></li>
            <li><a href="/calendar">Calendar</a></li>
            <li><a href="/chat/rooms">Chat</a></li>
            <li><a href="/files">Files</a></li>
            <li><a href="/time-tracking">Time Tracking</a></li>
            <li><a href="/notifications">Notifications</a></li>
            <li><a href="/logout">Logout</a></li>
          </ul>
        </nav>
        <Switch>
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/projects" component={Projects} />
          <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
          <Route path="/calendar" component={EventCalendar} />
          <Route path="/chat/rooms" component={ChatRooms} />
          <Route path="/chat/rooms/:id/messages" component={({ match }) => <ChatMessages roomId={match.params.id} />} />
          <Route path="/files" component={FileUpload} />
          <Route path="/time-tracking" component={TimeTracking} />
          <Route path="/notifications" component={Notifications} />
          <Route path="/logout" component={Logout} />
          <Route exact path="/" component={Projects} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
```

3. **Composants de navigation** :
   Chaque composant utilisé dans les routes doit être configuré pour afficher le contenu approprié. Voici un exemple pour le composant `Login` :

   **src/components/Login.js**:
   ```javascript
   import React, { useState } from 'react';
   import { useHistory } from 'react-router-dom';
   import axios from 'axios';

   function Login() {
     const [username, setUsername] = useState('');
     const [password, setPassword] = useState('');
     const history = useHistory();

     const handleLogin = async () => {
       try {
         await axios.post('http://localhost:5000/auth/login', { username, password }, { withCredentials: true });
         history.push('/projects');
       } catch (err) {
         console.error(err);
       }
     };

     return (
       <div>
         <h2>Login</h2>
         <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
         <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
         <button onClick={handleLogin}>Login</button>
       </div>
     );
   }

   export default Login;
   ```

4. **Naviguer entre les composants** :
   Utilisez les liens `<Link>` de `react-router-dom` pour permettre la navigation entre les pages sans recharger l'application entière.

   **src/App.js** (mise à jour de la navigation) :
   ```javascript
   import React from 'react';
   import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
   import Login from './components/Login';
   import Register from './components/Register';
   import Projects from './components/Projects';
   import Tasks from './components/Tasks';
   import EventCalendar from './components/Calendar';
   import ChatRooms from './components/ChatRooms';
   import ChatMessages from './components/ChatMessages';
   import FileUpload from './components/FileUpload';
   import TimeTracking from './components/TimeTracking';
   import Notifications from './components/Notifications';
   import Logout from './components/Logout';

   function App() {
     return (
       <Router>
         <div>
           <nav>
             <ul>
               <li><Link to="/projects">Projects</Link></li>
               <li><Link to="/calendar">Calendar</Link></li>
               <li><Link to="/chat/rooms">Chat</Link></li>
               <li><Link to="/files">Files</Link></li>
               <li><Link to="/time-tracking">Time Tracking</Link></li>
               <li><Link to="/notifications">Notifications</Link></li>
               <li><Link to="/logout">Logout</Link></li>
             </ul>
           </nav>
           <Switch>
             <Route path="/login" component={Login} />
             <Route path="/register" component={Register} />
             <Route path="/projects" component={Projects} />
             <Route path="/projects/:id/tasks" component={({ match }) => <Tasks projectId={match.params.id} />} />
             <Route path="/calendar" component={EventCalendar} />
             <Route path="/chat/rooms" component={ChatRooms} />
             <Route path="/chat/rooms/:id/messages" component={({ match }) => <ChatMessages roomId={match.params.id} />} />
             <Route path="/files" component={FileUpload} />
             <Route path="/time-tracking" component={TimeTracking} />
             <Route path="/notifications" component={Notifications} />
             <Route path="/logout" component={Logout} />
             <Route exact path="/" component={Projects} />
           </Switch>
         </div>
       </Router>
     );
   }

   export default App;
   ```

5. **Vérifiez le backend** : Assurez-vous que votre serveur backend est en cours d'exécution et que toutes les routes sont correctement définies.

Avec ces étapes, vous devriez avoir un projet React fonctionnel utilisant `react-router-dom` pour la navigation entre différentes pages et composants. Assurez-vous que votre backend est également correctement configuré et fonctionne comme attendu.
