Voici un tutoriel détaillé pour AngularJS, avec deux exemples de code pour chaque chapitre mentionné.

### 1. Bootstrapping

**Concept**: Bootstrapping consiste à démarrer votre application AngularJS. Cela implique généralement d'inclure AngularJS dans votre page et de définir un module AngularJS.

**Exemple 1: Bootstrapping avec un module simple**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My AngularJS App</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-app="myApp">
  <div ng-controller="MainController">
    {{ message }}
  </div>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.message = 'Hello, AngularJS!';
    });
  </script>
</body>
</html>
```

**Exemple 2: Bootstrapping manuel**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manual Bootstrapping</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body>
  <div ng-controller="MainController">
    {{ message }}
  </div>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.message = 'Manual Bootstrapping';
    });

    angular.element(document).ready(function() {
      angular.bootstrap(document, ['myApp']);
    });
  </script>
</body>
</html>
```

### 2. Static Template vs AngularJS Templates

**Concept**: Comparaison entre un modèle statique HTML et un modèle AngularJS dynamique.

**Exemple 1: Modèle statique**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Static Template</title>
</head>
<body>
  <h1>Welcome</h1>
  <p>This is a static message.</p>
</body>
</html>
```

**Exemple 2: Modèle AngularJS**

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>AngularJS Template</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-app="myApp">
  <div ng-controller="MainController">
    <h1>{{ title }}</h1>
    <p>{{ message }}</p>
  </div>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.title = 'Welcome';
      $scope.message = 'This message is dynamic with AngularJS!';
    });
  </script>
</body>
</html>
```

### 3. Components

**Concept**: Utilisation des composants pour réutiliser du code HTML et logique.

**Exemple 1: Composant de base**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Basic Component</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body>
  <hello-world></hello-world>

  <script>
    var app = angular.module('myApp', []);
    app.component('helloWorld', {
      template: '<h1>Hello World from a component!</h1>'
    });
  </script>
</body>
</html>
```

**Exemple 2: Composant avec contrôleur**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Component with Controller</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body>
  <greeting></greeting>

  <script>
    var app = angular.module('myApp', []);
    app.component('greeting', {
      template: '<h1>{{ $ctrl.greet }}</h1>',
      controller: function() {
        this.greet = 'Hello, AngularJS!';
      }
    });
  </script>
</body>
</html>
```

### 4. Directory and File Organization

**Concept**: Organisation des fichiers et dossiers dans un projet AngularJS.

**Exemple 1: Organisation de base**

```
myApp/
│
├── index.html
├── app.js
└── controllers/
    └── mainController.js
```

**Exemple 2: Organisation modulaire**

```
myApp/
│
├── index.html
├── app.js
├── components/
│   └── helloWorld/
│       ├── helloWorld.html
│       └── helloWorld.js
└── services/
    └── dataService.js
```

### 5. Filtering Repeaters

**Concept**: Utilisation de filtres pour afficher des éléments spécifiques dans une liste.

**Exemple 1: Filtrer par une chaîne**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Filter Example</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <input type="text" ng-model="searchText" placeholder="Search...">
  <ul>
    <li ng-repeat="item in items | filter:searchText">{{ item }}</li>
  </ul>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.items = ['Apple', 'Banana', 'Cherry', 'Date', 'Grape'];
    });
  </script>
</body>
</html>
```

**Exemple 2: Filtrer par condition**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Condition Filter</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <ul>
    <li ng-repeat="item in items | filter:checkFruit">{{ item.name }}</li>
  </ul>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.items = [
        {name: 'Apple', type: 'fruit'},
        {name: 'Carrot', type: 'vegetable'},
        {name: 'Banana', type: 'fruit'}
      ];
      $scope.checkFruit = function(item) {
        return item.type === 'fruit';
      };
    });
  </script>
</body>
</html>
```

### 6. Two-way Data Binding

**Concept**: Synchronisation automatique des données entre le modèle et la vue.

**Exemple 1: Simple binding**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Two-way Binding</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <input type="text" ng-model="name">
  <p>Hello, {{ name }}!</p>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.name = 'World';
    });
  </script>
</body>
</html>
```

**Exemple 2: Binding avec un objet**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Two-way Binding with Object</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <input type="text" ng-model="user.name">
  <p>Name: {{ user.name }}</p>
  <p>Age: {{ user.age }}</p>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.user = { name: 'Alice', age: 25 };
    });
  </script>
</body>
</html>
```

### 7. XHR & Dependency Injection

**Concept**: Récupération de données avec des requêtes XHR et utilisation de l'injection de dépendances.

**Exemple 1: Requête XHR simple avec $http**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>XHR Example</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
Voici la suite du code pour la section "XHR & Dependency Injection" et les chapitres suivants :

**Exemple 1: Requête XHR simple avec `$http` (suite)**

```html
</head>
<body ng-controller="MainController">
  <ul>
    <li ng-repeat="post in posts">{{ post.title }}</li>
  </ul>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope, $http) {
      $http.get('https://jsonplaceholder.typicode.com/posts')
        .then(function(response) {
          $scope.posts = response.data;
        });
    });
  </script>
</body>
</html>
```

**Exemple 2: Service personnalisé avec injection de dépendances**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Custom Service</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <ul>
    <li ng-repeat="item in items">{{ item.name }}</li>
  </ul>

  <script>
    var app = angular.module('myApp', []);

    app.service('DataService', function($http) {
      this.getItems = function() {
        return $http.get('https://jsonplaceholder.typicode.com/users');
      };
    });

    app.controller('MainController', function($scope, DataService) {
      DataService.getItems().then(function(response) {
        $scope.items = response.data;
      });
    });
  </script>
</body>
</html>
```

### 8. Templating Links & Images

**Concept**: Utilisation des liens et images dans les templates AngularJS.

**Exemple 1: Template avec liens dynamiques**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Dynamic Links</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <ul>
    <li ng-repeat="site in sites">
      <a ng-href="{{ site.url }}">{{ site.name }}</a>
    </li>
  </ul>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.sites = [
        { name: 'Google', url: 'https://www.google.com' },
        { name: 'Facebook', url: 'https://www.facebook.com' }
      ];
    });
  </script>
</body>
</html>
```

**Exemple 2: Template avec images dynamiques**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Dynamic Images</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <img ng-src="{{ image.src }}" alt="{{ image.alt }}">

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.image = {
        src: 'https://via.placeholder.com/150',
        alt: 'Placeholder Image'
      };
    });
  </script>
</body>
</html>
```

### 9. Routing & Multiple Views

**Concept**: Utilisation du routage pour gérer plusieurs vues dans une application AngularJS.

**Exemple 1: Configuration du routage simple**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Routing Example</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular-route.js"></script>
</head>
<body>
  <nav>
    <a href="#!/">Home</a>
    <a href="#!/about">About</a>
  </nav>
  <div ng-view></div>

  <script>
    var app = angular.module('myApp', ['ngRoute']);

    app.config(function($routeProvider) {
      $routeProvider
      .when("/", {
        template: "<h1>Welcome to Home</h1>"
      })
      .when("/about", {
        template: "<h1>About Us</h1>"
      });
    });
  </script>
</body>
</html>
```

**Exemple 2: Routage avec des templates externes**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>External Templates</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular-route.js"></script>
</head>
<body>
  <nav>
    <a href="#!/">Home</a>
    <a href="#!/contact">Contact</a>
  </nav>
  <div ng-view></div>

  <script>
    var app = angular.module('myApp', ['ngRoute']);

    app.config(function($routeProvider) {
      $routeProvider
      .when("/", {
        templateUrl: "home.html"
      })
      .when("/contact", {
        templateUrl: "contact.html"
      });
    });
  </script>
</body>
</html>
```

### 10. More Templating

**Concept**: Approfondir l'utilisation des templates avec des directives avancées.

**Exemple 1: Utilisation de `ng-if` pour afficher conditionnellement**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>ng-if Example</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <p ng-if="show">This message is visible!</p>
  <button ng-click="show = !show">Toggle Message</button>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.show = true;
    });
  </script>
</body>
</html>
```

**Exemple 2: Utilisation de `ng-repeat` pour générer des éléments dynamiques**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>ng-repeat Example</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <ul>
    <li ng-repeat="user in users">{{ user.name }}</li>
  </ul>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.users = [
        { name: 'Alice' },
        { name: 'Bob' },
        { name: 'Charlie' }
      ];
    });
  </script>
</body>
</html>
```

### 11. Custom Filters

**Concept**: Créer des filtres personnalisés pour manipuler l'affichage des données.

**Exemple 1: Filtre personnalisé pour convertir en majuscules**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Uppercase Filter</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <p>{{ message | uppercase }}</p>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.message = 'hello, angularjs!';
    });

    app.filter('uppercase', function() {
      return function(input) {
        return input.toUpperCase();
      };
    });
  </script>
</body>
</html>
```

**Exemple 2: Filtre personnalisé pour tronquer une chaîne**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Truncate Filter</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <p>{{ message | truncate:10 }}</p>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.message = 'This is a very long message!';
    });

    app.filter('truncate', function() {
      return function(input, length) {
        if (input.length <= length) {
          return input;
        }
        return input.substring(0, length) + '...';
      };
   Voici la suite du tutoriel avec les chapitres sur les "Event Handlers" et "REST and Custom Services" :

### 12. Event Handlers

**Concept**: Gérer les événements utilisateurs tels que les clics ou les saisies au clavier dans AngularJS.

**Exemple 1: Gestionnaire d'événements `ng-click`**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>ng-click Example</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <p>{{ counter }}</p>
  <button ng-click="incrementCounter()">Increment</button>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.counter = 0;
      $scope.incrementCounter = function() {
        $scope.counter++;
      };
    });
  </script>
</body>
</html>
```

**Exemple 2: Gestionnaire d'événements `ng-keyup`**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>ng-keyup Example</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <input type="text" ng-keyup="updateMessage($event)">
  <p>{{ message }}</p>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope) {
      $scope.message = '';
      $scope.updateMessage = function(event) {
        $scope.message = event.target.value;
      };
    });
  </script>
</body>
</html>
```

### 13. REST and Custom Services

**Concept**: Consommer des API RESTful et créer des services personnalisés pour structurer la logique de l'application.

**Exemple 1: Consommation d'une API REST avec `$http`**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>REST API Example</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <ul>
    <li ng-repeat="user in users">{{ user.name }}</li>
  </ul>

  <script>
    var app = angular.module('myApp', []);
    app.controller('MainController', function($scope, $http) {
      $http.get('https://jsonplaceholder.typicode.com/users')
        .then(function(response) {
          $scope.users = response.data;
        });
    });
  </script>
</body>
</html>
```

**Exemple 2: Service personnalisé pour interagir avec une API REST**

```html
<!DOCTYPE html>
<html lang="en" ng-app="myApp">
<head>
  <meta charset="UTF-8">
  <title>Custom REST Service</title>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
</head>
<body ng-controller="MainController">
  <ul>
    <li ng-repeat="post in posts">{{ post.title }}</li>
  </ul>

  <script>
    var app = angular.module('myApp', []);

    app.service('PostService', function($http) {
      this.getPosts = function() {
        return $http.get('https://jsonplaceholder.typicode.com/posts');
      };
    });

    app.controller('MainController', function($scope, PostService) {
      PostService.getPosts().then(function(response) {
        $scope.posts = response.data;
      });
    });
  </script>
</body>
</html>
```

---

Cela conclut le tutoriel avec des exemples de code pour chaque chapitre demandé. Ces exemples couvrent les concepts clés d'AngularJS et montrent comment créer des applications dynamiques en utilisant ce framework. Si vous avez besoin de plus d'explications sur une section spécifique ou d'exemples supplémentaires, n'hésitez pas à demander!


Pour structurer une application AngularJS avec plusieurs fichiers HTML, tu peux séparer tes vues en différents fichiers et les charger dynamiquement via le système de routage d'AngularJS. Voici un exemple qui montre comment le faire :

### Étapes

1. **Créer un fichier HTML principal** pour inclure AngularJS et gérer le routage.
2. **Créer des fichiers HTML distincts** pour chaque vue.
3. **Configurer le routage** pour charger ces fichiers.

### Arborescence du projet

```
/project-root
    /views
        home.html
        about.html
    index.html
```

### 1. Fichier `index.html`

C'est le fichier principal qui inclut AngularJS et gère le routage.

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AngularJS Routing with Multiple Files</title>
    <!-- CDN for AngularJS and ngRoute -->
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular-route.min.js"></script>
</head>
<body ng-app="myApp">

    <div>
        <a href="#!/">Home</a>
        <a href="#!/about">About</a>
    </div>

    <div ng-view></div>

    <script>
        // Créer le module et configurer les routes
        var app = angular.module("myApp", ["ngRoute"]);

        app.config(function($routeProvider) {
            $routeProvider
            .when("/", {
                templateUrl : "views/home.html"
            })
            .when("/about", {
                templateUrl : "views/about.html"
            })
            .otherwise({
                redirectTo: '/'
            });
        });
    </script>
    
</body>
</html>
```

### 2. Fichier `views/home.html`

Ceci est le fichier pour la page d'accueil.

```html
<h1>Welcome to the Home Page</h1>
<p>This is the content of the home page.</p>
```

### 3. Fichier `views/about.html`

Ceci est le fichier pour la page "About".

```html
<h1>About Us</h1>
<p>This is the content of the about page.</p>
```

### Explication

- **`templateUrl`** : Au lieu de définir la vue en ligne avec `template`, on utilise `templateUrl` pour charger des fichiers HTML externes. 
- **Dossiers de vues** : Les fichiers HTML pour chaque vue sont placés dans un dossier `views` pour organiser les différentes pages.
- **Directive `ng-view`** : Elle est toujours utilisée dans le fichier principal `index.html` pour rendre les vues basées sur la route actuelle.

Ce modèle te permet de structurer ton application AngularJS avec plusieurs fichiers HTML pour mieux gérer la navigation et le contenu.


Pour créer des pages séparées avec AngularJS pour chaque catégorie (par exemple, Tshirt, Chapeau, etc.), voici comment vous pouvez structurer votre projet. Chaque catégorie aura son propre fichier HTML, et nous allons gérer le routage à travers AngularJS pour naviguer entre les différentes pages.

### 1. **Index.html**
Ajout des CDN et création de la structure de base avec `ng-view` pour afficher les pages de catégories.

```html
<!DOCTYPE html>
<html lang="en" ng-app="catalogApp">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Catalogue</title>
  <!-- TailwindCSS CDN -->
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <!-- AngularJS CDN -->
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular-route.min.js"></script>
</head>
<body class="bg-gray-100">
  <nav class="bg-white p-4 shadow-md">
    <div class="container mx-auto flex justify-center">
      <a href="#/tshirt" class="bg-black text-white px-4 py-2 rounded-full mx-2">Tshirt</a>
      <a href="#/chapeau" class="bg-gray-200 text-black px-4 py-2 rounded-full mx-2">Chapeau</a>
      <a href="#/jacket" class="bg-gray-200 text-black px-4 py-2 rounded-full mx-2">Jacket</a>
      <a href="#/pants" class="bg-gray-200 text-black px-4 py-2 rounded-full mx-2">Pants</a>
    </div>
  </nav>

  <div ng-view></div>

  <!-- App Script -->
  <script src="app.js"></script>
</body>
</html>
```

### 2. **app.js**
Configurer le routage pour chaque catégorie (Tshirt, Chapeau, etc.). Chaque route correspond à une page séparée.

```javascript
angular.module('catalogApp', ['ngRoute'])
.config(function($routeProvider) {
  $routeProvider
  .when('/tshirt', {
    templateUrl: 'tshirt.html',
    controller: 'TshirtController'
  })
  .when('/chapeau', {
    templateUrl: 'chapeau.html',
    controller: 'ChapeauController'
  })
  .when('/jacket', {
    templateUrl: 'jacket.html',
    controller: 'JacketController'
  })
  .when('/pants', {
    templateUrl: 'pants.html',
    controller: 'PantsController'
  })
  .otherwise({ redirectTo: '/tshirt' });
})
.controller('TshirtController', function($scope) {
  $scope.products = [
    { name: 'Badacore Tshirt', price: 90, description: 'Classic t-shirt for daily use', image: 'image1.jpg' },
    { name: 'MR Pucy', price: 60, description: 'Simple t-shirt for daily use', image: 'image2.jpg' }
  ];
})
.controller('ChapeauController', function($scope) {
  $scope.products = [
    { name: 'Chapeau Noir', price: 45, description: 'Stylish black hat', image: 'chapeau1.jpg' },
    { name: 'Chapeau Blanc', price: 50, description: 'Elegant white hat', image: 'chapeau2.jpg' }
  ];
})
.controller('JacketController', function($scope) {
  $scope.products = [
    { name: 'Jacket A', price: 120, description: 'Comfortable jacket for all seasons', image: 'jacket1.jpg' },
    { name: 'Jacket B', price: 140, description: 'Stylish winter jacket', image: 'jacket2.jpg' }
  ];
})
.controller('PantsController', function($scope) {
  $scope.products = [
    { name: 'Pants A', price: 60, description: 'Comfortable everyday pants', image: 'pants1.jpg' },
    { name: 'Pants B', price: 70, description: 'Stylish formal pants', image: 'pants2.jpg' }
  ];
});
```

### 3. **tshirt.html**
Affichage des produits de la catégorie "Tshirt". Répétez une structure similaire pour chaque fichier HTML de catégorie (par exemple, `chapeau.html`, `jacket.html`, etc.).

```html
<div class="container mx-auto p-6">
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
    <div ng-repeat="product in products" class="bg-white p-4 rounded-lg shadow-md">
      <img ng-src="{{product.image}}" alt="{{product.name}}" class="w-full h-48 object-cover mb-4 rounded-lg">
      <h2 class="text-xl font-semibold mb-2">{{product.name}}</h2>
      <p class="text-gray-500 mb-2">{{product.description}}</p>
      <p class="text-gray-900 font-bold mb-4">${{product.price}}</p>
      <button class="bg-blue-500 text-white px-4 py-2 rounded-full w-full mb-2" ng-click="showDetails(product)">Details</button>
      <button class="bg-green-500 text-white px-4 py-2 rounded-full w-full" ng-click="checkout()">Passer à la caisse</button>
    </div>
  </div>
</div>
```

Répétez le contenu de cette page pour chaque catégorie, en changeant les données et les images pour chaque fichier HTML (par exemple, `chapeau.html`, `jacket.html`).

### 4. **Popup pour les détails du produit**
Le popup pour afficher les détails d’un produit peut être réutilisé dans chaque contrôleur ou partagé entre les fichiers si vous préférez.

### Explication:
- Chaque catégorie a sa propre page HTML (`tshirt.html`, `chapeau.html`, etc.), qui affiche les produits correspondants.
- **AngularJS** gère le routage avec `ngRoute`, permettant de naviguer entre les différentes pages de catégories.
- **Responsive Design** est géré par TailwindCSS pour s'assurer que le catalogue s'affiche correctement sur différentes tailles d'écran.

En structurant ainsi votre projet, chaque catégorie est facilement accessible par des routes séparées. Vous pouvez également ajouter des contrôleurs pour chaque page pour mieux gérer les données des produits.














