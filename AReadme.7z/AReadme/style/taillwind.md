### CSS Colors
- **Color** : `text-red-500`, `bg-blue-300`, `border-green-600`
- **Opacity** : `bg-gray-500/50` (50% opacity)

### CSS Backgrounds
- **Background Color** : `bg-red-500`
- **Background Image** : `bg-[url('image.jpg')]`
- **Background Size** : `bg-cover`, `bg-contain`

### CSS Borders
- **Border Width** : `border-2`, `border-t-4`
- **Border Color** : `border-red-500`
- **Border Radius** : `rounded`, `rounded-lg`, `rounded-full`

### CSS Margins
- **Margin** : `m-4`, `mt-2`, `mb-6`

### CSS Padding
- **Padding** : `p-4`, `pt-2`, `pb-6`

### CSS Height/Width
- **Height** : `h-32`, `h-screen`
- **Width** : `w-32`, `w-full`

### CSS Box Model
- **Box Sizing** : `box-border` (default), `box-content`

### CSS Outline
- **Outline** : `outline-none`, `outline-2`, `outline-blue-500`

### CSS Text
- **Text Color** : `text-gray-800`
- **Text Size** : `text-xl`, `text-2xl`
- **Text Alignment** : `text-center`, `text-right`

### CSS Fonts
- **Font Family** : `font-sans`, `font-serif`
- **Font Weight** : `font-bold`, `font-medium`


### CSS Links
- **Link Color** : `text-blue-500`, `hover:text-blue-700`

### CSS Lists
- **List Style** : `list-disc`, `list-inside`

### CSS Tables
- **Table Layout** : `table-auto`, `table-fixed`

### CSS Display
- **Display** : `block`, `inline`, `inline-block`, `hidden`

### CSS Max-width
- **Max-width** : `max-w-sm`, `max-w-full`

### CSS Position
- **Position** : `relative`, `absolute`, `fixed`, `sticky`

### CSS Z-index
- **Z-index** : `z-10`, `z-50`

### CSS Overflow
- **Overflow** : `overflow-auto`, `overflow-hidden`

### CSS Float
- **Float** : `float-left`, `float-right`

### CSS Inline-block
- **Inline-block** : `inline-block`

### CSS Align
- **Align Items** : `items-center`, `items-start`
- **Align Content** : `align-center`, `align-start`

### CSS Combinators
- **No direct support** : Utilisez des classes utilitaires Tailwind pour des combinaisons spécifiques.

### CSS Pseudo-class
- **Hover** : `hover:bg-blue-500`
- **Focus** : `focus:border-blue-500`

### CSS Opacity
- **Opacity** : `opacity-50`, `opacity-100`

### CSS Navigation Bar
- **Navbar** : Utilisez des classes pour la disposition, la couleur, etc. `bg-gray-800`, `text-white`, `py-4`

### CSS Dropdowns
- **Dropdown** : Utilisez des classes pour la visibilité, la position, etc. `hidden`, `block`, `absolute`

### CSS Image Gallery
- **Gallery Layout** : `grid`, `grid-cols-3`, `gap-4`

### CSS Image Sprites
- **Sprites** : Utilisez `bg-[url('sprite.png')]` et `bg-position`

### CSS Forms
- **Form Elements** : `p-2`, `border`, `rounded`

### CSS Website Layout
- **Layout** : `flex`, `grid`, `container`, `mx-auto`

### CSS Units
- **Units** : Utilisez des classes comme `px-4`, `py-2`, `w-1/2`, `h-screen`

### CSS Rounded Corners
- **Rounded Corners** : `rounded`, `rounded-lg`, `rounded-full`

### CSS Border Images
- **Border Images** : Utilisez des classes utilitaires pour les bordures `border` et `bg-image`.

### CSS Color Keywords
- **Color Keywords** : Utilisez les couleurs par défaut de Tailwind comme `text-gray-500`, `bg-blue-300`.

### CSS Gradients
- **Gradients** : `bg-gradient-to-r`, `from-blue-500`, `to-purple-500`

### CSS Shadows
- **Shadows** : `shadow`, `shadow-lg`, `shadow-md`

### CSS Text Effects
- **Text Effects** : Utilisez des classes pour les effets de texte, par exemple `italic`, `underline`.

### CSS Web Fonts
- **Web Fonts** : Importez les polices via `@import` ou `<link>` dans le `<head>`, puis utilisez les classes `font-sans`, `font-serif`.

### CSS 2D Transforms
- **2D Transforms** : `rotate-45`, `scale-50`

### CSS 3D Transforms
- **3D Transforms** : `transform`, `perspective-1000`

### CSS Transitions
- **Transitions** : `transition`, `duration-300`, `ease-in-out`

### CSS Animations
- **Animations** : `animate-spin`, `animate-pulse`

### CSS Style Images
- **Style Images** : Utilisez des classes pour les images comme `w-full`, `h-auto`, `object-cover`.

### CSS Image Reflection
- **Reflection** : Utilisez des classes utilitaires pour les effets visuels, comme `opacity-50`.

### CSS object-fit
- **object-fit** : `object-cover`, `object-contain`

### CSS object-position
- **object-position** : `object-center`, `object-top`

### CSS Masking
- **Masking** : Utilisez des effets visuels comme `bg-cover` et `bg-center`.

### CSS Buttons
- **Buttons** : `bg-blue-500`, `text-white`, `py-2`, `px-4`, `rounded`

### CSS Multiple Columns
- **Multiple Columns** : `columns-2`, `gap-4`

### CSS User Interface
- **UI Elements** : Utilisez des classes comme `bg-gray-200`, `p-4`, `rounded`.

### CSS Box Sizing
- **Box Sizing** : `box-border`

### CSS Media Queries
- **Media Queries** : Utilisez les variantes de Tailwind comme `md:bg-red-500`, `lg:text-xl`.

### CSS MQ Examples
- **Examples** : Utilisez les variantes responsives `sm`, `md`, `lg`, `xl`.

### CSS Flexbox
- **Flexbox** : `flex`, `flex-row`, `justify-center`, `items-center`

### CSS Grid
- **Grid Intro** : `grid`
- **Grid Container** : `grid-cols-3`, `gap-4`
- **Grid Item** : `col-span-2`, `row-span-3`
