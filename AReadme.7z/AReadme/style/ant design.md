Voici un exemple complet d'application React intégrant tous les composants listés en utilisant Ant Design. Assurez-vous d'avoir les dépendances nécessaires installées comme mentionné précédemment.

1. **Installer les dépendances :**
   ```sh
   npx create-react-app my-ant-design-app
   cd my-ant-design-app
   npm install antd
   ```

2. **Créer le composant principal :**
   Créez un fichier `App.js` et ajoutez le code suivant :

   ```jsx
   import React from 'react';
   import {
     Layout, Menu, Breadcrumb, Button, Form, Input, Select, Checkbox, Radio, Table, List,
     Tree, Calendar, Card, Modal, notification, Alert, message, Popover, Tabs, Collapse, Avatar,
     Badge, Carousel, Row, Col, Typography
   } from 'antd';
   import { UserOutlined, LaptopOutlined, NotificationOutlined } from '@ant-design/icons';

   const { Header, Content, Sider, Footer } = Layout;
   const { SubMenu } = Menu;
   const { Option } = Select;
   const { TabPane } = Tabs;
   const { Panel } = Collapse;
   const { Title, Paragraph } = Typography;

   const columns = [
     {
       title: 'Name',
       dataIndex: 'name',
       key: 'name',
     },
     {
       title: 'Age',
       dataIndex: 'age',
       key: 'age',
     },
     {
       title: 'Address',
       dataIndex: 'address',
       key: 'address',
     },
   ];

   const data = [
     {
       key: '1',
       name: 'John Brown',
       age: 32,
       address: 'New York No. 1 Lake Park',
     },
     {
       key: '2',
       name: 'Jim Green',
       age: 42,
       address: 'London No. 1 Lake Park',
     },
     {
       key: '3',
       name: 'Joe Black',
       age: 32,
       address: 'Sidney No. 1 Lake Park',
     },
   ];

   const treeData = [
     {
       title: 'parent 1',
       key: '0-0',
       children: [
         {
           title: 'child 1',
           key: '0-0-0',
           children: [
             { title: 'leaf', key: '0-0-0-0' },
             { title: 'leaf', key: '0-0-0-1' },
           ],
         },
         {
           title: 'child 2',
           key: '0-0-1',
           children: [
             { title: 'leaf', key: '0-0-1-0' },
           ],
         },
       ],
     },
   ];

   const openNotification = () => {
     notification.open({
       message: 'Notification Title',
       description: 'This is the content of the notification.',
     });
   };

   const showMessage = () => {
     message.info('This is a normal message');
   };

   const App = () => (
     <Layout>
       <Header className="header">
         <div className="logo" />
         <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['2']}>
           <Menu.Item key="1">nav 1</Menu.Item>
           <Menu.Item key="2">nav 2</Menu.Item>
           <Menu.Item key="3">nav 3</Menu.Item>
         </Menu>
       </Header>
       <Layout>
         <Sider width={200} className="site-layout-background">
           <Menu
             mode="inline"
             defaultSelectedKeys={['1']}
             defaultOpenKeys={['sub1']}
             style={{ height: '100%', borderRight: 0 }}
           >
             <SubMenu key="sub1" icon={<UserOutlined />} title="subnav 1">
               <Menu.Item key="1">option1</Menu.Item>
               <Menu.Item key="2">option2</Menu.Item>
               <Menu.Item key="3">option3</Menu.Item>
               <Menu.Item key="4">option4</Menu.Item>
             </SubMenu>
             <SubMenu key="sub2" icon={<LaptopOutlined />} title="subnav 2">
               <Menu.Item key="5">option5</Menu.Item>
               <Menu.Item key="6">option6</Menu.Item>
               <Menu.Item key="7">option7</Menu.Item>
               <Menu.Item key="8">option8</Menu.Item>
             </SubMenu>
             <SubMenu key="sub3" icon={<NotificationOutlined />} title="subnav 3">
               <Menu.Item key="9">option9</Menu.Item>
               <Menu.Item key="10">option10</Menu.Item>
               <Menu.Item key="11">option11</Menu.Item>
               <Menu.Item key="12">option12</Menu.Item>
             </SubMenu>
           </Menu>
         </Sider>
         <Layout style={{ padding: '0 24px 24px' }}>
           <Breadcrumb style={{ margin: '16px 0' }}>
             <Breadcrumb.Item>Home</Breadcrumb.Item>
             <Breadcrumb.Item>List</Breadcrumb.Item>
             <Breadcrumb.Item>App</Breadcrumb.Item>
           </Breadcrumb>
           <Content
             className="site-layout-background"
             style={{
               padding: 24,
               margin: 0,
               minHeight: 280,
             }}
           >
             <Button type="primary" onClick={openNotification}>
               Open Notification
             </Button>
             <Button type="primary" onClick={showMessage} style={{ marginLeft: 10 }}>
               Show Message
             </Button>
             <Form layout="inline" style={{ margin: '16px 0' }}>
               <Form.Item label="Name">
                 <Input placeholder="Enter your name" />
               </Form.Item>
               <Form.Item label="Age">
                 <Input placeholder="Enter your age" />
               </Form.Item>
               <Form.Item label="Gender">
                 <Select placeholder="Select your gender">
                   <Option value="male">Male</Option>
                   <Option value="female">Female</Option>
                 </Select>
               </Form.Item>
               <Form.Item>
                 <Checkbox>Accept terms</Checkbox>
               </Form.Item>
               <Form.Item>
                 <Radio.Group>
                   <Radio value="a">A</Radio>
                   <Radio value="b">B</Radio>
                 </Radio.Group>
               </Form.Item>
               <Button type="primary">Submit</Button>
             </Form>
             <Table columns={columns} dataSource={data} />
             <List
               header={<div>Header</div>}
               footer={<div>Footer</div>}
               bordered
               dataSource={data}
               renderItem={item => (
                 <List.Item>
                   {item.name}
                 </List.Item>
               )}
             />
             <Tree
               treeData={treeData}
             />
             <Calendar fullscreen={false} style={{ margin: '16px 0' }} />
             <Card title="Card Title" bordered={false} style={{ margin: '16px 0' }}>
               Card content
             </Card>
             <Modal title="Basic Modal" visible={false}>
               <p>Some contents...</p>
             </Modal>
             <Alert message="Success Text" type="success" style={{ margin: '16px 0' }} />
             <Popover content={<p>Content</p>} title="Title">
               <Button type="primary" style={{ margin: '16px 0' }}>Hover me</Button>
             </Popover>
             <Tabs defaultActiveKey="1">
               <TabPane tab="Tab 1" key="1">
                 Content of Tab Pane 1
               </TabPane>
               <TabPane tab="Tab 2" key="2">
                 Content of Tab Pane 2
               </TabPane>
             </Tabs>
             <Collapse defaultActiveKey={['1']}>
               <Panel header="This is panel header 1" key="1">
                 <p>Content 1</p>
               </Panel>
               <Panel header="This is panel header 2" key="2">
                 <p>Content 2</p>
               </Panel>
             </Collapse>
             <Avatar icon={<UserOutlined />} />
             <Badge count={5}>
               <Avatar shape="square" icon={<UserOutlined />} />
             </Badge>
             <Carousel autoplay style={{ margin: '16px 0' }}>
               <div>
                 <h3>1</h3>
               </div>
               <div>
                 <h3>2</h3>
               </div>
               <div>
                 <h3>3</h3>
               </div>
               <div>
                 <h3>4</h3>
               </div>
             </Carousel>
             <Row>
               <Col span={12}>
                 <Title level={2}>Title</Title>
                 <Paragraph>
                   This is a paragraph with some content.
                 </Paragraph>
               </Col>
               <Col span={12}>
                 <Title level={2}>Another Title</Title>
                 <Paragraph>
                   This is another paragraph with more content.
                 </Paragraph>
               </Col>
             </Row>
           </Content>
         </Layout>
       </Layout>
       <Footer style={{ textAlign: 'center' }}>Ant Design Layout Example ©2024</Footer>
     </Layout>
   );

   export default App;
   ```

3. **Ajouter les styles Ant Design :**
   Ajoutez les styles

Pour continuer, ajoutez les styles Ant Design en important le fichier CSS dans votre fichier `index.js` et finalisez la configuration.

3. **Ajouter les styles Ant Design :**
   Ajoutez les styles Ant Design en important le fichier CSS dans votre fichier `index.js` :

   ```jsx
   import 'antd/dist/reset.css'; // Pour Ant Design v4, utilisez 'antd/dist/antd.css'
   import React from 'react';
   import ReactDOM from 'react-dom';
   import './index.css';
   import App from './App';
   import reportWebVitals from './reportWebVitals';

   ReactDOM.render(
     <React.StrictMode>
       <App />
     </React.StrictMode>,
     document.getElementById('root')
   );

   reportWebVitals();
   ```

4. **Démarrer l'application :**
   Enfin, démarrez votre application avec la commande suivante :

   ```sh
   npm start
   ```

5. **Fichier index.css (optionnel) :**
   Vous pouvez ajouter un fichier `index.css` pour inclure quelques styles personnalisés. Créez un fichier `index.css` et ajoutez-y le contenu suivant :

   ```css
   .header {
     background: #001529;
     padding: 0;
   }

   .site-layout-background {
     background: #fff;
   }

   .logo {
     width: 120px;
     height: 31px;
     background: rgba(255, 255, 255, 0.2);
     margin: 16px 24px 16px 0;
     float: left;
   }
   ```

Maintenant, l'application React utilise Ant Design pour intégrer les composants de base, les composants de mise en page, les formulaires, l'affichage de données, le retour d'information, et d'autres composants. Vous pouvez ajuster et personnaliser cette configuration en fonction de vos besoins spécifiques.

