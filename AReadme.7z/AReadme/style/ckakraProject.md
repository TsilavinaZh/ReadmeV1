 Je vous prie de m'excuser pour la confusion. Vous avez raison, nous allons créer ce projet uniquement avec React.js et Chakra UI, sans Electron. Voici comment nous pouvons procéder pour créer le Planificateur de Cours (projet numéro 7) avec React.js et Chakra UI :

1. Configuration initiale :

```bash
npx create-react-app planificateur-cours
cd planificateur-cours
npm install @chakra-ui/react @emotion/react @emotion/styled framer-motion react-router-dom
```

2. Structure du projet :

```
planificateur-cours/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── Sidebar.js
│   │   └── Header.js
│   ├── pages/
│   │   ├── Home.js
│   │   ├── WeeklySchedule.js
│   │   ├── CourseList.js
│   │   └── Settings.js
│   ├── App.js
│   └── index.js
├── package.json
```

3. Modifiez `src/index.js` pour inclure ChakraProvider :

```jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import { ChakraProvider } from '@chakra-ui/react';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <ChakraProvider>
      <App />
    </ChakraProvider>
  </React.StrictMode>
);
```

4. Créez le composant App (`src/App.js`) avec le routage :

```jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Box, Flex } from '@chakra-ui/react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Home from './pages/Home';
import WeeklySchedule from './pages/WeeklySchedule';
import CourseList from './pages/CourseList';
import Settings from './pages/Settings';

function App() {
  return (
    <Router>
      <Flex>
        <Sidebar />
        <Box flex={1}>
          <Header />
          <Box p={4}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/weekly-schedule" element={<WeeklySchedule />} />
              <Route path="/course-list" element={<CourseList />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </Box>
        </Box>
      </Flex>
    </Router>
  );
}

export default App;
```

5. Créez le composant Sidebar (`src/components/Sidebar.js`) :

```jsx
import React from 'react';
import { Box, VStack, Link } from '@chakra-ui/react';
import { Link as RouterLink } from 'react-router-dom';

const Sidebar = () => {
  return (
    <Box width="200px" bg="gray.100" height="100vh" p={4}>
      <VStack spacing={4} align="stretch">
        <Link as={RouterLink} to="/">Accueil</Link>
        <Link as={RouterLink} to="/weekly-schedule">Emploi du temps</Link>
        <Link as={RouterLink} to="/course-list">Liste des cours</Link>
        <Link as={RouterLink} to="/settings">Paramètres</Link>
      </VStack>
    </Box>
  );
};

export default Sidebar;
```

6. Créez le composant Header (`src/components/Header.js`) :

```jsx
import React from 'react';
import { Box, Heading } from '@chakra-ui/react';

const Header = () => {
  return (
    <Box bg="teal.500" p={4} color="white">
      <Heading size="lg">Planificateur de Cours</Heading>
    </Box>
  );
};

export default Header;
```

Voulez-vous que je continue avec la création des pages principales (Home, WeeklySchedule, CourseList, Settings) ?



 Bien sûr, je vais vous fournir tous les codes pour le projet complet. Voici les fichiers restants pour le Planificateur de Cours avec React.js et Chakra UI :

7. Page d'accueil (`src/pages/Home.js`) :

```jsx
import React from 'react';
import { Box, Heading, Text, SimpleGrid, Button } from '@chakra-ui/react';
import { Link as RouterLink } from 'react-router-dom';

const Home = () => {
  return (
    <Box>
      <Heading mb={6}>Bienvenue sur votre Planificateur de Cours</Heading>
      <Text fontSize="xl" mb={8}>
        Gérez facilement votre emploi du temps et vos cours universitaires.
      </Text>
      <SimpleGrid columns={2} spacing={8}>
        <Button as={RouterLink} to="/weekly-schedule" colorScheme="teal" size="lg">
          Voir l'emploi du temps
        </Button>
        <Button as={RouterLink} to="/course-list" colorScheme="blue" size="lg">
          Gérer les cours
        </Button>
      </SimpleGrid>
    </Box>
  );
};

export default Home;
```

8. Page Emploi du temps hebdomadaire (`src/pages/WeeklySchedule.js`) :

```jsx
import React from 'react';
import { Box, Heading, Table, Thead, Tbody, Tr, Th, Td } from '@chakra-ui/react';

const WeeklySchedule = () => {
  const days = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'];
  const hours = ['8:00', '10:00', '12:00', '14:00', '16:00'];

  return (
    <Box>
      <Heading mb={6}>Emploi du temps hebdomadaire</Heading>
      <Table variant="simple">
        <Thead>
          <Tr>
            <Th>Heure</Th>
            {days.map(day => <Th key={day}>{day}</Th>)}
          </Tr>
        </Thead>
        <Tbody>
          {hours.map(hour => (
            <Tr key={hour}>
              <Td>{hour}</Td>
              {days.map(day => <Td key={`${day}-${hour}`}></Td>)}
            </Tr>
          ))}
        </Tbody>
      </Table>
    </Box>
  );
};

export default WeeklySchedule;
```

9. Page Liste des cours (`src/pages/CourseList.js`) :

```jsx
import React, { useState } from 'react';
import { Box, Heading, VStack, HStack, Input, Button, Text } from '@chakra-ui/react';

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const [newCourse, setNewCourse] = useState('');

  const addCourse = () => {
    if (newCourse.trim() !== '') {
      setCourses([...courses, newCourse.trim()]);
      setNewCourse('');
    }
  };

  return (
    <Box>
      <Heading mb={6}>Liste des cours</Heading>
      <HStack mb={4}>
        <Input
          value={newCourse}
          onChange={(e) => setNewCourse(e.target.value)}
          placeholder="Ajouter un nouveau cours"
        />
        <Button onClick={addCourse} colorScheme="teal">
          Ajouter
        </Button>
      </HStack>
      <VStack align="stretch" spacing={2}>
        {courses.map((course, index) => (
          <Box key={index} p={2} bg="gray.100" borderRadius="md">
            <Text>{course}</Text>
          </Box>
        ))}
      </VStack>
    </Box>
  );
};

export default CourseList;
```

10. Page Paramètres (`src/pages/Settings.js`) :

```jsx
import React from 'react';
import { Box, Heading, VStack, FormControl, FormLabel, Switch } from '@chakra-ui/react';

const Settings = () => {
  return (
    <Box>
      <Heading mb={6}>Paramètres</Heading>
      <VStack spacing={4} align="stretch">
        <FormControl display="flex" alignItems="center">
          <FormLabel htmlFor="dark-mode" mb="0">
            Mode sombre
          </FormLabel>
          <Switch id="dark-mode" />
        </FormControl>
        <FormControl display="flex" alignItems="center">
          <FormLabel htmlFor="notifications" mb="0">
            Notifications
          </FormLabel>
          <Switch id="notifications" />
        </FormControl>
      </VStack>
    </Box>
  );
};

export default Settings;
```

Avec ces fichiers, vous avez maintenant un projet React complet pour le Planificateur de Cours. Pour exécuter l'application, utilisez la commande suivante dans le répertoire du projet :

```bash
npm start
```

Cela lancera l'application dans votre navigateur par défaut à l'adresse `http://localhost:3000`.

Ce projet offre une base solide que vous pouvez étendre et personnaliser selon les besoins spécifiques de votre université. N'hésitez pas à ajouter des fonctionnalités, à améliorer le design ou à intégrer des données réelles pour rendre l'application plus utile pour les étudiants.


 Certainement ! Je vais ajouter plusieurs fonctionnalités et améliorations à votre Planificateur de Cours. Voici quelques ajouts que nous pouvons faire :

1. Ajout d'un système de couleurs pour les cours
2. Fonctionnalité de recherche dans la liste des cours
3. Possibilité d'ajouter des détails aux cours (professeur, salle, etc.)
4. Ajout d'un calendrier pour les événements importants
5. Intégration d'un système de rappels/notifications

Commençons par modifier et ajouter ces fonctionnalités :

1. Modifions d'abord `CourseList.js` pour inclure plus de détails et un système de couleurs :

```jsx
import React, { useState } from 'react';
import { Box, Heading, VStack, HStack, Input, Button, Text, Select, FormControl, FormLabel } from '@chakra-ui/react';

const CourseList = () => {
  const [courses, setCourses] = useState([]);
  const [newCourse, setNewCourse] = useState({ name: '', professor: '', room: '', color: 'blue.100' });

  const addCourse = () => {
    if (newCourse.name.trim() !== '') {
      setCourses([...courses, { ...newCourse, id: Date.now() }]);
      setNewCourse({ name: '', professor: '', room: '', color: 'blue.100' });
    }
  };

  const removeCourse = (id) => {
    setCourses(courses.filter(course => course.id !== id));
  };

  return (
    <Box>
      <Heading mb={6}>Liste des cours</Heading>
      <VStack spacing={4} align="stretch" mb={8}>
        <FormControl>
          <FormLabel>Nom du cours</FormLabel>
          <Input
            value={newCourse.name}
            onChange={(e) => setNewCourse({ ...newCourse, name: e.target.value })}
            placeholder="Nom du cours"
          />
        </FormControl>
        <FormControl>
          <FormLabel>Professeur</FormLabel>
          <Input
            value={newCourse.professor}
            onChange={(e) => setNewCourse({ ...newCourse, professor: e.target.value })}
            placeholder="Nom du professeur"
          />
        </FormControl>
        <FormControl>
          <FormLabel>Salle</FormLabel>
          <Input
            value={newCourse.room}
            onChange={(e) => setNewCourse({ ...newCourse, room: e.target.value })}
            placeholder="Numéro de salle"
          />
        </FormControl>
        <FormControl>
          <FormLabel>Couleur</FormLabel>
          <Select
            value={newCourse.color}
            onChange={(e) => setNewCourse({ ...newCourse, color: e.target.value })}
          >
            <option value="blue.100">Bleu</option>
            <option value="green.100">Vert</option>
            <option value="red.100">Rouge</option>
            <option value="yellow.100">Jaune</option>
            <option value="purple.100">Violet</option>
          </Select>
        </FormControl>
        <Button onClick={addCourse} colorScheme="teal">
          Ajouter le cours
        </Button>
      </VStack>
      <VStack align="stretch" spacing={2}>
        {courses.map((course) => (
          <Box key={course.id} p={2} bg={course.color} borderRadius="md">
            <HStack justify="space-between">
              <VStack align="start" spacing={1}>
                <Text fontWeight="bold">{course.name}</Text>
                <Text fontSize="sm">Prof: {course.professor}</Text>
                <Text fontSize="sm">Salle: {course.room}</Text>
              </VStack>
              <Button size="sm" colorScheme="red" onClick={() => removeCourse(course.id)}>
                Supprimer
              </Button>
            </HStack>
          </Box>
        ))}
      </VStack>
    </Box>
  );
};

export default CourseList;
```

2. Ajoutons une nouvelle page pour le calendrier des événements (`src/pages/EventCalendar.js`) :

```jsx
import React, { useState } from 'react';
import { Box, Heading, VStack, HStack, Input, Button, Text, FormControl, FormLabel } from '@chakra-ui/react';

const EventCalendar = () => {
  const [events, setEvents] = useState([]);
  const [newEvent, setNewEvent] = useState({ title: '', date: '', description: '' });

  const addEvent = () => {
    if (newEvent.title.trim() !== '' && newEvent.date.trim() !== '') {
      setEvents([...events, { ...newEvent, id: Date.now() }]);
      setNewEvent({ title: '', date: '', description: '' });
    }
  };

  const removeEvent = (id) => {
    setEvents(events.filter(event => event.id !== id));
  };

  return (
    <Box>
      <Heading mb={6}>Calendrier des événements</Heading>
      <VStack spacing={4} align="stretch" mb={8}>
        <FormControl>
          <FormLabel>Titre de l'événement</FormLabel>
          <Input
            value={newEvent.title}
            onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
            placeholder="Titre de l'événement"
          />
        </FormControl>
        <FormControl>
          <FormLabel>Date</FormLabel>
          <Input
            type="date"
            value={newEvent.date}
            onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
          />
        </FormControl>
        <FormControl>
          <FormLabel>Description</FormLabel>
          <Input
            value={newEvent.description}
            onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
            placeholder="Description de l'événement"
          />
        </FormControl>
        <Button onClick={addEvent} colorScheme="teal">
          Ajouter l'événement
        </Button>
      </VStack>
      <VStack align="stretch" spacing={2}>
        {events.map((event) => (
          <Box key={event.id} p={2} bg="gray.100" borderRadius="md">
            <HStack justify="space-between">
              <VStack align="start" spacing={1}>
                <Text fontWeight="bold">{event.title}</Text>
                <Text fontSize="sm">Date: {event.date}</Text>
                <Text fontSize="sm">{event.description}</Text>
              </VStack>
              <Button size="sm" colorScheme="red" onClick={() => removeEvent(event.id)}>
                Supprimer
              </Button>
            </HStack>
          </Box>
        ))}
      </VStack>
    </Box>
  );
};

export default EventCalendar;
```

3. Modifions `App.js` pour inclure la nouvelle page du calendrier :

```jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Box, Flex } from '@chakra-ui/react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Home from './pages/Home';
import WeeklySchedule from './pages/WeeklySchedule';
import CourseList from './pages/CourseList';
import Settings from './pages/Settings';
import EventCalendar from './pages/EventCalendar';

function App() {
  return (
    <Router>
      <Flex>
        <Sidebar />
        <Box flex={1}>
          <Header />
          <Box p={4}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/weekly-schedule" element={<WeeklySchedule />} />
              <Route path="/course-list" element={<CourseList />} />
              <Route path="/event-calendar" element={<EventCalendar />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </Box>
        </Box>
      </Flex>
    </Router>
  );
}

export default App;
```

4. Mettons à jour `Sidebar.js` pour inclure le lien vers le calendrier :

```jsx
import React from 'react';
import { Box, VStack, Link } from '@chakra-ui/react';
import { Link as RouterLink } from 'react-router-dom';

const Sidebar = () => {
  return (
    <Box width="200px" bg="gray.100" height="100vh" p={4}>
      <VStack spacing={4} align="stretch">
        <Link as={RouterLink} to="/">Accueil</Link>
        <Link as={RouterLink} to="/weekly-schedule">Emploi du temps</Link>
        <Link as={RouterLink} to="/course-list">Liste des cours</Link>
        <Link as={RouterLink} to="/event-calendar">Calendrier</Link>
        <Link as={RouterLink} to="/settings">Paramètres</Link>
      </VStack>
    </Box>
  );
};

export default Sidebar;
```

Ces modifications ajoutent plusieurs fonctionnalités à votre Planificateur de Cours :
- Un système de couleurs pour les cours
- Plus de détails pour chaque cours (professeur, salle)
- Un calendrier d'événements

Pour aller plus loin, vous pourriez envisager d'ajouter :
- Un système de persistence des données (avec localStorage ou une base de données)
- Une fonctionnalité de recherche dans la liste des cours et des événements
- Un système de rappels/notifications (cela nécessiterait probablement l'intégration d'une bibliothèque supplémentaire)

N'hésitez pas à me dire si vous souhaitez des explications supplémentaires ou d'autres fonctionnalités !


 Bien sûr, je vais ajouter d'autres pages et fonctionnalités à votre Planificateur de Cours. Voici quelques ajouts que nous allons faire :

1. Page de Tâches/Devoirs
2. Page de Statistiques
3. Page de Ressources
4. Amélioration de la page d'accueil
5. Système de recherche globale

Commençons par créer ces nouvelles pages et fonctionnalités :

1. Page de Tâches/Devoirs (`src/pages/Tasks.js`):

```jsx
import React, { useState } from 'react';
import { Box, Heading, VStack, HStack, Input, Button, Text, Checkbox, Select } from '@chakra-ui/react';

const Tasks = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState({ description: '', dueDate: '', course: '', completed: false });

  const addTask = () => {
    if (newTask.description.trim() !== '') {
      setTasks([...tasks, { ...newTask, id: Date.now() }]);
      setNewTask({ description: '', dueDate: '', course: '', completed: false });
    }
  };

  const toggleTask = (id) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const removeTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  return (
    <Box>
      <Heading mb={6}>Tâches et Devoirs</Heading>
      <VStack spacing={4} align="stretch" mb={8}>
        <Input
          value={newTask.description}
          onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
          placeholder="Description de la tâche"
        />
        <Input
          type="date"
          value={newTask.dueDate}
          onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
        />
        <Select
          placeholder="Sélectionner un cours"
          value={newTask.course}
          onChange={(e) => setNewTask({ ...newTask, course: e.target.value })}
        >
          <option value="math">Mathématiques</option>
          <option value="physics">Physique</option>
          <option value="literature">Littérature</option>
        </Select>
        <Button onClick={addTask} colorScheme="teal">Ajouter la tâche</Button>
      </VStack>
      <VStack align="stretch" spacing={2}>
        {tasks.map((task) => (
          <HStack key={task.id} p={2} bg={task.completed ? "green.100" : "red.100"} borderRadius="md">
            <Checkbox isChecked={task.completed} onChange={() => toggleTask(task.id)} />
            <Text flex={1}>{task.description}</Text>
            <Text fontSize="sm">{task.dueDate}</Text>
            <Text fontSize="sm">{task.course}</Text>
            <Button size="sm" colorScheme="red" onClick={() => removeTask(task.id)}>Supprimer</Button>
          </HStack>
        ))}
      </VStack>
    </Box>
  );
};

export default Tasks;
```

2. Page de Statistiques (`src/pages/Statistics.js`):

```jsx
import React from 'react';
import { Box, Heading, VStack, Text, Progress } from '@chakra-ui/react';

const Statistics = () => {
  // Ces données devraient idéalement provenir d'un état global ou d'une API
  const stats = {
    coursesCompleted: 5,
    totalCourses: 10,
    tasksCompleted: 15,
    totalTasks: 20,
    averageGrade: 85
  };

  return (
    <Box>
      <Heading mb={6}>Statistiques</Heading>
      <VStack spacing={6} align="stretch">
        <Box>
          <Text mb={2}>Progression des cours</Text>
          <Progress value={(stats.coursesCompleted / stats.totalCourses) * 100} colorScheme="green" />
          <Text mt={2}>{stats.coursesCompleted} sur {stats.totalCourses} cours complétés</Text>
        </Box>
        <Box>
          <Text mb={2}>Tâches accomplies</Text>
          <Progress value={(stats.tasksCompleted / stats.totalTasks) * 100} colorScheme="blue" />
          <Text mt={2}>{stats.tasksCompleted} sur {stats.totalTasks} tâches accomplies</Text>
        </Box>
        <Box>
          <Text mb={2}>Note moyenne</Text>
          <Text fontSize="3xl" fontWeight="bold">{stats.averageGrade}%</Text>
        </Box>
      </VStack>
    </Box>
  );
};

export default Statistics;
```

3. Page de Ressources (`src/pages/Resources.js`):

```jsx
import React, { useState } from 'react';
import { Box, Heading, VStack, HStack, Input, Button, Text, Link } from '@chakra-ui/react';

const Resources = () => {
  const [resources, setResources] = useState([]);
  const [newResource, setNewResource] = useState({ title: '', url: '', description: '' });

  const addResource = () => {
    if (newResource.title.trim() !== '' && newResource.url.trim() !== '') {
      setResources([...resources, { ...newResource, id: Date.now() }]);
      setNewResource({ title: '', url: '', description: '' });
    }
  };

  const removeResource = (id) => {
    setResources(resources.filter(resource => resource.id !== id));
  };

  return (
    <Box>
      <Heading mb={6}>Ressources</Heading>
      <VStack spacing={4} align="stretch" mb={8}>
        <Input
          value={newResource.title}
          onChange={(e) => setNewResource({ ...newResource, title: e.target.value })}
          placeholder="Titre de la ressource"
        />
        <Input
          value={newResource.url}
          onChange={(e) => setNewResource({ ...newResource, url: e.target.value })}
          placeholder="URL de la ressource"
        />
        <Input
          value={newResource.description}
          onChange={(e) => setNewResource({ ...newResource, description: e.target.value })}
          placeholder="Description (optionnelle)"
        />
        <Button onClick={addResource} colorScheme="teal">Ajouter la ressource</Button>
      </VStack>
      <VStack align="stretch" spacing={2}>
        {resources.map((resource) => (
          <Box key={resource.id} p={2} bg="gray.100" borderRadius="md">
            <HStack justify="space-between">
              <VStack align="start" spacing={1}>
                <Link href={resource.url} isExternal color="blue.500" fontWeight="bold">
                  {resource.title}
                </Link>
                <Text fontSize="sm">{resource.description}</Text>
              </VStack>
              <Button size="sm" colorScheme="red" onClick={() => removeResource(resource.id)}>
                Supprimer
              </Button>
            </HStack>
          </Box>
        ))}
      </VStack>
    </Box>
  );
};

export default Resources;
```

4. Améliorons la page d'accueil (`src/pages/Home.js`):

```jsx
import React from 'react';
import { Box, Heading, Text, SimpleGrid, Button, VStack, HStack, Progress } from '@chakra-ui/react';
import { Link as RouterLink } from 'react-router-dom';

const Home = () => {
  // Ces données devraient idéalement provenir d'un état global ou d'une API
  const upcomingTasks = [
    { id: 1, description: "Devoir de maths", dueDate: "2023-05-15" },
    { id: 2, description: "Présentation d'histoire", dueDate: "2023-05-18" },
  ];

  const courseProgress = 60; // Pourcentage de progression

  return (
    <Box>
      <Heading mb={6}>Tableau de bord</Heading>
      <SimpleGrid columns={2} spacing={8} mb={8}>
        <VStack align="stretch" p={4} borderWidth={1} borderRadius="md">
          <Heading size="md" mb={4}>Progression des cours</Heading>
          <Progress value={courseProgress} colorScheme="green" mb={2} />
          <Text>{courseProgress}% complété</Text>
          <Button as={RouterLink} to="/weekly-schedule" colorScheme="teal" mt={4}>
            Voir l'emploi du temps
          </Button>
        </VStack>
        <VStack align="stretch" p={4} borderWidth={1} borderRadius="md">
          <Heading size="md" mb={4}>Tâches à venir</Heading>
          {upcomingTasks.map(task => (
            <HStack key={task.id} justify="space-between">
              <Text>{task.description}</Text>
              <Text fontWeight="bold">{task.dueDate}</Text>
            </HStack>
          ))}
          <Button as={RouterLink} to="/tasks" colorScheme="blue" mt={4}>
            Gérer les tâches
          </Button>
        </VStack>
      </SimpleGrid>
      <SimpleGrid columns={2} spacing={8}>
        <Button as={RouterLink} to="/course-list" colorScheme="purple" size="lg">
          Liste des cours
        </Button>
        <Button as={RouterLink} to="/resources" colorScheme="orange" size="lg">
          Ressources
        </Button>
      </SimpleGrid>
    </Box>
  );
};

export default Home;
```

5. Ajoutons un système de recherche globale (`src/components/GlobalSearch.js`):

```jsx
import React, { useState } from 'react';
import { Input, Box, VStack, Text, Link } from '@chakra-ui/react';
import { Link as RouterLink } from 'react-router-dom';

const GlobalSearch = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);

  // Cette fonction devrait idéalement chercher dans toutes vos données
  const performSearch = (term) => {
    // Ceci est un exemple simplifié. Vous devriez adapter cela à vos données réelles.
    const results = [
      { type: 'course', name: 'Mathématiques', link: '/course-list' },
      { type: 'task', name: 'Devoir de physique', link: '/tasks' },
      { type: 'resource', name: 'Guide d'étude', link: '/resources' },
    ].filter(item => item.name.toLowerCase().includes(term.toLowerCase()));
    
    setSearchResults(results);
  };

  const handleSearch = (e) => {
    const term = e.target.value;
    setSearchTerm(term);
    if (term.length > 2) {
      performSearch(term);
    } else {
      setSearchResults([]);
    }
  };

  return (
    <Box position="relative">
      <Input
        value={searchTerm}
        onChange={handleSearch}
        placeholder="Rechercher..."
        mb={2}
      />
      {searchResults.length > 0 && (
        <Box position="absolute" width="100%" bg="white" boxShadow="md" zIndex={1}>
          <VStack align="stretch" spacing={2} p={2}>
            {searchResults.map((result, index) => (
              <Link key={index} as={RouterLink} to={result.link}>
                <Text>
                  {result.name} <Text as="span" color="gray.500">({result.type})</Text>
                </Text>
              </Link>
            ))}
          </VStack>
        </Box>
      )}
    </Box>
  );
};

export default GlobalSearch;
```

Enfin, mettez à jour `App.js` pour inclure toutes ces nouvelles pages et le composant de recherche globale :

```jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Box, Flex } from '@chakra-ui/react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import GlobalSearch from './components/GlobalSearch';
import Home from './pages/Home';
import WeeklySchedule from './pages/WeeklySchedule';
import CourseList from './pages/CourseList';
import Tasks from './pages/Tasks';
import EventCalendar from './pages/EventCalendar';
import Statistics from './pages/Statistics';
import Resources from './pages/Resources';
import Settings from './pages/Settings';

function App() {
  return (
    <Router>
      <Flex>
        <Sidebar />
        <Box flex={1}>
          <Header />
          <Box p={4}>
            <GlobalSearch />
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/weekly-schedule" element={<WeeklySchedule />} />
              <Route path="/course-list" element={<CourseList />} />
              <Route path="/tasks" element={<Tasks />} />
              <Route path="/event-calendar" element={<EventCalendar />} />
              <Route path="/statistics" element={<Statistics />} />
              <Route path="/resources" element={<Resources />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </Box>
        </Box>
      </Flex>
    </Router>
  );
}

export default App;
```

N'oubliez pas de mettre à jour votre `Sidebar.js` pour inclure les liens vers ces nouvelles pages.

Ces ajouts enrichissent considérablement votre Planificateur de Cours avec de nouvelles fonctionnalités utiles pour les étudiants. Le projet est maintenant plus complet et offre une meilleure expérience utilisateur.
