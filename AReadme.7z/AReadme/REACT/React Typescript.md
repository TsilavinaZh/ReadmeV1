React with TypeScript is a powerful combination that enhances the development experience and helps catch errors early. Here’s a comprehensive guide to get you started:

### Introduction to React and TypeScript

**React** is a JavaScript library for building user interfaces. It allows you to create reusable UI components.

**TypeScript** is a typed superset of JavaScript that compiles to plain JavaScript. It adds static types to the language, helping to catch errors at compile time and improving development tooling (like autocomplete and refactoring).

Combining React with TypeScript brings the benefits of static typing to React components, making your code more predictable and easier to debug.

### Setting Up a React Project with TypeScript

1. **Using Create React App (CRA):**
   ```bash
   npx create-react-app my-app --template typescript
   ```
   This sets up a new React project with TypeScript.

2. **Adding TypeScript to an Existing React Project:**
   ```bash
   npm install --save typescript @types/node @types/react @types/react-dom @types/jest
   ```
   Rename any `.js` files to `.tsx` to start using TypeScript.

### Basic Types

- **Primitive Types:**
  ```typescript
  let name: string = "John";
  let age: number = 25;
  let isStudent: boolean = true;
  ```

- **Arrays and Objects:**
  ```typescript
  let numbers: number[] = [1, 2, 3];
  let person: { name: string; age: number } = { name: "John", age: 25 };
  ```

- **Interfaces:**
  ```typescript
  interface Person {
    name: string;
    age: number;
  }

  let person: Person = { name: "John", age: 25 };
  ```

### React Components with TypeScript

- **Function Components:**
  ```tsx
  import React from "react";

  interface Props {
    name: string;
    age?: number; // Optional prop
  }

  const Greeting: React.FC<Props> = ({ name, age }) => {
    return (
      <div>
        Hello, {name}! {age && <p>You are {age} years old.</p>}
      </div>
    );
  };

  export default Greeting;
  ```

- **Class Components:**
  ```tsx
  import React, { Component } from "react";

  interface Props {
    name: string;
  }

  interface State {
    count: number;
  }

  class Counter extends Component<Props, State> {
    state: State = {
      count: 0,
    };

    increment = () => {
      this.setState({ count: this.state.count + 1 });
    };

    render() {
      return (
        <div>
          <p>{this.props.name}, you clicked {this.state.count} times</p>
          <button onClick={this.increment}>Increment</button>
        </div>
      );
    }
  }

  export default Counter;
  ```

### Using Hooks with TypeScript

- **useState:**
  ```tsx
  import React, { useState } from "react";

  const Counter: React.FC = () => {
    const [count, setCount] = useState<number>(0);

    return (
      <div>
        <p>You clicked {count} times</p>
        <button onClick={() => setCount(count + 1)}>Increment</button>
      </div>
    );
  };

  export default Counter;
  ```

- **useEffect:**
  ```tsx
  import React, { useEffect, useState } from "react";

  const Timer: React.FC = () => {
    const [seconds, setSeconds] = useState<number>(0);

    useEffect(() => {
      const interval = setInterval(() => {
        setSeconds(seconds + 1);
      }, 1000);

      return () => clearInterval(interval);
    }, [seconds]);

    return <div>Seconds: {seconds}</div>;
  };

  export default Timer;
  ```

### Props and State Types

- **Props Types:**
  ```tsx
  interface Props {
    name: string;
    age?: number; // Optional
  }

  const Component: React.FC<Props> = ({ name, age }) => {
    return <div>{name} {age && age}</div>;
  };
  ```

- **State Types in Class Components:**
  ```tsx
  interface State {
    count: number;
  }

  class MyComponent extends React.Component<{}, State> {
    state: State = {
      count: 0,
    };

    render() {
      return <div>{this.state.count}</div>;
    }
  }
  ```

### Type Checking Props

- **Prop Types in Functional Components:**
  ```tsx
  const MyComponent: React.FC<{ name: string }> = ({ name }) => {
    return <div>{name}</div>;
  };
  ```

- **Prop Types in Class Components:**
  ```tsx
  interface Props {
    name: string;
  }

  class MyComponent extends React.Component<Props> {
    render() {
      return <div>{this.props.name}</div>;
    }
  }
  ```

### Handling Events

- **Event Handlers:**
  ```tsx
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    console.log(event.currentTarget);
  };

  return <button onClick={handleClick}>Click me</button>;
  ```

### Common Types in React

- **ReactNode:**
  ```tsx
  interface Props {
    children: React.ReactNode;
  }

  const Wrapper: React.FC<Props> = ({ children }) => {
    return <div>{children}</div>;
  };
  ```

- **Ref Types:**
  ```tsx
  const inputRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);
  ```

### Conclusion

Using React with TypeScript offers a robust development experience by providing static type checking, enhanced tooling, and better code readability. This combination is especially beneficial for large codebases where maintaining type safety can significantly reduce the number of runtime errors.

Do you have any specific questions or parts of React with TypeScript you'd like to explore further?