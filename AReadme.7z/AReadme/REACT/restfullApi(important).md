Sure! Let's break down how to create a RESTful API using Express with CORS support, as described in your image.

### 1. Setup Express Project

First, create a new directory for your project and initialize it with npm:

```sh
mkdir express-api
cd express-api
npm init -y
```

Install Express and CORS:

```sh
npm install express cors
```

### 2. Create the Express Server

Create a new file named `server.js` and set up a basic Express server:

```js
const express = require('express');
const cors = require('cors');

const app = express();
const port = 3000;

// Use CORS middleware
app.use(cors());

// Middleware to parse JSON
app.use(express.json());

// Basic route
app.get('/', (req, res) => {
  res.send('Hello World!');
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
```

### 3. Creating Routes and Middleware

Create a `routes` directory and a `users.js` file within it:

```sh
mkdir routes
touch routes/users.js
```

In `routes/users.js`, define your routes:

```js
const express = require('express');
const router = express.Router();

// Mock data
const users = [
  { id: 1, name: 'John Doe' },
  { id: 2, name: 'Jane Doe' }
];

// Get all users
router.get('/', (req, res) => {
  res.json(users);
});

// Get user by ID
router.get('/:id', (req, res) => {
  const user = users.find(u => u.id === parseInt(req.params.id));
  if (!user) return res.status(404).send('User not found');
  res.json(user);
});

// Add a new user
router.post('/', (req, res) => {
  const newUser = {
    id: users.length + 1,
    name: req.body.name
  };
  users.push(newUser);
  res.status(201).json(newUser);
});

module.exports = router;
```

In `server.js`, use the users route:

```js
const usersRouter = require('./routes/users');

app.use('/api/users', usersRouter);
```

### 4. Handling Errors and Securing the API

Add a middleware for error handling at the end of your `server.js`:

```js
// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});
```

To enhance security, you can set specific CORS options:

```js
const corsOptions = {
  origin: 'http://your-frontend-domain.com', // restrict calls to those this address
  methods: 'GET,POST', // only allow GET and POST requests
  allowedHeaders: 'Content-Type,Authorization' // restrict allowed headers
};

app.use(cors(corsOptions));
```

### 5. Run Your Server

Run the server:

```sh
node server.js
```

Your Express server should now be running, supporting CORS, and able to handle routes, middlewares, error handling, and basic security.

If you have specific questions or need further clarification, feel free to ask!