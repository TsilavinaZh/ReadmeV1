Pour t'apprendre à configurer et utiliser Node.js, Express, MySQL et CORS avec des exemples de code, nous allons suivre les étapes du plan détaillé dans l'image et ajouter des exemples concrets pour chaque étape.

### 1. **Bases de Node.js**

#### a. **Introduction à Node.js**

1. **Installation de Node.js** :
   - Télécharge et installe Node.js depuis [nodejs.org](https://nodejs.org/).

2. **Premier script Node.js** :
   - Crée un fichier `app.js` et ajoute le code suivant pour créer un simple serveur HTTP.

```javascript
const http = require('http');

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello, World!\n');
});

const port = 3000;
server.listen(port, () => {
  console.log(`Server running at http://localhost:${port}/`);
});
```

3. **Exécute le serveur** :
   - Ouvre un terminal, navigue vers le dossier où se trouve `app.js` et exécute la commande :
   
   ```bash
   node app.js
   ```

### 2. **Serveurs HTTP avec Node.js et Express**

#### a. **Configuration d'Express.js**

1. **Installation d'Express.js** :
   - Initialise un nouveau projet et installe Express :

   ```bash
   mkdir myapp
   cd myapp
   npm init -y
   npm install express
   ```

2. **Création d'un serveur Express** :
   - Crée un fichier `server.js` et ajoute le code suivant :

```javascript
const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => {
  res.send('Hello, Express!');
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
```

3. **Démarrer le serveur** :
   - Exécute la commande suivante dans le terminal :

   ```bash
   node server.js
   ```

### 3. **API RESTful avec Express**

#### a. **Création de routes et middlewares**

1. **Ajout de routes** :

```javascript
app.get('/api', (req, res) => {
  res.send('API Home');
});

app.get('/api/users', (req, res) => {
  res.json([
    { id: 1, name: 'John Doe' },
    { id: 2, name: 'Jane Doe' }
  ]);
});
```

2. **Middlewares** :
   - Utilisation d'un middleware pour logger les requêtes :

```javascript
const logger = (req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
};

app.use(logger);
```

### 4. **Base de données avec MySQL**

#### a. **Installation et configuration de MySQL**

1. **Installation de MySQL** :
   - Installe MySQL sur ton système.

2. **Configuration de MySQL** :
   - Connecte-toi à MySQL et crée une base de données et une table :

```sql
CREATE DATABASE mydatabase;
USE mydatabase;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL
);
```

#### b. **Intégration avec Node.js**

1. **Installation de la bibliothèque MySQL pour Node.js** :

   ```bash
   npm install mysql
   ```

2. **Connexion à MySQL dans `server.js`** :

```javascript
const mysql = require('mysql');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'mydatabase'
});

db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log('Connected to MySQL Database');
});
```

3. **CRUD avec Node.js et MySQL** :

```javascript
// Create
app.post('/api/users', (req, res) => {
  const user = { name: req.body.name };
  const sql = 'INSERT INTO users SET ?';
  db.query(sql, user, (err, result) => {
    if (err) throw err;
    res.send('User added');
  });
});

// Read
app.get('/api/users', (req, res) => {
  const sql = 'SELECT * FROM users';
  db.query(sql, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

// Update
app.put('/api/users/:id', (req, res) => {
  const sql = `UPDATE users SET name = '${req.body.name}' WHERE id = ${req.params.id}`;
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.send('User updated');
  });
});

// Delete
app.delete('/api/users/:id', (req, res) => {
  const sql = `DELETE FROM users WHERE id = ${req.params.id}`;
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.send('User deleted');
  });
});
```

### 5. **Configuration de CORS**

1. **Installation du middleware CORS** :

   ```bash
   npm install cors
   ```

2. **Utilisation de CORS dans `server.js`** :

```javascript
const cors = require('cors');

app.use(cors());
```

### Exemple complet `server.js` :

```javascript
const express = require('express');
const cors = require('cors');
const mysql = require('mysql');
const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// MySQL Configuration
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'mydatabase'
});

db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log('Connected to MySQL Database');
});

// Routes
app.get('/api', (req, res) => {
  res.send('API Home');
});

app.get('/api/users', (req, res) => {
  const sql = 'SELECT * FROM users';
  db.query(sql, (err, results) => {
    if (err) throw err;
    res.json(results);
  });
});

app.post('/api/users', (req, res) => {
  const user = { name: req.body.name };
  const sql = 'INSERT INTO users SET ?';
  db.query(sql, user, (err, result) => {
    if (err) throw err;
    res.send('User added');
  });
});

app.put('/api/users/:id', (req, res) => {
  const sql = `UPDATE users SET name = '${req.body.name}' WHERE id = ${req.params.id}`;
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.send('User updated');
  });
});

app.delete('/api/users/:id', (req, res) => {
  const sql = `DELETE FROM users WHERE id = ${req.params.id}`;
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.send('User deleted');
  });
});

// Start Server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
```

Avec ces exemples, tu devrais avoir une bonne base pour construire une application fullstack avec Node.js, Express, MySQL et CORS. N'hésite pas à me demander si tu as des questions spécifiques ou besoin de plus d'aide sur certaines parties !