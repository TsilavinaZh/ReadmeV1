Les hooks de React sont des fonctions spéciales qui te permettent de faire des choses cool avec tes composants sans avoir à écrire des classes compliquées. Voici les principaux hooks de React, expliqués de manière simple et avec deux exemples pour chaque :

### 1. useState
**Explication :** `useState` te permet de créer une "boîte" où tu peux ranger des informations que tu veux utiliser et changer plus tard.

**Exemples :**
- Imaginons que tu construis un compteur de bonbons :
```jsx
import React, { useState } from 'react';

function CompteurDeBonbons() {
  const [bonbons, setBonbons] = useState(0);

  return (
    <div>
      <p>Tu as {bonbons} bonbons</p>
      <button onClick={() => setBonbons(bonbons + 1)}>Ajouter un bonbon</button>
    </div>
  );
}
```

- Imaginons un formulaire simple où tu peux entrer ton nom :
```jsx
import React, { useState } from 'react';

function FormulaireNom() {
  const [nom, setNom] = useState('');

  return (
    <div>
      <input type="text" value={nom} onChange={(e) => setNom(e.target.value)} />
      <p>Bonjour, {nom} !</p>
    </div>
  );
}
```

### 2. useEffect
**Explication :** `useEffect` est comme une alarme qui se déclenche à chaque fois que quelque chose change ou quand le composant est affiché pour la première fois.

**Exemples :**
- Imaginons que tu veux afficher un message dans la console chaque fois que le composant est affiché :
```jsx
import React, { useEffect } from 'react';

function MessageDeBienvenue() {
  useEffect(() => {
    console.log('Bienvenue !');
  }, []);

  return <p>Regarde la console !</p>;
}
```

- Imaginons que tu veux changer le titre de la page chaque fois que tu entres ton nom :
```jsx
import React, { useState, useEffect } from 'react';

function ChangerTitre() {
  const [nom, setNom] = useState('');

  useEffect(() => {
    document.title = `Salut, ${nom}`;
  }, [nom]);

  return (
    <div>
      <input type="text" value={nom} onChange={(e) => setNom(e.target.value)} />
      <p>Ton nom est {nom}</p>
    </div>
  );
}
```

### 3. useContext
**Explication :** `useContext` te permet d'utiliser des informations de partout dans ton application sans avoir à les passer à chaque composant.

**Exemples :**
- Imaginons que tu as une application avec un thème clair et sombre :
```jsx
import React, { useContext, createContext } from 'react';

const ThemeContext = createContext('clair');

function Bouton() {
  const theme = useContext(ThemeContext);
  return <button style={{ background: theme === 'clair' ? '#fff' : '#333' }}>Clique moi !</button>;
}

function App() {
  return (
    <ThemeContext.Provider value="sombre">
      <Bouton />
    </ThemeContext.Provider>
  );
}
```

- Imaginons que tu as une application où tu veux afficher le nom de l'utilisateur :
```jsx
import React, { useContext, createContext } from 'react';

const UserContext = createContext('Invité');

function AfficherNom() {
  const nom = useContext(UserContext);
  return <p>Bonjour, {nom} !</p>;
}

function App() {
  return (
    <UserContext.Provider value="Alice">
      <AfficherNom />
    </UserContext.Provider>
  );
}
```

### 4. useRef
**Explication :** `useRef` te permet de créer une référence vers un élément que tu peux modifier directement sans refaire tout le composant.

**Exemples :**
- Imaginons que tu veux cliquer sur un bouton automatiquement :
```jsx
import React, { useRef, useEffect } from 'react';

function CliquerAutomatiquement() {
  const boutonRef = useRef(null);

  useEffect(() => {
    boutonRef.current.click();
  }, []);

  return <button ref={boutonRef}>Clique moi automatiquement</button>;
}
```

- Imaginons que tu veux focus sur un champ de texte quand la page se charge :
```jsx
import React, { useRef, useEffect } from 'react';

function FocusAutomatique() {
  const inputRef = useRef(null);

  useEffect(() => {
    inputRef.current.focus();
  }, []);

  return <input ref={inputRef} type="text" />;
}
```

### 5. useReducer
**Explication :** `useReducer` est comme `useState`, mais il est utile pour gérer des états plus complexes en utilisant une fonction qui dit comment l'état doit changer.

**Exemples :**
- Imaginons un compteur qui peut être augmenté, diminué ou réinitialisé :
```jsx
import React, { useReducer } from 'react';

function reducer(state, action) {
  switch (action.type) {
    case 'incrementer':
      return { compteur: state.compteur + 1 };
    case 'decrementer':
      return { compteur: state.compteur - 1 };
    case 'reinitialiser':
      return { compteur: 0 };
    default:
      throw new Error();
  }
}

function CompteurComplexe() {
  const [state, dispatch] = useReducer(reducer, { compteur: 0 });

  return (
    <div>
      <p>Compteur: {state.compteur}</p>
      <button onClick={() => dispatch({ type: 'incrementer' })}>+</button>
      <button onClick={() => dispatch({ type: 'decrementer' })}>-</button>
      <button onClick={() => dispatch({ type: 'reinitialiser' })}>Réinitialiser</button>
    </div>
  );
}
```

- Imaginons un formulaire où tu peux ajouter et retirer des tâches :
```jsx
import React, { useReducer, useState } from 'react';

function reducer(state, action) {
  switch (action.type) {
    case 'ajouter':
      return [...state, action.tache];
    case 'supprimer':
      return state.filter((_, index) => index !== action.index);
    default:
      throw new Error();
  }
}

function ListeDeTaches() {
  const [taches, dispatch] = useReducer(reducer, []);
  const [tache, setTache] = useState('');

  return (
    <div>
      <input value={tache} onChange={(e) => setTache(e.target.value)} />
      <button onClick={() => { dispatch({ type: 'ajouter', tache }); setTache(''); }}>Ajouter tâche</button>
      <ul>
        {taches.map((t, index) => (
          <li key={index}>
            {t} <button onClick={() => dispatch({ type: 'supprimer', index })}>Supprimer</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
```

Ces exemples te donnent une bonne idée de la manière d'utiliser les principaux hooks de React. En utilisant ces hooks, tu peux rendre tes composants plus puissants et flexibles !