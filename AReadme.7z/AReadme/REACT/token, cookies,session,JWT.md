Bien sûr ! Je vais t'expliquer les sessions, les tokens, les cookies et les JWT de manière simple avec des exemples de code en Node.js et Express. Imaginons que tu as une application web où les utilisateurs doivent se connecter pour accéder à certaines parties du site.

## Sessions

### Qu'est-ce qu'une session ?
Une session est comme une boîte temporaire où on peut stocker des informations sur un utilisateur pendant qu'il est connecté à un site. Quand l'utilisateur se déconnecte, la boîte est vidée.

### Exemples de code

1. **Installer les dépendances** :
   ```sh
   npm install express express-session
   ```

2. **Configurer les sessions dans Express** :
   ```js
   const express = require('express');
   const session = require('express-session');
   
   const app = express();
   
   app.use(session({
     secret: 'my_secret_key',
     resave: false,
     saveUninitialized: true,
     cookie: { secure: false } // true si HTTPS
   }));
   
   app.get('/', (req, res) => {
     if (req.session.views) {
       req.session.views++;
       res.send(`Vous avez visité cette page ${req.session.views} fois`);
     } else {
       req.session.views = 1;
       res.send('Bienvenue pour la première fois sur cette page !');
     }
   });
   
   app.listen(3000, () => {
     console.log('Serveur démarré sur le port 3000');
   });
   ```

## Cookies

### Qu'est-ce qu'un cookie ?
Un cookie est un petit fichier stocké sur l'ordinateur de l'utilisateur par le navigateur. Il peut contenir des informations comme les préférences de l'utilisateur ou son identifiant de session.

### Exemples de code

1. **Installer les dépendances** :
   ```sh
   npm install express cookie-parser
   ```

2. **Configurer les cookies dans Express** :
   ```js
   const express = require('express');
   const cookieParser = require('cookie-parser');
   
   const app = express();
   app.use(cookieParser());
   
   app.get('/', (req, res) => {
     res.cookie('username', 'John Doe');
     res.send('Cookie a été défini');
   });
   
   app.get('/read-cookie', (req, res) => {
     res.send(`Cookie lu : ${req.cookies.username}`);
   });
   
   app.listen(3000, () => {
     console.log('Serveur démarré sur le port 3000');
   });
   ```

## JWT (JSON Web Token)

### Qu'est-ce qu'un JWT ?
Un JWT est un jeton qui permet d'authentifier un utilisateur. Il est signé numériquement et peut être vérifié par le serveur pour s'assurer que l'utilisateur est authentique.

### Exemples de code

1. **Installer les dépendances** :
   ```sh
   npm install express jsonwebtoken
   ```

2. **Générer et vérifier un JWT dans Express** :
   ```js
   const express = require('express');
   const jwt = require('jsonwebtoken');
   
   const app = express();
   const secretKey = 'my_secret_key';
   
   app.use(express.json());
   
   app.post('/login', (req, res) => {
     const user = { id: 1, username: 'JohnDoe' };
     const token = jwt.sign(user, secretKey, { expiresIn: '1h' });
     res.json({ token });
   });
   
   app.get('/protected', (req, res) => {
     const token = req.headers['authorization'];
     if (!token) return res.sendStatus(403);
     
     jwt.verify(token, secretKey, (err, user) => {
       if (err) return res.sendStatus(403);
       res.json({ message: 'Bienvenue dans la zone protégée', user });
     });
   });
   
   app.listen(3000, () => {
     console.log('Serveur démarré sur le port 3000');
   });
   ```

## Résumé

- **Sessions** : Stockent des informations sur l'utilisateur temporairement côté serveur.
- **Cookies** : Stockent des informations côté client (dans le navigateur).
- **JWT (JSON Web Token)** : Jetons signés numériquement pour authentifier les utilisateurs de manière sécurisée et stateless (sans état côté serveur).

Ces concepts permettent de gérer l'authentification et les préférences des utilisateurs de manière sécurisée et efficace dans une application web.