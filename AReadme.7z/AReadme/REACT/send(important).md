Pour envoyer des données depuis une application React vers un serveur Node.js sans utiliser Axios, vous pouvez utiliser l'API Fetch intégrée dans JavaScript. Voici un exemple de comment vous pouvez le faire :

### Côté client (React)

1. **Installer React et configurer votre composant :**

Assurez-vous d'avoir une application React configurée. Si ce n'est pas déjà fait, vous pouvez créer une nouvelle application React en utilisant `create-react-app` :

```bash
npx create-react-app my-app
cd my-app
```

2. **Créer un composant pour envoyer des données :**

Voici un exemple simple d'un composant React qui envoie des données au serveur lorsqu'un formulaire est soumis :

```jsx
import React, { useState } from 'react';

const MyForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    
    const data = { name, email };

    try {
      const response = await fetch('http://localhost:5000/api/data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Success:', result);
      } else {
        console.error('Error:', response.statusText);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>
          Name:
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
        </label>
      </div>
      <div>
        <label>
          Email:
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
      </div>
      <button type="submit">Submit</button>
    </form>
  );
};

export default MyForm;
```

### Côté serveur (Node.js)

1. **Installer et configurer Express :**

Assurez-vous d'avoir Node.js installé et initialisez un nouveau projet avec npm. Ensuite, installez Express :

```bash
npm init -y
npm install express
```

2. **Créer un serveur avec Express pour gérer les requêtes POST :**

Voici un exemple simple d'un serveur Express qui écoute sur le port 5000 et traite les données envoyées depuis le client :

```javascript
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 5000;

// Middleware pour parser les corps de requête JSON
app.use(bodyParser.json());

app.post('/api/data', (req, res) => {
  const { name, email } = req.body;

  // Traitement des données reçues
  console.log('Received data:', { name, email });

  // Réponse au client
  res.status(200).json({ message: 'Data received successfully' });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
```

### Exécution

1. **Démarrer le serveur Node.js :**

```bash
node server.js
```

2. **Lancer votre application React :**

```bash
npm start
```

Ensuite, ouvrez votre application React dans un navigateur, remplissez le formulaire et soumettez-le. Vous devriez voir les données imprimées dans la console de votre serveur Node.js et recevoir une réponse de confirmation sur le client.

Cela montre comment envoyer des données de React à Node.js sans utiliser Axios, en utilisant l'API Fetch intégrée.


Pour utiliser `cors` avec Express afin de gérer les requêtes cross-origin, vous devez installer le package `cors` et l'utiliser comme middleware dans votre application Express. Voici comment vous pouvez le faire :

### Installation de `cors`

Vous devez d'abord installer le package `cors` via npm :

```bash
npm install cors
```

### Configuration de `cors` dans votre serveur Express

Ensuite, vous devez configurer `cors` dans votre serveur Express. Voici comment intégrer cela dans le code de votre serveur :

```javascript
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 5000;

// Utiliser cors pour permettre les requêtes cross-origin
app.use(cors());

// Middleware pour parser les corps de requête JSON
app.use(bodyParser.json());

app.post('/api/data', (req, res) => {
  const { name, email } = req.body;

  // Traitement des données reçues
  console.log('Received data:', { name, email });

  // Réponse au client
  res.status(200).json({ message: 'Data received successfully' });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
```

### Explication

- **Installation et importation de `cors`** : Vous installez le package `cors` et l'importez dans votre fichier serveur.
- **Utilisation de `cors` comme middleware** : Vous appelez `app.use(cors())` pour permettre à votre serveur de gérer les requêtes provenant d'autres origines (cross-origin requests). Par défaut, cela permet toutes les requêtes cross-origin.

### Configuration avancée (facultatif)

Si vous souhaitez configurer `cors` pour permettre uniquement certaines origines ou définir des options spécifiques, vous pouvez passer un objet de configuration à `cors`. Par exemple, pour permettre uniquement les requêtes provenant de `http://localhost:3000` (votre application React) :

```javascript
const corsOptions = {
  origin: 'http://localhost:3000',
  optionsSuccessStatus: 200 // Pour les navigateurs anciens supportant mal les requêtes CORS
};

app.use(cors(corsOptions));
```

### Exemple complet avec configuration avancée

Voici le code complet avec une configuration `cors` plus stricte :

```javascript
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 5000;

const corsOptions = {
  origin: 'http://localhost:3000', // Origine permise
  optionsSuccessStatus: 200 // Pour les navigateurs anciens supportant mal les requêtes CORS
};

// Utiliser cors avec les options définies
app.use(cors(corsOptions));

// Middleware pour parser les corps de requête JSON
app.use(bodyParser.json());

app.post('/api/data', (req, res) => {
  const { name, email } = req.body;

  // Traitement des données reçues
  console.log('Received data:', { name, email });

  // Réponse au client
  res.status(200).json({ message: 'Data received successfully' });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
```

Avec cela, votre serveur Express est maintenant configuré pour gérer les requêtes cross-origin provenant de votre application React fonctionnant sur `http://localhost:3000`.