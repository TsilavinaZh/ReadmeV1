L'erreur que vous voyez est liée aux règles CORS (Cross-Origin Resource Sharing). Le message indique que la requête preflight (OPTIONS) a échoué en raison d'une mauvaise configuration des en-têtes CORS.

Pour résoudre ce problème, vous devez vous assurer que votre serveur Node.js configure correctement les en-têtes CORS. Voici comment vous pouvez vérifier et corriger cela.

### Étape 1 : Assurez-vous que CORS est correctement configuré

Vous devez ajouter le middleware `cors` à votre application Express avec les options correctes pour permettre les requêtes provenant de `http://localhost:5173`.

### Exemple de serveur Express

```javascript
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 5000;

const corsOptions = {
  origin: 'http://localhost:5173', // Origine permise
  optionsSuccessStatus: 200 // Pour les navigateurs anciens supportant mal les requêtes CORS
};

// Utiliser cors avec les options définies
app.use(cors(corsOptions));

// Middleware pour parser les corps de requête JSON
app.use(bodyParser.json());

app.post('/api/data', (req, res) => {
  const { name, email } = req.body;

  // Traitement des données reçues
  console.log('Received data:', { name, email });

  // Réponse au client
  res.status(200).json({ message: 'Data received successfully' });
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
```

### Étape 2 : Assurez-vous que le client envoie les requêtes correctement

Vérifiez que la requête Fetch est bien configurée dans votre composant React :

```jsx
import React, { useState } from 'react';

const MyForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    
    const data = { name, email };

    try {
      const response = await fetch('http://localhost:5000/api/data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Success:', result);
      } else {
        console.error('Error:', response.statusText);
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>
          Name:
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
        </label>
      </div>
      <div>
        <label>
          Email:
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
      </div>
      <button type="submit">Submit</button>
    </form>
  );
};

export default MyForm;
```

### Étape 3 : Redémarrez votre serveur Node.js

Assurez-vous de redémarrer votre serveur Node.js après avoir apporté ces modifications pour qu'elles soient prises en compte.

### Vérification

1. Démarrez votre serveur Node.js :

```bash
node server.js
```

2. Lancez votre application React :

```bash
npm start
```

3. Ouvrez votre application React dans le navigateur à l'adresse `http://localhost:5173` et soumettez le formulaire.

Si vous avez correctement configuré le middleware CORS et les options d'origine, les requêtes devraient passer sans problème et vous ne devriez plus voir l'erreur CORS.