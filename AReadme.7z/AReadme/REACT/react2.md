Bien sûr ! Voici quelques exemples de code courants que vous pourriez trouver dans des projets React.js :

### Exemple de Composant React avec JSX :

```jsx
import React from 'react';

class MyComponent extends React.Component {
  render() {
    return (
      <div>
        <h1>Bienvenue sur mon site !</h1>
        <p>Ceci est un exemple de composant React.</p>
      </div>
    );
  }
}

export default MyComponent;
```

### Exemple d'utilisation de State et Props :

```jsx
import React, { useState } from 'react';

function Counter(props) {
  const [count, setCount] = useState(0);

  const increment = () => {
    setCount(count + 1);
  };

  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={increment}>Incrementer</button>
      <p>Props reçues: {props.message}</p>
    </div>
  );
}

export default Counter;
```

### Exemple d'utilisation de React Router pour la navigation :

```jsx
import React from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';

function Home() {
  return <h2>Accueil</h2>;
}

function About() {
  return <h2>À propos</h2>;
}

function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Accueil</Link>
            </li>
            <li>
              <Link to="/about">À propos</Link>
            </li>
          </ul>
        </nav>

        <Route path="/" exact component={Home} />
        <Route path="/about" component={About} />
      </div>
    </Router>
  );
}

export default App;
```

### Exemple d'appel API avec Axios :

```jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function UserList() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/users')
      .then(response => {
        setUsers(response.data);
      })
      .catch(error => {
        console.error('Erreur lors de la récupération des utilisateurs:', error);
      });
  }, []);

  return (
    <div>
      <h2>Liste des utilisateurs</h2>
      <ul>
        {users.map(user => (
          <li key={user.id}>{user.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default UserList;
```

### Exemple d'utilisation de Context API pour gérer l'état global :

```jsx
import React, { createContext, useContext, useState } from 'react';

// Création d'un contexte
const ThemeContext = createContext();

function App() {
  const [theme, setTheme] = useState('light');

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      <div className={theme === 'light' ? 'light-theme' : 'dark-theme'}>
        <Toolbar />
      </div>
    </ThemeContext.Provider>
  );
}

function Toolbar() {
  // Utilisation du contexte
  const { theme, setTheme } = useContext(ThemeContext);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  return (
    <div>
      <button onClick={toggleTheme}>Changer de thème</button>
      <p>Thème actuel: {theme}</p>
    </div>
  );
}

export default App;
```

Ces exemples représentent des patterns et des fonctionnalités couramment utilisés dans les projets React.js. Ils démontrent comment créer des composants, gérer l'état local et global, effectuer des appels API, et gérer la navigation avec React Router.



Pour envoyer des données à une API depuis un composant React et recevoir des données de cette API en retour, vous pouvez utiliser des requêtes HTTP. Les bibliothèques couramment utilisées pour cela sont Axios et Fetch. Voici comment vous pouvez procéder :

### Utilisation d'Axios pour envoyer et recevoir des données d'une API :

1. **Installation d'Axios** : Tout d'abord, assurez-vous d'avoir Axios installé dans votre projet React. Si ce n'est pas le cas, vous pouvez l'installer à l'aide de npm ou yarn :

   ```bash
   npm install axios
   # ou
   yarn add axios
   ```

2. **Exemple d'envoi de données à une API avec Axios** : Vous pouvez utiliser Axios dans un composant React pour envoyer des données à une API. Voici un exemple simple :

   ```jsx
   import React, { useState } from 'react';
   import axios from 'axios';

   function MyComponent() {
     const [data, setData] = useState('');
     const [inputValue, setInputValue] = useState('');

     const sendDataToAPI = () => {
       axios.post('https://api.example.com/data', { input: inputValue })
         .then(response => {
           console.log('Réponse de l\'API:', response.data);
           setData(response.data);
         })
         .catch(error => {
           console.error('Erreur lors de l\'envoi des données à l\'API:', error);
         });
     };

     return (
       <div>
         <input
           type="text"
           value={inputValue}
           onChange={(e) => setInputValue(e.target.value)}
         />
         <button onClick={sendDataToAPI}>Envoyer à l'API</button>
         <p>Réponse de l'API: {data}</p>
       </div>
     );
   }

   export default MyComponent;
   ```

   - Dans cet exemple, `axios.post` est utilisé pour envoyer une requête POST à `https://api.example.com/data` avec les données provenant de `inputValue`.
   - La réponse de l'API est capturée dans la promesse `.then`, où `response.data` contient les données renvoyées par l'API.
   - En cas d'erreur, `.catch` capture les erreurs éventuelles.

3. **Exemple de récupération de données depuis une API avec Axios** : Pour récupérer des données d'une API dans un composant React :

   ```jsx
   import React, { useState, useEffect } from 'react';
   import axios from 'axios';

   function FetchDataComponent() {
     const [data, setData] = useState(null);
     const [loading, setLoading] = useState(true);

     useEffect(() => {
       axios.get('https://api.example.com/data')
         .then(response => {
           setData(response.data);
           setLoading(false);
         })
         .catch(error => {
           console.error('Erreur lors de la récupération des données depuis l\'API:', error);
           setLoading(false);
         });
     }, []);

     if (loading) {
       return <p>Chargement en cours...</p>;
     }

     return (
       <div>
         <p>Données récupérées depuis l'API: </p>
         <pre>{JSON.stringify(data, null, 2)}</pre>
       </div>
     );
   }

   export default FetchDataComponent;
   ```

   - `axios.get` est utilisé pour effectuer une requête GET à `https://api.example.com/data` pour récupérer des données depuis l'API.
   - `useEffect` est utilisé pour effectuer la requête une seule fois lors du montage du composant (grâce au tableau de dépendances vide `[]`).
   - Une fois les données récupérées, elles sont mises à jour dans l'état local (`data`) à l'aide de `setData`.

Ces exemples montrent comment utiliser Axios pour envoyer des données à une API (POST) et récupérer des données d'une API (GET) dans des composants React. Assurez-vous d'adapter les URL et les données selon les besoins spécifiques de votre application et de gérer les erreurs de manière appropriée pour une meilleure robustesse de votre application React.