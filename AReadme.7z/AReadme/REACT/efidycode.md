 Je comprends que vous souhaitez un code complet pour une application de vote avec authentification, gestion des sessions, et toutes les fonctionnalités mentionnées. Je vais vous fournir une version plus complète du projet, incluant l'authentification et la gestion des sessions. Notez que c'est un code assez long, donc je vais le diviser en plusieurs parties.

Commençons par la structure du projet, puis nous passerons au code pour chaque partie.

Structure du projet :

```
project-root/
│
├── client/                 # Frontend React
│   ├── public/
│   │   └── index.html
│   └── src/
│       ├── components/
│       │   ├── CandidateList.js
│       │   ├── CandidateForm.js
│       │   ├── VotingResults.js
│       │   ├── Login.js
│       │   └── Register.js
│       ├── services/
│       │   └── api.js
│       ├── contexts/
│       │   └── AuthContext.js
│       ├── App.js
│       └── index.js
│
├── server/                 # Backend Express
│   ├── config/
│   │   └── db.js
│   ├── controllers/
│   │   ├── candidateController.js
│   │   └── authController.js
│   ├── middleware/
│   │   └── auth.js
│   ├── models/
│   │   ├── candidate.js
│   │   └── user.js
│   ├── routes/
│   │   ├── candidateRoutes.js
│   │   └── authRoutes.js
│   └── server.js
│
├── package.json
└── sql/
    └── schema.sql
```

1. Base de données (SQL)

Fichier: `sql/schema.sql`

```sql
CREATE DATABASE IF NOT EXISTS voting_app;
USE voting_app;

CREATE TABLE candidates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  photo VARCHAR(255),
  description TEXT,
  votes INT DEFAULT 0
);

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  has_voted BOOLEAN DEFAULT FALSE
);
```

2. Backend (Express et MySQL)

Fichier: `server/config/db.js`

```javascript
const mysql = require('mysql2');

const pool = mysql.createPool({
  host: 'localhost',
  user: 'your_username',
  password: 'your_password',
  database: 'voting_app',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

module.exports = pool.promise();
```

Fichier: `server/models/candidate.js`

```javascript
const db = require('../config/db');

class Candidate {
  static async getAll() {
    const [rows] = await db.query('SELECT * FROM candidates');
    return rows;
  }

  static async getById(id) {
    const [rows] = await db.query('SELECT * FROM candidates WHERE id = ?', [id]);
    return rows[0];
  }

  static async create(name, photo, description) {
    const [result] = await db.query(
      'INSERT INTO candidates (name, photo, description) VALUES (?, ?, ?)',
      [name, photo, description]
    );
    return result.insertId;
  }

  static async update(id, name, photo, description) {
    const [result] = await db.query(
      'UPDATE candidates SET name = ?, photo = ?, description = ? WHERE id = ?',
      [name, photo, description, id]
    );
    return result.affectedRows;
  }

  static async delete(id) {
    const [result] = await db.query('DELETE FROM candidates WHERE id = ?', [id]);
    return result.affectedRows;
  }

  static async vote(id, userId) {
    const connection = await db.getConnection();
    try {
      await connection.beginTransaction();

      const [userResult] = await connection.query(
        'UPDATE users SET has_voted = TRUE WHERE id = ? AND has_voted = FALSE',
        [userId]
      );

      if (userResult.affectedRows === 0) {
        throw new Error('User has already voted or does not exist');
      }

      const [candidateResult] = await connection.query(
        'UPDATE candidates SET votes = votes + 1 WHERE id = ?',
        [id]
      );

      if (candidateResult.affectedRows === 0) {
        throw new Error('Candidate not found');
      }

      await connection.commit();
      return true;
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  }

  static async getResults() {
    const [rows] = await db.query('SELECT id, name, votes FROM candidates ORDER BY votes DESC');
    return rows;
  }
}

module.exports = Candidate;
```

Fichier: `server/models/user.js`

```javascript
const db = require('../config/db');
const bcrypt = require('bcryptjs');

class User {
  static async create(username, email, password) {
    const hashedPassword = await bcrypt.hash(password, 10);
    const [result] = await db.query(
      'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
      [username, email, hashedPassword]
    );
    return result.insertId;
  }

  static async findByUsername(username) {
    const [rows] = await db.query('SELECT * FROM users WHERE username = ?', [username]);
    return rows[0];
  }

  static async findById(id) {
    const [rows] = await db.query('SELECT id, username, email, has_voted FROM users WHERE id = ?', [id]);
    return rows[0];
  }
}

module.exports = User;
```

Fichier: `server/controllers/candidateController.js`

```javascript
const Candidate = require('../models/candidate');

exports.getAllCandidates = async (req, res) => {
  try {
    const candidates = await Candidate.getAll();
    res.json(candidates);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getCandidateById = async (req, res) => {
  try {
    const candidate = await Candidate.getById(req.params.id);
    if (candidate) {
      res.json(candidate);
    } else {
      res.status(404).json({ message: 'Candidate not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createCandidate = async (req, res) => {
  try {
    const { name, photo, description } = req.body;
    const id = await Candidate.create(name, photo, description);
    res.status(201).json({ id, name, photo, description });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateCandidate = async (req, res) => {
  try {
    const { name, photo, description } = req.body;
    const affectedRows = await Candidate.update(req.params.id, name, photo, description);
    if (affectedRows) {
      res.json({ message: 'Candidate updated successfully' });
    } else {
      res.status(404).json({ message: 'Candidate not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.deleteCandidate = async (req, res) => {
  try {
    const affectedRows = await Candidate.delete(req.params.id);
    if (affectedRows) {
      res.json({ message: 'Candidate deleted successfully' });
    } else {
      res.status(404).json({ message: 'Candidate not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.voteForCandidate = async (req, res) => {
  try {
    await Candidate.vote(req.params.id, req.user.id);
    res.json({ message: 'Vote recorded successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.getVotingResults = async (req, res) => {
  try {
    const results = await Candidate.getResults();
    res.json(results);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
```

Fichier: `server/controllers/authController.js`

```javascript
const User = require('../models/user');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const JWT_SECRET = 'your_jwt_secret'; // Idéalement, stockez ceci dans une variable d'environnement

exports.register = async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const userId = await User.create(username, email, password);
    res.status(201).json({ message: 'User registered successfully', userId });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findByUsername(username);
    
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '1h' });
    res.json({ token, user: { id: user.id, username: user.username, email: user.email } });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (user) {
      res.json(user);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
```

Fichier: `server/middleware/auth.js`

```javascript
const jwt = require('jsonwebtoken');

const JWT_SECRET = 'your_jwt_secret'; // Utilisez la même clé secrète que dans authController.js

module.exports = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');

  if (!token) {
    return res.status(401).json({ message: 'No token, authorization denied' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = { id: decoded.userId };
    next();
  } catch (error) {
    res.status(401).json({ message: 'Token is not valid' });
  }
};
```

Fichier: `server/routes/candidateRoutes.js`

```javascript
const express = require('express');
const router = express.Router();
const candidateController = require('../controllers/candidateController');
const auth = require('../middleware/auth');

router.get('/', candidateController.getAllCandidates);
router.get('/results', candidateController.getVotingResults);
router.get('/:id', candidateController.getCandidateById);
router.post('/', auth, candidateController.createCandidate);
router.put('/:id', auth, candidateController.updateCandidate);
router.delete('/:id', auth, candidateController.deleteCandidate);
router.post('/:id/vote', auth, candidateController.voteForCandidate);

module.exports = router;
```

Fichier: `server/routes/authRoutes.js`

```javascript
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const auth = require('../middleware/auth');

router.post('/register', authController.register);
router.post('/login', authController.login);
router.get('/profile', auth, authController.getProfile);

module.exports = router;
```

Fichier: `server/server.js`

```javascript
const express = require('express');
const cors = require('cors');
const candidateRoutes = require('./routes/candidateRoutes');
const authRoutes = require('./routes/authRoutes');

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/candidates', candidateRoutes);
app.use('/api/auth', authRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
```

3. Frontend (React avec Ant Design)

Fichier: `client/src/services/api.js`

```javascript
import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const register = (data) => api.post('/auth/register', data);
export const login = (data) => api.post('/auth/login', data);
export const getProfile = () => api.get('/auth/profile');

export const getAllCandidates = () => api.get('/candidates');
export const getCandidateById = (id) => api.get(`/candidates/${id}`);
export const createCandidate = (data) => api.post('/candidates', data);
export const updateCandidate = (id, data) => api.put(`/candidates/${id}`, data);
export const deleteCandidate = (id) => api.delete(`/candidates/${id}`);
export const voteForCandidate = (id) => api.post(`/candidates/${id}/vote`);
export const getVotingResults = () => api.get('/candidates/results');
```

Fichier: `client/src/contexts/AuthContext.js`

```javascript
import React, { createContext, useState, useEffect } from 'react';
import { getProfile } from '../services/api';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const response = await getProfile();
          setUser(response.data);
        } catch (error) {
          console.error('Failed to load user:', error);
          localStorage.removeItem('token');
        }
      }
      setLoading(false);
    };
    loadUser();
  }, []);

  const login = (userData, token) => {
    setUser(userData);
    localStorage.setItem('token', token);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('token');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};
```

 Bien sûr, je vais continuer avec le reste du code pour le frontend.

Fichier: `client/src/components/Login.js` (suite)

```javascript
import React, { useContext } from 'react';
import { Form, Input, Button, message } from 'antd';
import { login } from '../services/api';
import { AuthContext } from '../contexts/AuthContext';
import { useHistory } from 'react-router-dom';

const Login = () => {
  const { login: authLogin } = useContext(AuthContext);
  const history = useHistory();

  const onFinish = async (values) => {
    try {
      const response = await login(values);
      authLogin(response.data.user, response.data.token);
      message.success('Logged in successfully');
      history.push('/');
    } catch (error) {
      message.error('Failed to login');
    }
  };

  return (
    <Form onFinish={onFinish}>
      <Form.Item name="username" rules={[{ required: true }]}>
        <Input placeholder="Username" />
      </Form.Item>
      <Form.Item name="password" rules={[{ required: true }]}>
        <Input.Password placeholder="Password" />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit">
          Login
        </Button>
      </Form.Item>
    </Form>
  );
};

export default Login;
```

Fichier: `client/src/components/Register.js`

```javascript
import React from 'react';
import { Form, Input, Button, message } from 'antd';
import { register } from '../services/api';
import { useHistory } from 'react-router-dom';

const Register = () => {
  const history = useHistory();

  const onFinish = async (values) => {
    try {
      await register(values);
      message.success('Registered successfully');
      history.push('/login');
    } catch (error) {
      message.error('Failed to register');
    }
  };

  return (
    <Form onFinish={onFinish}>
      <Form.Item name="username" rules={[{ required: true }]}>
        <Input placeholder="Username" />
      </Form.Item>
      <Form.Item name="email" rules={[{ required: true, type: 'email' }]}>
        <Input placeholder="Email" />
      </Form.Item>
      <Form.Item name="password" rules={[{ required: true }]}>
        <Input.Password placeholder="Password" />
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit">
          Register
        </Button>
      </Form.Item>
    </Form>
  );
};

export default Register;
```

Fichier: `client/src/components/CandidateList.js`

```javascript
import React, { useState, useEffect, useContext } from 'react';
import { Table, Button, message, Space } from 'antd';
import { getAllCandidates, voteForCandidate, deleteCandidate } from '../services/api';
import { AuthContext } from '../contexts/AuthContext';

const CandidateList = () => {
  const [candidates, setCandidates] = useState([]);
  const { user } = useContext(AuthContext);

  useEffect(() => {
    fetchCandidates();
  }, []);

  const fetchCandidates = async () => {
    try {
      const response = await getAllCandidates();
      setCandidates(response.data);
    } catch (error) {
      message.error('Failed to fetch candidates');
    }
  };

  const handleVote = async (id) => {
    try {
      await voteForCandidate(id);
      message.success('Vote recorded successfully');
      fetchCandidates();
    } catch (error) {
      message.error('Failed to record vote');
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteCandidate(id);
      message.success('Candidate deleted successfully');
      fetchCandidates();
    } catch (error) {
      message.error('Failed to delete candidate');
    }
  };

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Photo',
      dataIndex: 'photo',
      key: 'photo',
      render: (photo) => <img src={photo} alt="Candidate" style={{ width: 50, height: 50 }} />,
    },
    {
      title: 'Description',
      dataIndex: 'description',
      key: 'description',
    },
    {
      title: 'Votes',
      dataIndex: 'votes',
      key: 'votes',
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          {user && !user.has_voted && (
            <Button onClick={() => handleVote(record.id)}>Vote</Button>
          )}
          {user && user.isAdmin && (
            <Button onClick={() => handleDelete(record.id)} danger>
              Delete
            </Button>
          )}
        </Space>
      ),
    },
  ];

  return <Table dataSource={candidates} columns={columns} rowKey="id" />;
};

export default CandidateList;
```

Fichier: `client/src/components/CandidateForm.js`

```javascript
import React from 'react';
import { Form, Input, Button, message, Upload } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import { createCandidate } from '../services/api';

const CandidateForm = ({ onCandidateAdded }) => {
  const [form] = Form.useForm();

  const onFinish = async (values) => {
    try {
      const formData = new FormData();
      formData.append('name', values.name);
      formData.append('description', values.description);
      if (values.photo && values.photo[0]) {
        formData.append('photo', values.photo[0].originFileObj);
      }

      await createCandidate(formData);
      message.success('Candidate added successfully');
      form.resetFields();
      onCandidateAdded();
    } catch (error) {
      message.error('Failed to add candidate');
    }
  };

  return (
    <Form form={form} onFinish={onFinish} layout="vertical">
      <Form.Item name="name" label="Name" rules={[{ required: true }]}>
        <Input />
      </Form.Item>
      <Form.Item name="description" label="Description" rules={[{ required: true }]}>
        <Input.TextArea />
      </Form.Item>
      <Form.Item name="photo" label="Photo">
        <Upload beforeUpload={() => false} listType="picture">
          <Button icon={<UploadOutlined />}>Click to upload</Button>
        </Upload>
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit">
          Add Candidate
        </Button>
      </Form.Item>
    </Form>
  );
};

export default CandidateForm;
```

Fichier: `client/src/components/VotingResults.js`

```javascript
import React, { useState, useEffect } from 'react';
import { Table, message } from 'antd';
import { getVotingResults } from '../services/api';

const VotingResults = () => {
  const [results, setResults] = useState([]);

  useEffect(() => {
    fetchResults();
  }, []);

  const fetchResults = async () => {
    try {
      const response = await getVotingResults();
      setResults(response.data);
    } catch (error) {
      message.error('Failed to fetch voting results');
    }
  };

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Votes',
      dataIndex: 'votes',
      key: 'votes',
    },
  ];

  return <Table dataSource={results} columns={columns} rowKey="id" />;
};

export default VotingResults;
```

Fichier: `client/src/App.js`

```javascript
import React, { useContext } from 'react';
import { Layout, Menu } from 'antd';
import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom';
import CandidateList from './components/CandidateList';
import CandidateForm from './components/CandidateForm';
import VotingResults from './components/VotingResults';
import Login from './components/Login';
import Register from './components/Register';
import { AuthContext, AuthProvider } from './contexts/AuthContext';

const { Header, Content } = Layout;

const AuthenticatedApp = () => {
  const { user, logout } = useContext(AuthContext);

  return (
    <Router>
      <Layout className="layout">
        <Header>
          <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['1']}>
            <Menu.Item key="1">
              <Link to="/">Candidates</Link>
            </Menu.Item>
            {user && user.isAdmin && (
              <Menu.Item key="2">
                <Link to="/add">Add Candidate</Link>
              </Menu.Item>
            )}
            <Menu.Item key="3">
              <Link to="/results">Results</Link>
            </Menu.Item>
            {user ? (
              <Menu.Item key="4" onClick={logout}>
                Logout
              </Menu.Item>
            ) : (
              <>
                <Menu.Item key="4">
                  <Link to="/login">Login</Link>
                </Menu.Item>
                <Menu.Item key="5">
                  <Link to="/register">Register</Link>
                </Menu.Item>
              </>
            )}
          </Menu>
        </Header>
        <Content style={{ padding: '0 50px' }}>
          <div className="site-layout-content" style={{ margin: '16px 0' }}>
            <Switch>
              <Route exact path="/" component={CandidateList} />
              {user && user.isAdmin && (
                <Route path="/add" component={CandidateForm} />
              )}
              <Route path="/results" component={VotingResults} />
              <Route path="/login" component={Login} />
              <Route path="/register" component={Register} />
            </Switch>
          </div>
        </Content>
      </Layout>
    </Router>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <AuthenticatedApp />
    </AuthProvider>
  );
};

export default App;
```

Fichier: `client/src/index.js`

```javascript
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import 'antd/dist/antd.css';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);
```

Voilà ! Vous avez maintenant une application de vote complète avec authentification, gestion des sessions, et toutes les fonctionnalités demandées. Le frontend utilise React avec Ant Design pour l'interface utilisateur, et le backend utilise Express avec MySQL pour la gestion des données.

Pour exécuter l'application :

1. Créez la base de données en utilisant le fichier `schema.sql`.
2. Dans le dossier `server`, exécutez `npm install` puis `node server.js`.
3. Dans le dossier `client`, exécutez `npm install` puis `npm start`.

N'oubliez pas d'installer les dépendances nécessaires (express, mysql2, cors, bcryptjs, jsonwebtoken pour le backend ; react, react-router-dom, axios, antd pour le frontend).

Vous devrez peut-être ajuster certains détails en fonction de votre configuration spécifique, mais ce code devrait vous donner une base solide pour votre application de vote.