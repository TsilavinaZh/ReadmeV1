Pour afficher les valeurs de session sur différentes pages avec React et Express.js, vous devez suivre ces étapes :

1. **Stocker les valeurs dans la session côté serveur (comme montré précédemment).**
2. **Créer des routes supplémentaires pour récupérer les valeurs de la session.**
3. **Utiliser React Router pour naviguer entre les pages et Axios pour récupérer les données de session côté client.**

### 1. Mise à jour du backend (Express.js)

Ajoutez une route GET pour récupérer les valeurs de la session :

**`index.js` :**
```js
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const session = require('express-session');

const app = express();
const PORT = 5000;

app.use(cors({ origin: 'http://localhost:3000', credentials: true }));
app.use(bodyParser.json());
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }  // Pour le développement, mettre `secure: true` en production si vous utilisez HTTPS
}));

app.post('/api/input', (req, res) => {
    const { inputText } = req.body;
    req.session.inputText = inputText;
    res.sendStatus(200);
});

app.get('/api/input', (req, res) => {
    if (req.session.inputText) {
        res.json({ inputText: req.session.inputText });
    } else {
        res.sendStatus(404);
    }
});

app.listen(PORT, () => {
    console.log(`Serveur démarré sur le port ${PORT}`);
});
```

### 2. Mise à jour du frontend (React)

Installez React Router :
```bash
npm install react-router-dom
```

**`App.js` :**
```jsx
import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import Home from './Home';
import Display from './Display';

function App() {
    return (
        <Router>
            <div>
                <nav>
                    <ul>
                        <li>
                            <Link to="/">Home</Link>
                        </li>
                        <li>
                            <Link to="/display">Display</Link>
                        </li>
                    </ul>
                </nav>
                <Switch>
                    <Route path="/" exact component={Home} />
                    <Route path="/display" component={Display} />
                </Switch>
            </div>
        </Router>
    );
}

export default App;
```

**`Home.js` :**
```jsx
import React, { useState } from 'react';
import axios from 'axios';

function Home() {
    const [inputText, setInputText] = useState('');

    const handleChange = (event) => {
        setInputText(event.target.value);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            await axios.post('http://localhost:5000/api/input', { inputText }, { withCredentials: true });
            alert('Donnée envoyée avec succès');
        } catch (error) {
            console.error('Erreur lors de l\'envoi de la donnée', error);
        }
    };

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <label>
                    Entrez du texte :
                    <input type="text" value={inputText} onChange={handleChange} />
                </label>
                <button type="submit">Soumettre</button>
            </form>
        </div>
    );
}

export default Home;
```

**`Display.js` :**
```jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Display() {
    const [inputText, setInputText] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/input', { withCredentials: true });
                setInputText(response.data.inputText);
            } catch (error) {
                console.error('Erreur lors de la récupération de la donnée', error);
            }
        };

        fetchData();
    }, []);

    return (
        <div>
            <h1>Valeur de session</h1>
            {inputText ? <p>Vous avez entré : {inputText}</p> : <p>Aucune valeur n'a été soumise.</p>}
        </div>
    );
}

export default Display;
```

### Explications :

1. **Backend (Express.js) :**
   - Route POST `/api/input` : Stocke la valeur dans la session.
   - Route GET `/api/input` : Récupère la valeur de la session.

2. **Frontend (React) :**
   - `App.js` : Utilise React Router pour naviguer entre les pages "Home" et "Display".
   - `Home.js` : Formulaire pour envoyer des données au serveur.
   - `Display.js` : Utilise `useEffect` pour récupérer et afficher la valeur de la session depuis le serveur.

### Démarrage :

1. **Démarrer le serveur Express.js :**
   ```bash
   node index.js
   ```

2. **Démarrer l'application React :**
   ```bash
   npm start
   ```

Avec cette configuration, vous pouvez entrer une valeur sur la page d'accueil, l'envoyer au serveur, et la récupérer pour l'afficher sur une autre page.


Pour détruire une session en Express.js, vous pouvez utiliser la méthode `req.session.destroy()` sur le serveur. Ensuite, vous pouvez appeler cette route depuis le frontend avec React pour déclencher la destruction de la session.

Voici comment vous pouvez mettre en œuvre cela :

### 1. Mise à jour du backend (Express.js)

Ajoutez une route pour détruire la session :

**`index.js` :**
```js
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const session = require('express-session');

const app = express();
const PORT = 5000;

app.use(cors({ origin: 'http://localhost:3000', credentials: true }));
app.use(bodyParser.json());
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }  // Pour le développement, mettre `secure: true` en production si vous utilisez HTTPS
}));

app.post('/api/input', (req, res) => {
    const { inputText } = req.body;
    req.session.inputText = inputText;
    res.sendStatus(200);
});

app.get('/api/input', (req, res) => {
    if (req.session.inputText) {
        res.json({ inputText: req.session.inputText });
    } else {
        res.sendStatus(404);
    }
});

app.post('/api/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.sendStatus(500);
        }
        res.sendStatus(200);
    });
});

app.listen(PORT, () => {
    console.log(`Serveur démarré sur le port ${PORT}`);
});
```

### 2. Mise à jour du frontend (React)

Ajoutez une fonction pour appeler la route de déconnexion et détruire la session :

**`Display.js` :**
```jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Display() {
    const [inputText, setInputText] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:5000/api/input', { withCredentials: true });
                setInputText(response.data.inputText);
            } catch (error) {
                console.error('Erreur lors de la récupération de la donnée', error);
            }
        };

        fetchData();
    }, []);

    const handleLogout = async () => {
        try {
            await axios.post('http://localhost:5000/api/logout', {}, { withCredentials: true });
            alert('Session détruite avec succès');
            setInputText(''); // Réinitialiser l'état
        } catch (error) {
            console.error('Erreur lors de la destruction de la session', error);
        }
    };

    return (
        <div>
            <h1>Valeur de session</h1>
            {inputText ? <p>Vous avez entré : {inputText}</p> : <p>Aucune valeur n'a été soumise.</p>}
            <button onClick={handleLogout}>Déconnexion</button>
        </div>
    );
}

export default Display;
```

### Explications :

1. **Backend (Express.js) :**
   - La route POST `/api/logout` utilise `req.session.destroy()` pour détruire la session. Si une erreur survient, elle renvoie un statut 500, sinon un statut 200.

2. **Frontend (React) :**
   - `handleLogout` : Fonction qui envoie une requête POST à la route `/api/logout` pour détruire la session. Si la session est détruite avec succès, elle réinitialise l'état de `inputText`.

### Démarrage :

1. **Démarrer le serveur Express.js :**
   ```bash
   node index.js
   ```

2. **Démarrer l'application React :**
   ```bash
   npm start
   ```

Avec cette configuration, vous pouvez détruire la session côté serveur en appelant la route appropriée depuis votre frontend React.
