Pour créer un exemple de code CORS (Cross-Origin Resource Sharing) et l'afficher dans une application React sans utiliser Axios, tu peux suivre les étapes ci-dessous. Nous utiliserons `fetch` pour effectuer la requête HTTP.

### Serveur (Node.js avec Express)

Tout d'abord, nous allons créer un serveur simple en Node.js avec Express pour gérer les requêtes CORS.

1. **Installer les dépendances nécessaires** :
   ```bash
   npm init -y
   npm install express cors
   ```

2. **Créer un fichier `server.js`** et ajouter le code suivant :
   ```javascript
   const express = require('express');
   const cors = require('cors');
   const app = express();

   app.use(cors());

   app.get('/api/data', (req, res) => {
     res.json({ message: 'Hello from the server!' });
   });

   const PORT = 5000;
   app.listen(PORT, () => {
     console.log(`Server is running on http://localhost:${PORT}`);
   });
   ```

### Client (React)

Ensuite, nous allons créer une application React qui va consommer cette API.

1. **Créer une nouvelle application React** (si ce n'est pas déjà fait) :
   ```bash
   npx create-react-app my-app
   cd my-app
   ```

2. **Modifier le composant `App.js`** pour ajouter le code suivant :
   ```javascript
   import React, { useEffect, useState } from 'react';

   function App() {
     const [data, setData] = useState(null);

     useEffect(() => {
       fetch('http://localhost:5000/api/data')
         .then((response) => response.json())
         .then((data) => setData(data))
         .catch((error) => console.error('Error fetching data:', error));
     }, []);

     return (
       <div className="App">
         <header className="App-header">
           <h1>React CORS Example</h1>
           {data ? <p>{data.message}</p> : <p>Loading...</p>}
         </header>
       </div>
     );
   }

   export default App;
   ```

### Démarrer le serveur et le client

1. **Démarrer le serveur** :
   ```bash
   node server.js
   ```

2. **Démarrer l'application React** :
   ```bash
   npm start
   ```

### Explications

- **Serveur Node.js avec Express** : Le serveur écoute sur le port 5000 et utilise le middleware `cors` pour permettre les requêtes CORS. Il expose