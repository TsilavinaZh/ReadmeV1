Bien sûr! Voici un cours complet sur les sessions en JavaScript, incluant les concepts fondamentaux et des exemples de code pour illustrer leur utilisation.

## Introduction aux sessions

Une session est un moyen de stocker des données sur le serveur pour un utilisateur particulier. Les sessions sont utilisées pour conserver des informations entre les requêtes HTTP, car le protocole HTTP est sans état (stateless). Cela signifie que chaque requête est indépendante et ne conserve pas de données sur les requêtes précédentes.

Les sessions sont couramment utilisées pour des tâches telles que l'authentification des utilisateurs, la gestion de paniers d'achat, et la personnalisation de l'expérience utilisateur.

## Les cookies

Avant d'explorer les sessions, il est important de comprendre les cookies, car ils sont souvent utilisés pour stocker l'identifiant de session du côté client.

Voici un exemple simple de création et de lecture de cookies en JavaScript:

### Création d'un cookie

```javascript
document.cookie = "username=John Doe";
```

### Lecture des cookies

```javascript
let cookies = document.cookie;
console.log(cookies); // "username=John Doe"
```

## Sessions côté serveur

Pour gérer les sessions côté serveur avec JavaScript, nous utiliserons Node.js et Express.js, un framework populaire pour Node.js.

### Installation

Assurez-vous d'avoir Node.js et npm installés sur votre machine. Ensuite, créez un nouveau projet et installez les dépendances nécessaires:

```bash
mkdir session-demo
cd session-demo
npm init -y
npm install express express-session
```

### Configuration de base d'Express avec des sessions

Voici un exemple de configuration d'une application Express.js avec des sessions:

```javascript
const express = require('express');
const session = require('express-session');
const app = express();

app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Utiliser true en production avec HTTPS
}));

app.get('/', (req, res) => {
  if (req.session.views) {
    req.session.views++;
    res.send(`Number of views: ${req.session.views}`);
  } else {
    req.session.views = 1;
    res.send('Welcome to the session demo. Refresh!');
  }
});

app.listen(3000, () => {
  console.log('Server started on http://localhost:3000');
});
```

Dans cet exemple:
- Nous configurons le middleware `express-session` avec une clé secrète.
- Nous définissons un endpoint de base (`/`) qui compte et affiche le nombre de fois que l'utilisateur a visité la page au cours de la session.

## Gestion des sessions

### Stockage des sessions

Par défaut, les sessions sont stockées en mémoire. Cela convient aux applications simples, mais pour les applications à grande échelle, il est recommandé d'utiliser un magasin de session persistant, comme une base de données ou un magasin en mémoire (Redis).

Voici un exemple de configuration avec Redis:

```bash
npm install connect-redis redis
```

Ensuite, configurez votre application pour utiliser Redis comme magasin de sessions:

```javascript
const session = require('express-session');
const RedisStore = require('connect-redis')(session);
const redis = require('redis');
const client = redis.createClient();

app.use(session({
  store: new RedisStore({ client }),
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Utiliser true en production avec HTTPS
}));
```

### Authentification utilisateur avec sessions

Voici un exemple simple d'authentification utilisateur utilisant des sessions:

```javascript
const users = {
  'user1': 'password1',
  'user2': 'password2'
};

app.use(express.json());

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (users[username] && users[username] === password) {
    req.session.user = username;
    res.send('Logged in!');
  } else {
    res.status(401).send('Invalid credentials');
  }
});

app.get('/protected', (req, res) => {
  if (req.session.user) {
    res.send(`Hello ${req.session.user}, you have access to this route.`);
  } else {
    res.status(401).send('You need to log in first.');
  }
});
```

Dans cet exemple:
- Nous définissons un endpoint `/login` pour authentifier les utilisateurs.
- Si les informations d'identification sont valides, l'utilisateur est enregistré dans la session.
- Un endpoint protégé `/protected` vérifie si l'utilisateur est connecté avant d'autoriser l'accès.

## Conclusion

Les sessions sont un outil puissant pour gérer l'état des utilisateurs dans une application web. En utilisant Express.js avec `express-session` et un magasin de session persistant comme Redis, vous pouvez facilement mettre en place des sessions robustes et sécurisées.

Pour aller plus loin, vous pouvez explorer des concepts tels que les JWT (JSON Web Tokens) pour des alternatives sans état aux sessions, ou approfondir les mécanismes de sécurité liés aux sessions comme les cookies sécurisés et les protections CSRF (Cross-Site Request Forgery).



Utiliser les sessions avec une application React et Express implique une architecture client-serveur où React est le client et Express gère les sessions côté serveur. Voici un guide pour configurer une telle application.

### Prérequis

Assurez-vous d'avoir Node.js, npm, et `create-react-app` installés.

### Étape 1: Configuration du serveur Express

1. Créez un dossier pour le serveur et initialisez un nouveau projet Node.js:

```bash
mkdir my-app-server
cd my-app-server
npm init -y
```

2. Installez les dépendances nécessaires:

```bash
npm install express express-session cors body-parser
```

3. Créez un fichier `server.js` et configurez votre serveur Express avec les sessions:

```javascript
const express = require('express');
const session = require('express-session');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));

app.use(session({
  secret: 'your_secret_key',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Utiliser true en production avec HTTPS
}));

const users = {
  'user1': 'password1',
  'user2': 'password2'
};

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (users[username] && users[username] === password) {
    req.session.user = username;
    res.send({ message: 'Logged in!' });
  } else {
    res.status(401).send({ message: 'Invalid credentials' });
  }
});

app.get('/protected', (req, res) => {
  if (req.session.user) {
    res.send({ message: `Hello ${req.session.user}, you have access to this route.` });
  } else {
    res.status(401).send({ message: 'You need to log in first.' });
  }
});

app.listen(4000, () => {
  console.log('Server started on http://localhost:4000');
});
```

### Étape 2: Configuration de l'application React

1. Créez un dossier pour le client et initialisez une nouvelle application React:

```bash
npx create-react-app my-app-client
cd my-app-client
```

2. Installez Axios pour effectuer des requêtes HTTP:

```bash
npm install axios
```

3. Modifiez `src/App.js` pour ajouter un formulaire de connexion et gérer les requêtes vers le serveur Express:

```javascript
import React, { useState } from 'react';
import axios from 'axios';

const App = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:4000/login', {
        username,
        password
      }, { withCredentials: true });
      setMessage(response.data.message);
    } catch (error) {
      setMessage(error.response.data.message);
    }
  };

  const handleProtected = async () => {
    try {
      const response = await axios.get('http://localhost:4000/protected', { withCredentials: true });
      setMessage(response.data.message);
    } catch (error) {
      setMessage(error.response.data.message);
    }
  };

  return (
    <div>
      <h1>Login</h1>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
      <button onClick={handleProtected}>Protected Route</button>
      <p>{message}</p>
    </div>
  );
};

export default App;
```

### Étape 3: Lancer le serveur et l'application React

1. Dans le dossier du serveur, lancez le serveur Express:

```bash
node server.js
```

2. Dans le dossier du client, lancez l'application React:

```bash
npm start
```

### Explications

- **CORS**: Nous avons configuré CORS pour permettre les requêtes du client React (`http://localhost:3000`) vers le serveur Express (`http://localhost:4000`).
- **Sessions**: Le middleware `express-session` gère les sessions, et l'identifiant de session est stocké dans un cookie envoyé au client.
- **Requêtes HTTP**: Utilisation d'Axios pour effectuer des requêtes POST pour la connexion et GET pour accéder à la route protégée.

### Conclusion

Cette configuration vous permet d'utiliser des sessions pour gérer l'authentification et l'autorisation dans une application React avec un backend Express. Vous pouvez adapter et étendre cette architecture pour répondre aux besoins spécifiques de votre application.



Pour utiliser les sessions sur plusieurs pages dans une application React, vous pouvez suivre ces étapes :

1. **Configurer votre serveur Express pour les sessions (comme décrit précédemment)**
2. **Configurer votre client React pour gérer les sessions et les redirections**

### Étape 1: Configuration du serveur Express

Assurez-vous que votre serveur Express est correctement configuré pour gérer les sessions et CORS, comme illustré ci-dessus.

### Étape 2: Configuration de l'application React pour les sessions et la navigation

1. **Structurez votre application React pour avoir plusieurs pages**

Nous utiliserons `react-router-dom` pour gérer la navigation entre les pages.

```bash
npm install react-router-dom
```

2. **Créez des composants pour chaque page**

Par exemple, créez `Home.js`, `Login.js`, et `Protected.js`.

#### `Home.js`

```javascript
import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Home</h1>
      <p>Welcome to the home page!</p>
    </div>
  );
};

export default Home;
```

#### `Login.js`

```javascript
import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://localhost:4000/login', {
        username,
        password
      }, { withCredentials: true });
      setMessage(response.data.message);
      navigate('/protected'); // Rediriger vers la page protégée après connexion réussie
    } catch (error) {
      setMessage(error.response.data.message);
    }
  };

  return (
    <div>
      <h1>Login</h1>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
      <p>{message}</p>
    </div>
  );
};

export default Login;
```

#### `Protected.js`

```javascript
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Protected = () => {
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:4000/protected', { withCredentials: true });
        setMessage(response.data.message);
      } catch (error) {
        setMessage(error.response.data.message);
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h1>Protected</h1>
      <p>{message}</p>
    </div>
  );
};

export default Protected;
```

3. **Configurer les routes dans `App.js`**

```javascript
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Login from './Login';
import Protected from './Protected';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/protected" element={<Protected />} />
      </Routes>
    </Router>
  );
};

export default App;
```

### Étape 3: Gestion des redirections et des protections de route

Pour rediriger les utilisateurs non connectés, vous pouvez créer un composant de route protégée.

#### `ProtectedRoute.js`

```javascript
import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import axios from 'axios';

const ProtectedRoute = ({ element: Component, ...rest }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(null);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        await axios.get('http://localhost:4000/protected', { withCredentials: true });
        setIsAuthenticated(true);
      } catch (error) {
        setIsAuthenticated(false);
      }
    };

    checkAuth();
  }, []);

  if (isAuthenticated === null) {
    return <div>Loading...</div>; // Ou un indicateur de chargement
  }

  return isAuthenticated ? <Component {...rest} /> : <Navigate to="/login" />;
};

export default ProtectedRoute;
```

Puis, utilisez `ProtectedRoute` pour protéger les routes dans `App.js`:

```javascript
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Login from './Login';
import Protected from './Protected';
import ProtectedRoute from './ProtectedRoute';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route
          path="/protected"
          element={<ProtectedRoute element={Protected} />}
        />
      </Routes>
    </Router>
  );
};

export default App;
```

### Conclusion

Avec cette configuration, vous avez une application React avec plusieurs pages qui utilise des sessions pour gérer l'authentification. Les utilisateurs non connectés sont redirigés vers la page de connexion lorsqu'ils essaient d'accéder à une route protégée. Vous pouvez étendre cette configuration pour inclure des fonctionnalités supplémentaires comme l'inscription, la déconnexion, et la gestion des rôles utilisateurs.



