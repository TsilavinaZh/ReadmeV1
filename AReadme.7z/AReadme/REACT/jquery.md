jQuery est une bibliothèque JavaScript rapide, petite et riche en fonctionnalités. Elle simplifie grandement la manipulation des documents HTML, la gestion des événements, l'animation et l'interaction Ajax, grâce à une API facile à utiliser qui fonctionne sur une multitude de navigateurs.

### Historique et Popularité
- **Création**: jQuery a été créé par John Resig et publié en janvier 2006.
- **Popularité**: jQuery est l'une des bibliothèques JavaScript les plus populaires, utilisée par une grande partie des sites web.

### Avantages de jQuery
1. **Simplicité**: jQuery rend les sélections et manipulations DOM très simples.
2. **Compatibilité entre navigateurs**: Elle gère automatiquement les différences entre les navigateurs.
3. **Fonctionnalités enrichies**: Animation, manipulation DOM, gestion des événements, et Ajax sont simplifiés.
4. **Extensible**: jQuery peut être facilement étendu par des plugins.

### Installation et Utilisation
#### Intégration de jQuery
1. **CDN (Content Delivery Network)**:
   ```html
   <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   ```
2. **Téléchargement et hébergement local**:
   Téléchargez jQuery depuis [jquery.com](https://jquery.com) et ajoutez-le à votre projet :
   ```html
   <script src="path/to/your/jquery-3.6.0.min.js"></script>
   ```

### Syntaxe de Base
La syntaxe de jQuery est conçue pour être simple :
```javascript
$(document).ready(function(){
    // Votre code ici
});
```
Le `$` est le raccourci pour `jQuery`. La fonction `$(document).ready()` garantit que le DOM est entièrement chargé avant l'exécution du code.

### Sélecteurs jQuery
Les sélecteurs permettent de sélectionner et de manipuler des éléments HTML :
```javascript
$(document).ready(function(){
    // Sélectionne tous les éléments <p>
    $("p").css("color", "red");

    // Sélectionne l'élément avec id="unique"
    $("#unique").text("Texte modifié");

    // Sélectionne tous les éléments avec la classe .maClasse
    $(".maClasse").hide();
});
```

### Manipulation du DOM
jQuery simplifie la modification des éléments HTML :
- **Changer le contenu** :
  ```javascript
  $("#idElement").text("Nouveau texte");
  $("#idElement").html("<b>Nouveau contenu HTML</b>");
  ```
- **Changer les attributs** :
  ```javascript
  $("#idElement").attr("src", "nouvelleImage.jpg");
  ```
- **Ajouter ou enlever des classes** :
  ```javascript
  $("#idElement").addClass("nouvelleClasse");
  $("#idElement").removeClass("ancienneClasse");
  ```

### Gestion des événements
jQuery offre une manière élégante de gérer les événements :
```javascript
$(document).ready(function(){
    $("#bouton").click(function(){
        alert("Bouton cliqué!");
    });

    $("p").mouseover(function(){
        $(this).css("color", "blue");
    });
});
```

### Effets et Animations
jQuery permet de créer des animations et des effets visuels facilement :
```javascript
$(document).ready(function(){
    $("#bouton").click(function(){
        $("p").hide();  // Cache tous les <p>
    });

    $("#bouton").click(function(){
        $("p").fadeOut();  // Fait disparaître tous les <p> avec un effet de fondu
    });

    $("#bouton").click(function(){
        $("p").slideUp();  // Fait glisser vers le haut tous les <p>
    });
});
```

### AJAX avec jQuery
jQuery simplifie les requêtes AJAX :
```javascript
$(document).ready(function(){
    $("#chargerContenu").click(function(){
        $("#contenu").load("fichier.html");
    });

    $("#envoyerDonnees").click(function(){
        $.post("serveur.php", { nom: "John", age: 30 }, function(data){
            $("#resultat").html(data);
        });
    });
});
```

### Extensibilité
Les plugins jQuery permettent d'ajouter des fonctionnalités supplémentaires :
```javascript
// Exemple de création d'un plugin jQuery simple
$.fn.vert = function() {
    this.css("color", "green");
    return this;
};

// Utilisation du plugin
$("p").vert();
```

### Conclusion
jQuery est un outil puissant et polyvalent qui peut grandement simplifier le développement web en JavaScript. Bien que de nouvelles technologies comme les frameworks modernes (React, Vue.js, etc.) aient gagné en popularité, jQuery reste pertinent pour de nombreux projets, en particulier ceux nécessitant une compatibilité étendue entre les navigateurs.